"""
Run a multi-mutation comparison panel on the toy 1ZNF system.

This script executes multiple WT-vs-MUT pipelines and builds aggregate
comparison tables/plots across mutation types.
"""

from __future__ import annotations

import argparse
import csv
import json
import os
import shutil
from typing import Dict, List, Tuple

import matplotlib.pyplot as plt
import numpy as np

from topology_safe_pipeline import (
    BuildConfig,
    FieldConfig,
    LatentConfig,
    MDConfig,
    TEConfig,
    run_full_pipeline,
)


MUTATION_SCENARIOS: List[Tuple[str, List[str]]] = [
    ("snp_k2r", ["K2R"]),
    ("ins_r8_s9insa", ["R8_S9insA"]),
    ("delins_10_11_g", ["10_11delinsG"]),
    ("dup_q20", ["Q20dup"]),
]


def _parse_csv_tokens(values: List[str]) -> List[str]:
    out: List[str] = []
    for value in values:
        for token in value.split(","):
            token = token.strip()
            if token:
                out.append(token)
    return out


def _scenario_table(rows: List[Dict]) -> Dict[str, Dict[str, float]]:
    by_name: Dict[str, List[Dict]] = {}
    for row in rows:
        by_name.setdefault(row["scenario"], []).append(row)

    metrics = [
        "te_mut_p_to_b",
        "te_delta_mut_minus_wt",
        "te_mut_pvalue",
        "js_divergence",
        "gmm_kl_wt_to_mut",
        "susceptibility_delta_fro_norm",
    ]
    out: Dict[str, Dict[str, float]] = {}
    for name, items in by_name.items():
        entry: Dict[str, float] = {"replicas": float(len(items))}
        for metric in metrics:
            vals = np.asarray([float(item.get(metric, np.nan)) for item in items], dtype=float)
            entry[f"{metric}_mean"] = float(np.nanmean(vals))
            entry[f"{metric}_std"] = float(np.nanstd(vals))
        out[name] = entry
    return out


def _write_csv(rows: List[Dict], out_csv: str) -> None:
    if not rows:
        return
    keys = list(rows[0].keys())
    with open(out_csv, "w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=keys)
        writer.writeheader()
        writer.writerows(rows)


def _plot_panel(agg: Dict[str, Dict[str, float]], out_png: str) -> None:
    names = list(agg.keys())
    x = np.arange(len(names))

    te_delta_mean = np.array([agg[n]["te_delta_mut_minus_wt_mean"] for n in names], dtype=float)
    te_delta_std = np.array([agg[n]["te_delta_mut_minus_wt_std"] for n in names], dtype=float)
    js_mean = np.array([agg[n]["js_divergence_mean"] for n in names], dtype=float)
    js_std = np.array([agg[n]["js_divergence_std"] for n in names], dtype=float)
    sus_mean = np.array([agg[n]["susceptibility_delta_fro_norm_mean"] for n in names], dtype=float)
    sus_std = np.array([agg[n]["susceptibility_delta_fro_norm_std"] for n in names], dtype=float)
    p_mean = np.array([agg[n]["te_mut_pvalue_mean"] for n in names], dtype=float)

    fig, axes = plt.subplots(2, 2, figsize=(13, 8))

    axes[0, 0].bar(x, te_delta_mean, yerr=te_delta_std, color="#1f77b4", capsize=4)
    axes[0, 0].axhline(0.0, color="black", linewidth=1)
    axes[0, 0].set_xticks(x)
    axes[0, 0].set_xticklabels(names, rotation=20, ha="right")
    axes[0, 0].set_title("ΔTE (MUT-WT)")
    axes[0, 0].set_ylabel("nats")
    axes[0, 0].grid(alpha=0.2, axis="y")

    axes[0, 1].bar(x, js_mean, yerr=js_std, color="#d62728", capsize=4)
    axes[0, 1].set_xticks(x)
    axes[0, 1].set_xticklabels(names, rotation=20, ha="right")
    axes[0, 1].set_title("Distribution Shift (JS)")
    axes[0, 1].set_ylabel("JS divergence")
    axes[0, 1].grid(alpha=0.2, axis="y")

    axes[1, 0].bar(x, sus_mean, yerr=sus_std, color="#2ca02c", capsize=4)
    axes[1, 0].set_xticks(x)
    axes[1, 0].set_xticklabels(names, rotation=20, ha="right")
    axes[1, 0].set_title("Susceptibility Shift")
    axes[1, 0].set_ylabel("||ΔΓ||F")
    axes[1, 0].grid(alpha=0.2, axis="y")

    axes[1, 1].scatter(js_mean, te_delta_mean, s=180, c=sus_mean, cmap="viridis", edgecolor="black")
    for i, name in enumerate(names):
        axes[1, 1].annotate(name, (js_mean[i], te_delta_mean[i]), textcoords="offset points", xytext=(6, 6))
    axes[1, 1].set_xlabel("JS divergence")
    axes[1, 1].set_ylabel("ΔTE (MUT-WT)")
    axes[1, 1].set_title("Mutation Effect Map (color=||ΔΓ||F)")
    axes[1, 1].grid(alpha=0.25)

    text_lines = [f"{n}: p={p_mean[i]:.3f}" for i, n in enumerate(names)]
    axes[1, 1].text(
        0.03,
        0.03,
        "\n".join(text_lines),
        transform=axes[1, 1].transAxes,
        va="bottom",
        ha="left",
        fontsize=8,
        bbox={"facecolor": "white", "alpha": 0.8, "edgecolor": "#cccccc"},
    )

    fig.suptitle("Mutation Panel Comparison")
    fig.tight_layout()
    fig.savefig(out_png, dpi=220)
    plt.close(fig)


def main() -> None:
    parser = argparse.ArgumentParser(description="Run 1ZNF mutation comparison panel.")
    parser.add_argument("--reference-pdb", default="toy_data/1ZNF.pdb")
    parser.add_argument("--template-pdb", default="toy_data/1ZNF.pdb")
    parser.add_argument("--ligand-xml", default="toy_data/empty_ligand.xml")
    parser.add_argument("--ligand-resname", default="ZN")
    parser.add_argument("--template", default="1ZNFA")
    parser.add_argument("--chain-id", default="A")
    parser.add_argument("--replicas", type=int, default=2)
    parser.add_argument("--output-dir", default="mutation_panel_1znf")
    parser.add_argument("--num-models", type=int, default=4)
    parser.add_argument("--num-processors", type=int, default=1)
    parser.add_argument("--temperature-k", type=float, default=300.0)
    parser.add_argument("--equil-steps", type=int, default=2000)
    parser.add_argument("--prod-steps", type=int, default=20000)
    parser.add_argument("--report-interval", type=int, default=100)
    parser.add_argument("--no-solvent", action="store_true", help="Disable solvent and ions for dry/vacuum tests.")
    parser.add_argument(
        "--nonbonded-method",
        default="PME",
        help="PME/Ewald/CutoffPeriodic/CutoffNonPeriodic/NoCutoff.",
    )
    parser.add_argument("--nonbonded-cutoff-nm", type=float, default=1.0)
    parser.add_argument("--platform", default="CPU")
    parser.add_argument("--md-seed-base", type=int, default=1300)
    parser.add_argument("--rb-ang", type=float, default=6.0)
    parser.add_argument("--rp-ang", type=float, default=12.0)
    parser.add_argument("--grid-spacing-ang", type=float, default=3.0)
    parser.add_argument("--sigma-ang", type=float, default=3.0)
    parser.add_argument("--max-grid-points", type=int, default=64)
    parser.add_argument("--occupancy-only", action="store_true")
    parser.add_argument("--vamp-lag", type=int, default=4)
    parser.add_argument("--latent-b", type=int, default=6)
    parser.add_argument("--latent-p", type=int, default=6)
    parser.add_argument("--latent-l", type=int, default=3)
    parser.add_argument("--var-max-order", type=int, default=3)
    parser.add_argument("--te-surrogates", type=int, default=64)
    parser.add_argument("--te-seed-base", type=int, default=200)
    parser.add_argument(
        "--scenarios",
        action="append",
        default=None,
        help="Scenario name filter (repeat and/or comma-separated). "
        "Available: snp_k2r, ins_r8_s9insa, delins_10_11_g, dup_q20.",
    )
    args = parser.parse_args()

    os.makedirs(args.output_dir, exist_ok=True)
    template_code = args.template[:-1]
    all_rows: List[Dict] = []
    scenarios = MUTATION_SCENARIOS
    if args.scenarios:
        selected = set(_parse_csv_tokens(args.scenarios))
        scenarios = [item for item in MUTATION_SCENARIOS if item[0] in selected]
        if not scenarios:
            raise ValueError("No valid scenarios selected via --scenarios.")

    for scenario_index, (scenario_name, mutations) in enumerate(scenarios):
        for rep in range(1, args.replicas + 1):
            run_dir = os.path.join(args.output_dir, scenario_name, f"rep{rep}")
            os.makedirs(run_dir, exist_ok=True)
            seed_dir = os.path.join(run_dir, "model_build", "modeling_job")
            os.makedirs(seed_dir, exist_ok=True)
            shutil.copy2(args.template_pdb, os.path.join(seed_dir, f"{template_code}.pdb"))

            seed_modeller = 17 + scenario_index * 100 + rep
            seed_md = args.md_seed_base + scenario_index * 50 + rep * 3
            seed_te = args.te_seed_base + scenario_index * 10 + rep

            nonbonded_method = args.nonbonded_method
            if args.no_solvent and nonbonded_method.strip().upper() in {
                "PME",
                "EWALD",
                "CUTOFFPERIODIC",
            }:
                nonbonded_method = "CutoffNonPeriodic"

            build_cfg = BuildConfig(
                reference_pdb=args.reference_pdb,
                ligand_xml=args.ligand_xml,
                ligand_resnames=[args.ligand_resname],
                mutations=mutations,
                templates=[args.template],
                chain_id=args.chain_id,
                num_models=args.num_models,
                num_processors=args.num_processors,
                modeller_seed=seed_modeller,
            )
            md_cfg = MDConfig(
                temperature_k=args.temperature_k,
                add_solvent=not args.no_solvent,
                nonbonded_method=nonbonded_method,
                nonbonded_cutoff_nm=args.nonbonded_cutoff_nm,
                equilibration_steps=args.equil_steps,
                production_steps=args.prod_steps,
                report_interval=args.report_interval,
                platform=args.platform,
                random_seed=seed_md,
            )
            field_cfg = FieldConfig(
                rb_ang=args.rb_ang,
                rp_ang=args.rp_ang,
                grid_spacing_ang=args.grid_spacing_ang,
                sigma_ang=args.sigma_ang,
                max_grid_points=args.max_grid_points,
                include_velocity=not args.occupancy_only,
                remove_com=True,
            )
            latent_cfg = LatentConfig(
                lag=args.vamp_lag,
                m_b=args.latent_b,
                m_p=args.latent_p,
                m_l=args.latent_l,
                reg=1e-6,
            )
            te_cfg = TEConfig(
                max_order=args.var_max_order,
                surrogates=args.te_surrogates,
                random_seed=seed_te,
            )

            summary = run_full_pipeline(
                build_cfg=build_cfg,
                md_cfg=md_cfg,
                field_cfg=field_cfg,
                latent_cfg=latent_cfg,
                te_cfg=te_cfg,
                output_dir=run_dir,
            )
            analysis = summary["analysis"]
            dist = analysis["distribution_shift"]
            basin = analysis["basin_ddg"]["basins"]
            dominant = max(basin, key=lambda row: row["p_mut"])

            all_rows.append(
                {
                    "scenario": scenario_name,
                    "replica": rep,
                    "mutations": ",".join(mutations),
                    "te_mut_p_to_b": float(analysis["te_mut_p_to_b_given_l"]["te_driver_to_target"]),
                    "te_mut_pvalue": float(analysis["te_mut_p_to_b_given_l"]["surrogate_pvalue"]),
                    "te_delta_mut_minus_wt": float(analysis["te_delta_mut_minus_wt"]),
                    "js_divergence": float(dist.get("js_divergence", np.nan)),
                    "gmm_kl_wt_to_mut": float(dist.get("gmm_kl_wt_to_mut", np.nan)),
                    "susceptibility_delta_fro_norm": float(analysis["susceptibility_delta_fro_norm"]),
                    "dominant_basin": int(dominant["basin"]),
                    "dominant_basin_p_mut": float(dominant["p_mut"]),
                    "dominant_basin_ddg_kcal_mol": float(dominant["ddg_kcal_mol"]),
                }
            )

    out_csv = os.path.join(args.output_dir, "mutation_panel_metrics.csv")
    _write_csv(all_rows, out_csv)

    agg = _scenario_table(all_rows)
    out_json = os.path.join(args.output_dir, "mutation_panel_summary.json")
    with open(out_json, "w", encoding="utf-8") as handle:
        json.dump(agg, handle, indent=2)

    out_plot = os.path.join(args.output_dir, "mutation_panel_comparison.png")
    _plot_panel(agg, out_plot)

    payload = {
        "runs": len(all_rows),
        "scenarios": [name for name, _ in scenarios],
        "metrics_csv": out_csv,
        "summary_json": out_json,
        "comparison_plot": out_plot,
    }
    with open(os.path.join(args.output_dir, "panel_manifest.json"), "w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
    print(json.dumps(payload, indent=2))


if __name__ == "__main__":
    main()
