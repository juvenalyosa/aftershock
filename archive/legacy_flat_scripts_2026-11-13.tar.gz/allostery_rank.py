"""
Rank mutation-associated allosteric residue and region effects for one run.

This script is a post-processing layer over a completed pipeline run. It combines
structure shifts, trajectory dynamics, contact-network changes, and residue-level
TE/flow proxies into a residue ranking intended for allostery hypothesis
generation.
"""

from __future__ import annotations

import argparse
import csv
import json
import os
import re
from typing import Dict, List, Optional, Sequence, Tuple

os.environ.setdefault("MPLCONFIGDIR", os.path.join(os.environ.get("TMPDIR", "/tmp"), "pert-matplotlib"))

import matplotlib.pyplot as plt
import numpy as np

from plot_toy_analysis import (
    _aligned_ca_pair_records,
    _align_positions_and_velocities,
    _build_residue_motion_signals,
    _infer_mutation_anchor_from_structure,
    _indices_from_mut_residue_keys,
    _pairwise_te_matrix,
    _read_binding_residue_keys,
    _resolve_run_path,
    _relay_scores,
    _top_delta_edges,
    _top_paths,
    _write_binding_csv,
)
from topology_safe_pipeline import _tcl_braced_path


def _load_json(path: str) -> Dict:
    with open(path, "r", encoding="utf-8") as handle:
        return json.load(handle)


def _optional_run_path(run_dir: str, value: Optional[str]) -> Optional[str]:
    if not value:
        return None
    return _resolve_run_path(run_dir, value)


def _sample_frame_indices(n_frames: int, max_frames: Optional[int]) -> np.ndarray:
    if max_frames is None or max_frames <= 0 or n_frames <= max_frames:
        return np.arange(n_frames, dtype=int)
    return np.unique(np.linspace(0, n_frames - 1, int(max_frames), dtype=int))


def _rmsf_ang(positions_nm: np.ndarray) -> np.ndarray:
    centered = positions_nm - np.mean(positions_nm, axis=0, keepdims=True)
    return 10.0 * np.sqrt(np.mean(np.sum(centered * centered, axis=2), axis=0))


def _mean_speed_ang_per_ps(velocities_nmps: np.ndarray) -> np.ndarray:
    return 10.0 * np.mean(np.linalg.norm(velocities_nmps, axis=2), axis=0)


def _contact_change_score(
    wt_pos_nm: np.ndarray,
    mut_pos_nm: np.ndarray,
    threshold_ang: float,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    n_frames = min(int(wt_pos_nm.shape[0]), int(mut_pos_nm.shape[0]))
    n_res = min(int(wt_pos_nm.shape[1]), int(mut_pos_nm.shape[1]))
    if n_frames < 1 or n_res < 2:
        zeros = np.zeros(n_res, dtype=float)
        return zeros, np.zeros((n_res, n_res), dtype=float), np.zeros((n_res, n_res), dtype=float)

    threshold_nm = float(threshold_ang) * 0.1
    wt_counts = np.zeros((n_res, n_res), dtype=float)
    mut_counts = np.zeros((n_res, n_res), dtype=float)
    eye = np.eye(n_res, dtype=bool)

    for frame in range(n_frames):
        wt_xyz = wt_pos_nm[frame, :n_res, :]
        mut_xyz = mut_pos_nm[frame, :n_res, :]
        wt_d = np.linalg.norm(wt_xyz[:, None, :] - wt_xyz[None, :, :], axis=2)
        mut_d = np.linalg.norm(mut_xyz[:, None, :] - mut_xyz[None, :, :], axis=2)
        wt_contact = (wt_d <= threshold_nm) & (~eye)
        mut_contact = (mut_d <= threshold_nm) & (~eye)
        wt_counts += wt_contact.astype(float)
        mut_counts += mut_contact.astype(float)

    wt_prob = wt_counts / float(n_frames)
    mut_prob = mut_counts / float(n_frames)
    delta = mut_prob - wt_prob
    per_residue = np.sum(np.abs(delta), axis=1) / float(max(1, n_res - 1))
    return per_residue, wt_prob, mut_prob


def _normalize_nonnegative(values: np.ndarray) -> np.ndarray:
    arr = np.asarray(values, dtype=float)
    arr = np.where(np.isfinite(arr), arr, 0.0)
    arr = np.clip(arr, 0.0, None)
    positive = arr[arr > 1e-12]
    if positive.size == 0:
        return np.zeros_like(arr)
    scale = float(np.percentile(positive, 95.0))
    if scale <= 1e-12:
        scale = float(np.max(positive))
    if scale <= 1e-12:
        return np.zeros_like(arr)
    return np.clip(arr / scale, 0.0, 1.0)


def _aa_code_from_residue_key(key: str) -> str:
    match = re.match(r"([A-Za-z]+)", str(key).strip())
    return match.group(1).upper() if match else ""


def _explicit_sequence_difference_indices(pair_records: Sequence[Dict[str, object]]) -> List[int]:
    indices: List[int] = []
    for idx, rec in enumerate(pair_records):
        wt_key = str(rec.get("wt_residue_key", ""))
        mut_key = str(rec.get("mut_residue_key", ""))
        if _aa_code_from_residue_key(wt_key) != _aa_code_from_residue_key(mut_key):
            indices.append(idx)
    return indices


def _write_rows_csv(path: str, rows: Sequence[Dict[str, object]]) -> None:
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    if not rows:
        with open(path, "w", encoding="utf-8") as handle:
            handle.write("")
        return
    keys = list(rows[0].keys())
    with open(path, "w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=keys)
        writer.writeheader()
        writer.writerows(rows)


def _region_rows(
    residue_rows_sorted_by_index: Sequence[Dict[str, object]],
    region_window: int,
) -> List[Dict[str, object]]:
    if not residue_rows_sorted_by_index:
        return []
    window = max(1, int(region_window))
    out: List[Dict[str, object]] = []
    start = 0
    while start < len(residue_rows_sorted_by_index):
        chain = str(residue_rows_sorted_by_index[start]["chain"])
        end = start
        while end < len(residue_rows_sorted_by_index) and str(residue_rows_sorted_by_index[end]["chain"]) == chain:
            end += 1
        chain_rows = list(residue_rows_sorted_by_index[start:end])
        for chunk_start in range(0, len(chain_rows), window):
            chunk = chain_rows[chunk_start : chunk_start + window]
            if not chunk:
                continue
            scores = np.asarray([float(row["total_score"]) for row in chunk], dtype=float)
            top = max(chunk, key=lambda row: float(row["total_score"]))
            first = str(chunk[0]["residue"])
            last = str(chunk[-1]["residue"])
            out.append(
                {
                    "region": f"{chain}:{first}-{last}" if chain else f"{first}-{last}",
                    "chain": chain,
                    "residue_count": len(chunk),
                    "mean_total_score": float(np.mean(scores)),
                    "max_total_score": float(np.max(scores)),
                    "top_residue": str(top["residue"]),
                    "residues": ",".join(str(row["residue"]) for row in chunk),
                }
            )
        start = end
    out.sort(key=lambda row: (float(row["mean_total_score"]), float(row["max_total_score"])), reverse=True)
    for rank, row in enumerate(out, start=1):
        row["rank"] = rank
    return out


def _plot_ranked_residues(rows: Sequence[Dict[str, object]], out_png: str, top_n: int) -> None:
    top = list(rows[: max(1, int(top_n))])
    if not top:
        return
    top = list(reversed(top))
    labels = [str(row["node_label"]) for row in top]
    y = np.arange(len(top), dtype=float)

    structural = np.asarray([float(row["structural_component"]) for row in top], dtype=float)
    dynamics = np.asarray([float(row["dynamics_component"]) for row in top], dtype=float)
    contacts = np.asarray([float(row["contact_component"]) for row in top], dtype=float)
    te = np.asarray([float(row["te_component"]) for row in top], dtype=float)
    relay = np.asarray([float(row["relay_component"]) for row in top], dtype=float)
    target = np.asarray([float(row["target_coupling_component"]) for row in top], dtype=float)
    total = np.asarray([float(row["total_score"]) for row in top], dtype=float)

    fig, ax = plt.subplots(figsize=(10.5, max(4.5, 0.32 * len(top) + 1.5)))
    left = np.zeros_like(y)
    parts = [
        ("structure", structural, "#4C78A8"),
        ("dynamics", dynamics, "#F58518"),
        ("contacts", contacts, "#54A24B"),
        ("TE", te, "#B279A2"),
        ("relay", relay, "#E45756"),
        ("site coupling", target, "#72B7B2"),
    ]
    for name, values, color in parts:
        ax.barh(y, values, left=left, color=color, alpha=0.88, label=name)
        left += values
    ax.plot(total * max(float(np.max(left)), 1.0), y, "ko", markersize=3.5, label="total score")
    ax.set_yticks(y)
    ax.set_yticklabels(labels)
    ax.set_xlabel("Normalized component contribution")
    ax.set_title("Top Mutation-Associated Allosteric Residues")
    ax.grid(alpha=0.18, axis="x")
    ax.legend(frameon=False, ncol=3, fontsize=8)
    fig.tight_layout()
    os.makedirs(os.path.dirname(out_png) or ".", exist_ok=True)
    fig.savefig(out_png, dpi=220)
    plt.close(fig)


def _selection_from_rows(rows: Sequence[Dict[str, object]]) -> str:
    terms = []
    seen = set()
    for row in rows:
        chain = str(row["chain"]).strip()
        resid = str(row["resid"]).strip()
        key = (chain, resid)
        if key in seen:
            continue
        seen.add(key)
        if chain:
            terms.append(f"(chain {chain} and resid {resid})")
        else:
            terms.append(f"(resid {resid})")
    if not terms:
        return "none"
    return "protein and (" + " or ".join(terms) + ")"


def _write_hotspot_vmd(
    mut_pdb: str,
    mut_dcd: Optional[str],
    ligand_resname: str,
    rows: Sequence[Dict[str, object]],
    source_rows: Sequence[Dict[str, object]],
    target_rows: Sequence[Dict[str, object]],
    out_tcl: str,
    top_n: int,
) -> str:
    draw_rows = list(rows[: max(1, int(top_n))])
    hotspot_sel = _selection_from_rows(draw_rows)
    source_sel = _selection_from_rows(source_rows)
    target_sel = _selection_from_rows(target_rows)

    label_lines: List[str] = []
    for rank, row in enumerate(draw_rows[: min(20, len(draw_rows))], start=1):
        coord_nm = np.asarray(row["mut_coord_nm"], dtype=float)
        coord_ang = 10.0 * coord_nm
        label = f"{rank}. {row['node_label']} {float(row['total_score']):.3f}"
        label = label.replace("{", "").replace("}", "")
        label_lines.append(
            f"graphics $mid text {{{coord_ang[0]:.3f} {coord_ang[1]:.3f} {coord_ang[2]:.3f}}} {{{label}}} size 0.9 thickness 2"
        )

    lines = [
        "# Auto-generated allostery hotspot view for VMD",
        "display projection Orthographic",
        "display depthcue off",
        "axes location Off",
        "color Display Background white",
        f"set mut_pdb {_tcl_braced_path(mut_pdb)}",
        f"set mut_dcd {_tcl_braced_path(mut_dcd)}",
        f"set ligand_sel {{resname {ligand_resname.upper()}}}",
        f"set hotspot_sel {{{hotspot_sel}}}",
        f"set source_sel {{{source_sel}}}",
        f"set target_sel {{{target_sel}}}",
        "",
        "mol new $mut_pdb type pdb waitfor all",
        "set mid [molinfo top]",
        "if {[string length $mut_dcd] > 0 && [file exists $mut_dcd]} {",
        "    mol addfile $mut_dcd type dcd waitfor all molid $mid",
        "}",
        "mol delrep 0 $mid",
        "mol representation NewCartoon 0.22 24.0 4.2 0",
        "mol color ColorID 8",
        "mol selection {protein}",
        "mol material AOChalky",
        "mol addrep $mid",
        "",
        "mol representation Licorice 0.24 20.0 20.0",
        "mol color Name",
        "mol selection $ligand_sel",
        "mol material Glossy",
        "mol addrep $mid",
    ]
    if hotspot_sel != "none":
        lines += [
            "",
            "mol representation VDW 0.52 24.0",
            "mol color ColorID 1",
            "mol selection ($hotspot_sel) and name CA",
            "mol material Glossy",
            "mol addrep $mid",
            "mol representation Licorice 0.20 18.0 18.0",
            "mol color ColorID 1",
            "mol selection ($hotspot_sel) and not hydrogen",
            "mol material Glossy",
            "mol addrep $mid",
        ]
    if source_sel != "none":
        lines += [
            "",
            "mol representation VDW 0.68 24.0",
            "mol color ColorID 4",
            "mol selection ($source_sel) and name CA",
            "mol material Glossy",
            "mol addrep $mid",
        ]
    if target_sel != "none":
        lines += [
            "",
            "mol representation QuickSurf 1.0 0.5 1.0 1.0",
            "mol color ColorID 10",
            "mol selection $target_sel",
            "mol material Transparent",
            "mol addrep $mid",
        ]
    lines += [
        "",
        "graphics $mid color black",
        *label_lines,
        "display resetview",
        "puts \"Loaded allostery hotspot view.\"",
        "puts \"Red: top ranked allosteric residues. Yellow: mutation source hotspots. Cyan surface: target/binding site.\"",
    ]

    os.makedirs(os.path.dirname(out_tcl) or ".", exist_ok=True)
    with open(out_tcl, "w", encoding="utf-8") as handle:
        handle.write("\n".join(lines) + "\n")
    return out_tcl


def run_allostery_ranking(
    run_dir: str,
    ligand_resname: str,
    cutoff_ang: float,
    source_hotspots: int,
    top_edges_n: int,
    top_paths_n: int,
    top_residues: int,
    region_window: int,
    max_frames: Optional[int],
    contact_threshold_ang: float,
    output_dir: Optional[str] = None,
) -> Dict[str, object]:
    run_dir = os.path.abspath(run_dir)
    summary = _load_json(os.path.join(run_dir, "run_summary.json"))
    out_dir = output_dir or os.path.join(run_dir, "analysis")
    os.makedirs(out_dir, exist_ok=True)

    wt_pdb = _resolve_run_path(run_dir, summary["md"]["wt"]["prepared_pdb"])
    mut_pdb = _resolve_run_path(run_dir, summary["md"]["mut"]["prepared_pdb"])
    wt_traj_npz = _resolve_run_path(run_dir, summary["md"]["wt"]["traj_npz"])
    mut_traj_npz = _resolve_run_path(run_dir, summary["md"]["mut"]["traj_npz"])
    mut_dcd = _optional_run_path(run_dir, summary["md"]["mut"].get("traj_dcd"))

    binding_csv = os.path.join(out_dir, "binding_site_residues.csv")
    if not os.path.exists(binding_csv):
        _write_binding_csv(
            wt_pdb=wt_pdb,
            mut_pdb=mut_pdb,
            ligand_resname=ligand_resname,
            cutoff_ang=cutoff_ang,
            out_csv=binding_csv,
        )

    pair_records = _aligned_ca_pair_records(wt_pdb, mut_pdb)
    wt_idx = np.asarray([int(rec["wt_atom_index"]) for rec in pair_records], dtype=int)
    mut_idx = np.asarray([int(rec["mut_atom_index"]) for rec in pair_records], dtype=int)

    wt_data = np.load(wt_traj_npz)
    mut_data = np.load(mut_traj_npz)
    n_frames = min(int(wt_data["positions"].shape[0]), int(mut_data["positions"].shape[0]))
    frame_idx = _sample_frame_indices(n_frames, max_frames)
    if frame_idx.size < 10:
        raise ValueError("Need at least 10 sampled frames for allostery ranking.")

    wt_pos_raw = np.asarray(wt_data["positions"][frame_idx][:, wt_idx, :], dtype=float)
    wt_vel_raw = np.asarray(wt_data["velocities"][frame_idx][:, wt_idx, :], dtype=float)
    mut_pos_raw = np.asarray(mut_data["positions"][frame_idx][:, mut_idx, :], dtype=float)
    mut_vel_raw = np.asarray(mut_data["velocities"][frame_idx][:, mut_idx, :], dtype=float)

    wt_pos, wt_vel = _align_positions_and_velocities(wt_pos_raw, wt_vel_raw)
    mut_pos, mut_vel = _align_positions_and_velocities(mut_pos_raw, mut_vel_raw)
    signal_wt = _build_residue_motion_signals(wt_pos, wt_vel, velocity_weight=0.35)
    signal_mut = _build_residue_motion_signals(mut_pos, mut_vel, velocity_weight=0.35)

    _, hotspot_keys, disp_map_nm = _infer_mutation_anchor_from_structure(
        wt_pdb,
        mut_pdb,
        top_n=max(1, int(source_hotspots)),
    )
    binding_keys = _read_binding_residue_keys(binding_csv)
    source_idx = _indices_from_mut_residue_keys(pair_records, hotspot_keys)
    explicit_source_idx = _explicit_sequence_difference_indices(pair_records)
    source_idx = sorted(set(source_idx) | set(explicit_source_idx))
    target_idx = _indices_from_mut_residue_keys(pair_records, binding_keys)
    if not source_idx and pair_records:
        source_idx = [0]
    if not target_idx and len(pair_records) > 1:
        target_idx = [len(pair_records) - 1]
    target_idx = [idx for idx in target_idx if idx not in set(source_idx)] or target_idx

    te_wt = _pairwise_te_matrix(signal_wt, lag=1)
    te_mut = _pairwise_te_matrix(signal_mut, lag=1)
    te_delta = te_mut - te_wt
    te_delta_pos = np.clip(te_delta, 0.0, None)
    relay = _relay_scores(te_delta_pos, source_idx=source_idx, target_idx=target_idx)
    top_edges = _top_delta_edges(te_wt=te_wt, te_mut=te_mut, pair_records=pair_records, top_n=top_edges_n)
    top_paths = _top_paths(
        te_delta_pos=te_delta_pos,
        source_idx=source_idx,
        target_idx=target_idx,
        pair_records=pair_records,
        top_n=top_paths_n,
    )

    structural_shift_ang = np.asarray(
        [10.0 * float(disp_map_nm.get(str(rec["mut_residue_key"]), 0.0)) for rec in pair_records],
        dtype=float,
    )
    rmsf_wt = _rmsf_ang(wt_pos)
    rmsf_mut = _rmsf_ang(mut_pos)
    rmsf_delta_abs = np.abs(rmsf_mut - rmsf_wt)
    speed_wt = _mean_speed_ang_per_ps(wt_vel)
    speed_mut = _mean_speed_ang_per_ps(mut_vel)
    speed_delta_abs = np.abs(speed_mut - speed_wt)
    dynamics_raw = rmsf_delta_abs + 0.25 * speed_delta_abs
    contact_change, contact_wt, contact_mut = _contact_change_score(
        wt_pos_nm=wt_pos,
        mut_pos_nm=mut_pos,
        threshold_ang=contact_threshold_ang,
    )
    te_out_gain = np.sum(te_delta_pos, axis=1)
    te_in_gain = np.sum(te_delta_pos, axis=0)
    te_out_abs = np.sum(np.abs(te_delta), axis=1)
    te_in_abs = np.sum(np.abs(te_delta), axis=0)
    target_coupling = np.zeros(len(pair_records), dtype=float)
    if target_idx:
        tgt = np.asarray(target_idx, dtype=int)
        target_coupling = np.sum(te_delta_pos[:, tgt], axis=1) + np.sum(te_delta_pos[tgt, :], axis=0)

    structural_component = _normalize_nonnegative(structural_shift_ang)
    dynamics_component = _normalize_nonnegative(dynamics_raw)
    contact_component = _normalize_nonnegative(contact_change)
    te_component = _normalize_nonnegative(te_out_abs + te_in_abs)
    relay_component = _normalize_nonnegative(relay)
    target_coupling_component = _normalize_nonnegative(target_coupling)

    total_score = (
        0.15 * structural_component
        + 0.20 * dynamics_component
        + 0.20 * contact_component
        + 0.25 * te_component
        + 0.15 * relay_component
        + 0.05 * target_coupling_component
    )

    rows_by_index: List[Dict[str, object]] = []
    source_set = set(source_idx)
    target_set = set(target_idx)
    for idx, rec in enumerate(pair_records):
        row = {
            "index": idx,
            "node_label": str(rec["node_label"]),
            "chain": str(rec["chain_id"]),
            "resid": str(rec["resid"]),
            "residue": str(rec["mut_residue_key"]),
            "wt_residue": str(rec["wt_residue_key"]),
            "is_source_hotspot": idx in source_set,
            "is_target_site": idx in target_set,
            "structural_shift_ang": float(structural_shift_ang[idx]),
            "rmsf_wt_ang": float(rmsf_wt[idx]),
            "rmsf_mut_ang": float(rmsf_mut[idx]),
            "rmsf_delta_abs_ang": float(rmsf_delta_abs[idx]),
            "speed_wt_ang_per_ps": float(speed_wt[idx]),
            "speed_mut_ang_per_ps": float(speed_mut[idx]),
            "speed_delta_abs_ang_per_ps": float(speed_delta_abs[idx]),
            "contact_change": float(contact_change[idx]),
            "te_out_gain": float(te_out_gain[idx]),
            "te_in_gain": float(te_in_gain[idx]),
            "te_out_abs_delta": float(te_out_abs[idx]),
            "te_in_abs_delta": float(te_in_abs[idx]),
            "target_coupling_gain": float(target_coupling[idx]),
            "relay_score": float(relay[idx]),
            "structural_component": float(structural_component[idx]),
            "dynamics_component": float(dynamics_component[idx]),
            "contact_component": float(contact_component[idx]),
            "te_component": float(te_component[idx]),
            "relay_component": float(relay_component[idx]),
            "target_coupling_component": float(target_coupling_component[idx]),
            "total_score": float(total_score[idx]),
            "mut_coord_nm": np.asarray(rec["mut_coord_nm"], dtype=float).tolist(),
        }
        rows_by_index.append(row)

    rows_ranked = sorted(rows_by_index, key=lambda row: float(row["total_score"]), reverse=True)
    for rank, row in enumerate(rows_ranked, start=1):
        row["rank"] = rank
    csv_rows = []
    for row in rows_ranked:
        csv_row = dict(row)
        csv_row.pop("mut_coord_nm", None)
        csv_rows.append(csv_row)

    residue_csv = os.path.join(out_dir, "allostery_residue_scores.csv")
    _write_rows_csv(residue_csv, csv_rows)

    residue_json = os.path.join(out_dir, "allostery_residue_scores.json")
    with open(residue_json, "w", encoding="utf-8") as handle:
        json.dump(rows_ranked, handle, indent=2)

    region_csv = os.path.join(out_dir, "allostery_region_scores.csv")
    region_rows = _region_rows(rows_by_index, region_window=region_window)
    _write_rows_csv(region_csv, region_rows)

    contact_npz = os.path.join(out_dir, "allostery_contact_maps.npz")
    np.savez_compressed(
        contact_npz,
        node_label=np.asarray([str(row["node_label"]) for row in rows_by_index], dtype=str),
        contact_wt=contact_wt,
        contact_mut=contact_mut,
        contact_delta=contact_mut - contact_wt,
        te_wt=te_wt,
        te_mut=te_mut,
        te_delta=te_delta,
    )

    rank_plot = os.path.join(out_dir, "plot_allostery_residue_rank.png")
    _plot_ranked_residues(rows_ranked, rank_plot, top_n=top_residues)

    source_rows = [rows_by_index[i] for i in source_idx if 0 <= i < len(rows_by_index)]
    target_rows = [rows_by_index[i] for i in target_idx if 0 <= i < len(rows_by_index)]
    vmd_script = os.path.join(out_dir, "view_allostery_hotspots.vmd.tcl")
    _write_hotspot_vmd(
        mut_pdb=mut_pdb,
        mut_dcd=mut_dcd,
        ligand_resname=ligand_resname,
        rows=rows_ranked,
        source_rows=source_rows,
        target_rows=target_rows,
        out_tcl=vmd_script,
        top_n=top_residues,
    )

    network_json = os.path.join(out_dir, "allostery_network.json")
    network = {
        "run_dir": run_dir,
        "ligand_resname": ligand_resname,
        "binding_cutoff_ang": cutoff_ang,
        "contact_threshold_ang": contact_threshold_ang,
        "sampled_frames": int(frame_idx.size),
        "source_hotspot_count_requested": int(source_hotspots),
        "source_residues": [str(rows_by_index[i]["node_label"]) for i in source_idx if 0 <= i < len(rows_by_index)],
        "target_residues": [str(rows_by_index[i]["node_label"]) for i in target_idx if 0 <= i < len(rows_by_index)],
        "score_weights": {
            "structural_component": 0.15,
            "dynamics_component": 0.20,
            "contact_component": 0.20,
            "te_component": 0.25,
            "relay_component": 0.15,
            "target_coupling_component": 0.05,
        },
        "top_residues": [
            {k: v for k, v in row.items() if k != "mut_coord_nm"}
            for row in rows_ranked[: max(1, int(top_residues))]
        ],
        "top_regions": region_rows[: max(1, min(20, len(region_rows)))],
        "top_delta_edges": top_edges,
        "top_mutation_to_binding_paths": top_paths,
        "outputs": {
            "residue_csv": residue_csv,
            "residue_json": residue_json,
            "region_csv": region_csv,
            "contact_npz": contact_npz,
            "rank_plot": rank_plot,
            "vmd_script": vmd_script,
        },
    }
    with open(network_json, "w", encoding="utf-8") as handle:
        json.dump(network, handle, indent=2)

    manifest = {
        "residue_scores": residue_csv,
        "region_scores": region_csv,
        "network_json": network_json,
        "contact_maps": contact_npz,
        "rank_plot": rank_plot,
        "vmd_script": vmd_script,
    }
    manifest_path = os.path.join(out_dir, "allostery_manifest.json")
    with open(manifest_path, "w", encoding="utf-8") as handle:
        json.dump(manifest, handle, indent=2)

    return manifest


def main() -> None:
    parser = argparse.ArgumentParser(description="Rank allosteric residue effects for a completed run.")
    parser.add_argument("--run-dir", required=True, help="Pipeline run directory containing run_summary.json.")
    parser.add_argument("--ligand-resname", default="ZN")
    parser.add_argument("--cutoff-ang", type=float, default=6.0, help="Binding-site cutoff around ligand.")
    parser.add_argument("--source-hotspots", type=int, default=10, help="Number of mutation-proximal shifted residues to use as sources.")
    parser.add_argument("--top-edges", type=int, default=80, help="Number of positive TE-delta edges to store.")
    parser.add_argument("--top-paths", type=int, default=30, help="Number of mutation-to-site paths to store.")
    parser.add_argument("--top-residues", type=int, default=30, help="Number of residues to show in plot/VMD.")
    parser.add_argument("--region-window", type=int, default=5, help="Contiguous residue window size for region ranking.")
    parser.add_argument("--max-frames", type=int, default=2000, help="Evenly sample at most this many frames; <=0 uses all frames.")
    parser.add_argument("--contact-threshold-ang", type=float, default=8.0, help="C-alpha contact threshold.")
    parser.add_argument("--output-dir", default=None, help="Default: <run-dir>/analysis.")
    args = parser.parse_args()

    manifest = run_allostery_ranking(
        run_dir=args.run_dir,
        ligand_resname=args.ligand_resname,
        cutoff_ang=args.cutoff_ang,
        source_hotspots=args.source_hotspots,
        top_edges_n=args.top_edges,
        top_paths_n=args.top_paths,
        top_residues=args.top_residues,
        region_window=args.region_window,
        max_frames=None if args.max_frames <= 0 else args.max_frames,
        contact_threshold_ang=args.contact_threshold_ang,
        output_dir=args.output_dir,
    )
    print(json.dumps(manifest, indent=2))


if __name__ == "__main__":
    main()
