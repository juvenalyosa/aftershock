"""
Fast topology-flexible mutation/allostery scanner.

This is the fast, FoldX/DDMut-like layer for screening many mutation designs.
It avoids production MD and instead scores a WT/MUT structure pair using:

- sequence/topology-aware CA alignment, including insertions/deletions
- structural displacement after global alignment
- CA contact-network gain/loss
- local geometric strain
- graph connectivity from mutation source residues to binding-site targets
- pocket-site coupling proxies

The output is a fast hypothesis generator for SNP, multiple SNPs, INS, DEL,
INSDEL, DUP, and combinations. It is not a replacement for explicit MD
validation when making final mechanistic claims.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import os
import re
from collections import deque
from typing import Any, Dict, List, Optional, Sequence, Tuple

os.environ.setdefault("MPLCONFIGDIR", os.path.join(os.environ.get("TMPDIR", "/tmp"), "pert-matplotlib"))

import matplotlib.pyplot as plt
import numpy as np

from mutator import mutation_reference_map, needleman_wunsch_affine
from plot_toy_analysis import _binding_site_residues, _kabsch_align, _protein_ca_records, _resolve_run_path
from topology_safe_pipeline import _tcl_braced_path


def _load_json(path: str) -> Dict[str, Any]:
    with open(path, "r", encoding="utf-8") as handle:
        return json.load(handle)


def _parse_csv_tokens(values: Optional[Sequence[str]]) -> List[str]:
    out: List[str] = []
    for value in values or []:
        for token in str(value).split(","):
            token = token.strip()
            if token:
                out.append(token)
    return out


def _aa_code_from_residue_key(key: str) -> str:
    match = re.match(r"([A-Za-z]+)", str(key).strip())
    return match.group(1).upper() if match else ""


def _normalize(values: np.ndarray) -> np.ndarray:
    arr = np.asarray(values, dtype=float)
    arr = np.where(np.isfinite(arr), arr, 0.0)
    arr = np.clip(arr, 0.0, None)
    positive = arr[arr > 1e-12]
    if positive.size == 0:
        return np.zeros_like(arr)
    scale = float(np.percentile(positive, 95.0))
    if scale <= 1e-12:
        scale = float(np.max(positive))
    if scale <= 1e-12:
        return np.zeros_like(arr)
    return np.clip(arr / scale, 0.0, 1.0)


def _write_csv(path: str, rows: Sequence[Dict[str, Any]]) -> None:
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    if not rows:
        with open(path, "w", encoding="utf-8") as handle:
            handle.write("")
        return
    keys = list(rows[0].keys())
    with open(path, "w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=keys)
        writer.writeheader()
        writer.writerows(rows)


def _distance_matrix(coords: np.ndarray) -> np.ndarray:
    return np.linalg.norm(coords[:, None, :] - coords[None, :, :], axis=2)


def _bfs_distances(adj: np.ndarray, sources: Sequence[int]) -> np.ndarray:
    n = int(adj.shape[0])
    dist = np.full(n, np.inf, dtype=float)
    q: deque[int] = deque()
    for src in sources:
        if 0 <= int(src) < n and not np.isfinite(dist[int(src)]):
            dist[int(src)] = 0.0
            q.append(int(src))
    while q:
        cur = q.popleft()
        for nxt in np.where(adj[cur])[0].tolist():
            if not np.isfinite(dist[int(nxt)]):
                dist[int(nxt)] = dist[cur] + 1.0
                q.append(int(nxt))
    return dist


def _make_pairs_with_indels(wt_pdb: str, mut_pdb: str) -> Tuple[List[Dict[str, Any]], List[str]]:
    wt_records = _protein_ca_records(wt_pdb)
    mut_records = _protein_ca_records(mut_pdb)
    if len(wt_records) < 3 or len(mut_records) < 3:
        raise ValueError("Need at least 3 CA residues in both WT and MUT.")

    wt_seq = "".join(str(rec["aa1"]) for rec in wt_records)
    mut_seq = "".join(str(rec["aa1"]) for rec in mut_records)
    aln_wt, aln_mut = needleman_wunsch_affine(wt_seq, mut_seq)

    wt_idx = 0
    mut_idx = 0
    rows: List[Dict[str, Any]] = []
    deleted_wt_residues: List[str] = []
    deletion_neighbor_indices: List[int] = []

    for aa_w, aa_m in zip(aln_wt, aln_mut):
        wt_rec = None
        mut_rec = None
        if aa_w != "-":
            wt_rec = wt_records[wt_idx]
            wt_idx += 1
        if aa_m != "-":
            mut_rec = mut_records[mut_idx]
            mut_idx += 1

        if mut_rec is None:
            if wt_rec is not None:
                deleted_wt_residues.append(str(wt_rec["residue_key"]))
                if rows:
                    deletion_neighbor_indices.append(len(rows) - 1)
                if mut_idx < len(mut_records):
                    deletion_neighbor_indices.append(len(rows))
            continue

        chain_id = str(mut_rec["chain_id"]).strip()
        resid = str(mut_rec["resid"]).strip()
        mut_key = str(mut_rec["residue_key"]).strip()
        wt_key = str(wt_rec["residue_key"]).strip() if wt_rec is not None else ""
        node_label = f"{chain_id}:{mut_key}" if chain_id else mut_key
        rows.append(
            {
                "index": len(rows),
                "node_label": node_label,
                "chain": chain_id,
                "resid": resid,
                "residue": mut_key,
                "wt_residue": wt_key,
                "aa_mut": str(mut_rec["aa1"]),
                "aa_wt": str(wt_rec["aa1"]) if wt_rec is not None else "-",
                "is_insertion": wt_rec is None,
                "is_substitution": wt_rec is not None and str(wt_rec["aa1"]) != str(mut_rec["aa1"]),
                "is_deletion_neighbor": False,
                "mut_coord_nm": np.asarray(mut_rec["coord"], dtype=float),
                "wt_coord_nm": None if wt_rec is None else np.asarray(wt_rec["coord"], dtype=float),
            }
        )

    for idx in deletion_neighbor_indices:
        if 0 <= idx < len(rows):
            rows[idx]["is_deletion_neighbor"] = True
    return rows, sorted(set(deleted_wt_residues))


def _reference_start_from_records(records: Sequence[Dict[str, Any]]) -> int:
    if not records:
        return 1
    try:
        return int(str(records[0]["resid"]).strip())
    except ValueError:
        return 1


def _make_pairs_from_mutation_specs(
    wt_pdb: str,
    mut_pdb: str,
    mutation_specs: Sequence[str],
) -> Tuple[List[Dict[str, Any]], List[str]]:
    wt_records = _protein_ca_records(wt_pdb)
    mut_records = _protein_ca_records(mut_pdb)
    if len(wt_records) < 3 or len(mut_records) < 3:
        raise ValueError("Need at least 3 CA residues in both WT and MUT.")

    wt_seq = "".join(str(rec["aa1"]) for rec in wt_records)
    mut_seq = "".join(str(rec["aa1"]) for rec in mut_records)
    ref_start = _reference_start_from_records(wt_records)
    ref_map = mutation_reference_map(wt_seq, mutation_specs, start_pos=ref_start)
    expected_mut_seq = str(ref_map["mutated_sequence"])
    if expected_mut_seq != mut_seq:
        raise ValueError(
            "Mutation specs do not match mutant structure sequence. "
            f"Expected {expected_mut_seq}, found {mut_seq}."
        )

    wt_by_ref_pos = {ref_start + idx: rec for idx, rec in enumerate(wt_records)}
    deleted_ref_positions = [int(pos) for pos in ref_map["deleted_ref_positions"]]
    deleted_set = set(deleted_ref_positions)
    deleted_wt_residues = [
        str(wt_by_ref_pos[pos]["residue_key"])
        for pos in deleted_ref_positions
        if pos in wt_by_ref_pos
    ]

    rows: List[Dict[str, Any]] = []
    for idx, (mut_rec, map_row) in enumerate(zip(mut_records, ref_map["residue_map"])):
        ref_pos = map_row.get("ref_pos")
        wt_rec = wt_by_ref_pos.get(int(ref_pos)) if ref_pos is not None else None
        chain_id = str(mut_rec["chain_id"]).strip()
        resid = str(mut_rec["resid"]).strip()
        mut_key = str(mut_rec["residue_key"]).strip()
        wt_key = str(wt_rec["residue_key"]).strip() if wt_rec is not None else ""
        node_label = f"{chain_id}:{mut_key}" if chain_id else mut_key
        status = str(map_row.get("status", "unknown"))
        is_deleted_neighbor = False
        if ref_pos is not None:
            ref_pos_int = int(ref_pos)
            is_deleted_neighbor = (ref_pos_int - 1 in deleted_set) or (ref_pos_int + 1 in deleted_set)
        rows.append(
            {
                "index": idx,
                "node_label": node_label,
                "chain": chain_id,
                "resid": resid,
                "residue": mut_key,
                "wt_residue": wt_key,
                "aa_mut": str(mut_rec["aa1"]),
                "aa_wt": str(wt_rec["aa1"]) if wt_rec is not None else "-",
                "is_insertion": status in {"insertion", "duplication"} or wt_rec is None,
                "is_substitution": status in {"substitution", "delins"},
                "is_deletion_neighbor": is_deleted_neighbor or status == "delins",
                "is_mutation_source": bool(map_row.get("is_source", False)),
                "mutation_status": status,
                "mutation_spec": str(map_row.get("mutation", "")),
                "mut_coord_nm": np.asarray(mut_rec["coord"], dtype=float),
                "wt_coord_nm": None if wt_rec is None else np.asarray(wt_rec["coord"], dtype=float),
            }
        )
    return rows, sorted(set(deleted_wt_residues))


def _align_mutant_coords(rows: Sequence[Dict[str, Any]]) -> Tuple[np.ndarray, np.ndarray, float]:
    paired = [row for row in rows if row["wt_coord_nm"] is not None]
    if len(paired) < 3:
        raise ValueError("Need at least 3 aligned WT/MUT residue pairs for structural alignment.")
    wt = np.stack([np.asarray(row["wt_coord_nm"], dtype=float) for row in paired], axis=0)
    mut = np.stack([np.asarray(row["mut_coord_nm"], dtype=float) for row in paired], axis=0)
    rot, trans = _kabsch_align(mut, wt)
    all_mut = np.stack([np.asarray(row["mut_coord_nm"], dtype=float) for row in rows], axis=0)
    all_mut_aligned = (rot @ all_mut.T).T + trans[None, :]
    paired_aligned = (rot @ mut.T).T + trans[None, :]
    rmsd_ang = float(np.sqrt(np.mean(np.sum((paired_aligned - wt) ** 2, axis=1))) * 10.0)
    return all_mut_aligned, wt, rmsd_ang


def _binding_target_indices(
    rows: Sequence[Dict[str, Any]],
    wt_pdb: str,
    mut_pdb: str,
    ligand_resname: str,
    cutoff_ang: float,
) -> Tuple[List[int], List[str]]:
    wt_site = _binding_site_residues(wt_pdb, ligand_resname, cutoff_ang)
    mut_site = _binding_site_residues(mut_pdb, ligand_resname, cutoff_ang)
    site_keys = {row[1] for row in wt_site} | {row[1] for row in mut_site}
    indices: List[int] = []
    for idx, row in enumerate(rows):
        if str(row["residue"]) in site_keys or str(row["wt_residue"]) in site_keys:
            indices.append(idx)
    return sorted(set(indices)), sorted(site_keys)


def _plot_fast_scores(rows: Sequence[Dict[str, Any]], out_png: str, top_n: int) -> None:
    top = list(rows[: max(1, int(top_n))])
    if not top:
        return
    plot_rows = list(reversed(top))
    labels = [str(row["node_label"]) for row in plot_rows]
    y = np.arange(len(plot_rows), dtype=float)
    parts = [
        ("structure", np.asarray([float(row["structural_component"]) for row in plot_rows]), "#4C78A8"),
        ("contacts", np.asarray([float(row["contact_component"]) for row in plot_rows]), "#54A24B"),
        ("strain", np.asarray([float(row["strain_component"]) for row in plot_rows]), "#F58518"),
        ("path", np.asarray([float(row["path_component"]) for row in plot_rows]), "#B279A2"),
        ("pocket", np.asarray([float(row["pocket_component"]) for row in plot_rows]), "#72B7B2"),
        ("source", np.asarray([float(row["source_component"]) for row in plot_rows]), "#E45756"),
    ]
    fig, ax = plt.subplots(figsize=(10.5, max(4.5, 0.34 * len(plot_rows) + 1.5)))
    left = np.zeros(len(plot_rows), dtype=float)
    for name, values, color in parts:
        ax.barh(y, values, left=left, color=color, alpha=0.88, label=name)
        left += values
    ax.set_yticks(y)
    ax.set_yticklabels(labels)
    ax.set_xlabel("Normalized component contribution")
    ax.set_title("Fast Mutation/Allostery Residue Scan")
    ax.grid(alpha=0.18, axis="x")
    ax.legend(frameon=False, ncol=3, fontsize=8)
    fig.tight_layout()
    os.makedirs(os.path.dirname(out_png) or ".", exist_ok=True)
    fig.savefig(out_png, dpi=220)
    plt.close(fig)


def _selection_from_rows(rows: Sequence[Dict[str, Any]]) -> str:
    terms: List[str] = []
    seen = set()
    for row in rows:
        chain = str(row.get("chain", "")).strip()
        resid = str(row.get("resid", "")).strip()
        if not resid:
            continue
        key = (chain, resid)
        if key in seen:
            continue
        seen.add(key)
        if chain:
            terms.append(f"(chain {chain} and resid {resid})")
        else:
            terms.append(f"(resid {resid})")
    if not terms:
        return "none"
    return "protein and (" + " or ".join(terms) + ")"


def _write_vmd(
    mut_pdb: str,
    ligand_resname: str,
    rows_ranked: Sequence[Dict[str, Any]],
    source_rows: Sequence[Dict[str, Any]],
    target_rows: Sequence[Dict[str, Any]],
    out_tcl: str,
    top_n: int,
) -> str:
    top_rows = list(rows_ranked[: max(1, int(top_n))])
    hotspot_sel = _selection_from_rows(top_rows)
    source_sel = _selection_from_rows(source_rows)
    target_sel = _selection_from_rows(target_rows)
    lines = [
        "# Auto-generated fast allostery scan view for VMD",
        "display projection Orthographic",
        "display depthcue off",
        "axes location Off",
        "color Display Background white",
        f"set mut_pdb {_tcl_braced_path(mut_pdb)}",
        f"set ligand_sel {{resname {ligand_resname.upper()}}}",
        f"set hotspot_sel {{{hotspot_sel}}}",
        f"set source_sel {{{source_sel}}}",
        f"set target_sel {{{target_sel}}}",
        "mol new $mut_pdb type pdb waitfor all",
        "set mid [molinfo top]",
        "mol delrep 0 $mid",
        "mol representation NewCartoon 0.22 24.0 4.2 0",
        "mol color ColorID 8",
        "mol selection {protein}",
        "mol material AOChalky",
        "mol addrep $mid",
        "mol representation Licorice 0.24 20.0 20.0",
        "mol color Name",
        "mol selection $ligand_sel",
        "mol material Glossy",
        "mol addrep $mid",
        "mol representation VDW 0.55 24.0",
        "mol color ColorID 1",
        "mol selection ($hotspot_sel) and name CA",
        "mol material Glossy",
        "mol addrep $mid",
        "mol representation VDW 0.70 24.0",
        "mol color ColorID 4",
        "mol selection ($source_sel) and name CA",
        "mol material Glossy",
        "mol addrep $mid",
        "mol representation QuickSurf 1.0 0.5 1.0 1.0",
        "mol color ColorID 10",
        "mol selection $target_sel",
        "mol material Transparent",
        "mol addrep $mid",
        "graphics $mid color black",
    ]
    for row in top_rows[: min(20, len(top_rows))]:
        coord_ang = 10.0 * np.asarray(row["mut_coord_nm"], dtype=float)
        label = f"{row['rank']}. {row['node_label']} {float(row['fast_allostery_score']):.2f}"
        label = label.replace("{", "").replace("}", "")
        lines.append(
            f"graphics $mid text {{{coord_ang[0]:.3f} {coord_ang[1]:.3f} {coord_ang[2]:.3f}}} {{{label}}} size 0.85 thickness 2"
        )
    lines += [
        "display resetview",
        "puts \"Loaded fast allostery scan view.\"",
        "puts \"Red: top fast-ranked residues. Yellow: mutation source. Cyan: target/binding site.\"",
    ]
    os.makedirs(os.path.dirname(out_tcl) or ".", exist_ok=True)
    with open(out_tcl, "w", encoding="utf-8") as handle:
        handle.write("\n".join(lines) + "\n")
    return out_tcl


def run_fast_scan(
    wt_pdb: str,
    mut_pdb: str,
    ligand_resname: str,
    output_dir: str,
    mutation_label: str = "mutation",
    mutation_specs: Optional[Sequence[str]] = None,
    cutoff_ang: float = 6.0,
    contact_threshold_ang: float = 8.0,
    source_hotspots: int = 8,
    top_residues: int = 30,
) -> Dict[str, Any]:
    wt_pdb = os.path.abspath(wt_pdb)
    mut_pdb = os.path.abspath(mut_pdb)
    os.makedirs(output_dir, exist_ok=True)

    if mutation_specs:
        rows, deleted_wt_residues = _make_pairs_from_mutation_specs(wt_pdb, mut_pdb, mutation_specs)
    else:
        rows, deleted_wt_residues = _make_pairs_with_indels(wt_pdb, mut_pdb)
    mut_aligned, paired_wt_coords, ca_rmsd_ang = _align_mutant_coords(rows)
    mut_coords = np.stack([np.asarray(row["mut_coord_nm"], dtype=float) for row in rows], axis=0)
    mut_dist = _distance_matrix(mut_coords)
    mut_adj = (mut_dist <= contact_threshold_ang * 0.1) & (~np.eye(len(rows), dtype=bool))

    wt_coords_full = np.full_like(mut_aligned, np.nan)
    paired_indices = []
    for idx, row in enumerate(rows):
        if row["wt_coord_nm"] is not None:
            wt_coords_full[idx] = np.asarray(row["wt_coord_nm"], dtype=float)
            paired_indices.append(idx)
    structural_shift = np.zeros(len(rows), dtype=float)
    paired_mask = np.isfinite(wt_coords_full[:, 0])
    if np.any(paired_mask):
        structural_shift[paired_mask] = 10.0 * np.linalg.norm(
            mut_aligned[paired_mask] - wt_coords_full[paired_mask],
            axis=1,
        )
        insertion_default = max(float(np.percentile(structural_shift[paired_mask], 90.0)), 1.0)
    else:
        insertion_default = 1.0
    for idx, row in enumerate(rows):
        if row["wt_coord_nm"] is None:
            nearest = np.min(np.linalg.norm(mut_aligned[idx][None, :] - paired_wt_coords, axis=1))
            structural_shift[idx] = max(float(nearest * 10.0), insertion_default)

    wt_dist = np.full((len(rows), len(rows)), np.nan, dtype=float)
    valid = np.where(paired_mask)[0]
    if valid.size > 1:
        valid_wt = wt_coords_full[valid]
        wt_d_valid = _distance_matrix(valid_wt)
        wt_dist[np.ix_(valid, valid)] = wt_d_valid

    threshold_nm = contact_threshold_ang * 0.1
    wt_contact = np.isfinite(wt_dist) & (wt_dist <= threshold_nm) & (~np.eye(len(rows), dtype=bool))
    mut_contact = mut_adj
    contact_gain = np.sum(mut_contact & (~wt_contact), axis=1) / float(max(1, len(rows) - 1))
    contact_loss = np.sum(wt_contact & (~mut_contact), axis=1) / float(max(1, len(rows) - 1))
    contact_change = contact_gain + contact_loss

    union_contact = wt_contact | mut_contact
    strain = np.zeros(len(rows), dtype=float)
    abs_delta_d = np.abs(mut_dist - wt_dist)
    for idx in range(len(rows)):
        mask = union_contact[idx] & np.isfinite(abs_delta_d[idx])
        if np.any(mask):
            strain[idx] = 10.0 * float(np.mean(abs_delta_d[idx, mask]))
        elif rows[idx]["wt_coord_nm"] is None:
            strain[idx] = structural_shift[idx]

    target_idx, binding_keys = _binding_target_indices(
        rows=rows,
        wt_pdb=wt_pdb,
        mut_pdb=mut_pdb,
        ligand_resname=ligand_resname,
        cutoff_ang=cutoff_ang,
    )
    explicit_sources = [
        idx
        for idx, row in enumerate(rows)
        if bool(row.get("is_mutation_source", False))
        or bool(row["is_insertion"])
        or bool(row["is_substitution"])
        or bool(row["is_deletion_neighbor"])
    ]
    shifted_sources = np.argsort(-structural_shift)[: max(1, int(source_hotspots))].astype(int).tolist()
    source_idx = sorted(set(explicit_sources) | set(shifted_sources))
    if not source_idx:
        source_idx = [int(np.argmax(structural_shift))]
    if not target_idx:
        target_idx = [int(np.argmin(_bfs_distances(mut_adj, source_idx)))] if len(rows) else []

    dist_source = _bfs_distances(mut_adj, source_idx)
    dist_target = _bfs_distances(mut_adj, target_idx)
    graph_scale = 3.0
    path_bridge = np.exp(-np.where(np.isfinite(dist_source), dist_source, 99.0) / graph_scale) * np.exp(
        -np.where(np.isfinite(dist_target), dist_target, 99.0) / graph_scale
    )
    pocket_component = np.exp(-np.where(np.isfinite(dist_target), dist_target, 99.0) / graph_scale)
    source_component = np.zeros(len(rows), dtype=float)
    source_component[source_idx] = 1.0

    structural_component = _normalize(structural_shift)
    contact_component = _normalize(contact_change)
    strain_component = _normalize(strain)
    path_component = _normalize(path_bridge)
    pocket_component = _normalize(pocket_component)

    fast_score = (
        0.25 * structural_component
        + 0.20 * contact_component
        + 0.20 * strain_component
        + 0.20 * path_component
        + 0.10 * pocket_component
        + 0.05 * source_component
    )
    destabilization_proxy = 0.45 * _normalize(contact_loss) + 0.35 * strain_component + 0.20 * structural_component

    output_rows: List[Dict[str, Any]] = []
    source_set = set(source_idx)
    target_set = set(target_idx)
    for idx, row in enumerate(rows):
        out = {
            "index": idx,
            "node_label": row["node_label"],
            "chain": row["chain"],
            "resid": row["resid"],
            "residue": row["residue"],
            "wt_residue": row["wt_residue"],
            "aa_wt": row["aa_wt"],
            "aa_mut": row["aa_mut"],
            "is_source": idx in source_set,
            "is_target_site": idx in target_set,
            "is_insertion": bool(row["is_insertion"]),
            "is_substitution": bool(row["is_substitution"]),
            "is_deletion_neighbor": bool(row["is_deletion_neighbor"]),
            "is_mutation_source": bool(row.get("is_mutation_source", False)),
            "mutation_status": str(row.get("mutation_status", "")),
            "mutation_spec": str(row.get("mutation_spec", "")),
            "structural_shift_ang": float(structural_shift[idx]),
            "contact_gain_fraction": float(contact_gain[idx]),
            "contact_loss_fraction": float(contact_loss[idx]),
            "contact_change_fraction": float(contact_change[idx]),
            "local_strain_ang": float(strain[idx]),
            "graph_distance_from_source": None if not np.isfinite(dist_source[idx]) else float(dist_source[idx]),
            "graph_distance_to_target": None if not np.isfinite(dist_target[idx]) else float(dist_target[idx]),
            "structural_component": float(structural_component[idx]),
            "contact_component": float(contact_component[idx]),
            "strain_component": float(strain_component[idx]),
            "path_component": float(path_component[idx]),
            "pocket_component": float(pocket_component[idx]),
            "source_component": float(source_component[idx]),
            "destabilization_proxy": float(destabilization_proxy[idx]),
            "fast_allostery_score": float(fast_score[idx]),
            "mut_coord_nm": np.asarray(row["mut_coord_nm"], dtype=float).tolist(),
        }
        output_rows.append(out)

    ranked = sorted(output_rows, key=lambda r: float(r["fast_allostery_score"]), reverse=True)
    for rank, row in enumerate(ranked, start=1):
        row["rank"] = rank

    csv_rows = []
    for row in ranked:
        csv_row = dict(row)
        csv_row.pop("mut_coord_nm", None)
        csv_rows.append(csv_row)

    residue_csv = os.path.join(output_dir, "fast_allostery_residue_scores.csv")
    residue_json = os.path.join(output_dir, "fast_allostery_residue_scores.json")
    summary_json = os.path.join(output_dir, "fast_allostery_summary.json")
    plot_png = os.path.join(output_dir, "plot_fast_allostery_rank.png")
    vmd_tcl = os.path.join(output_dir, "view_fast_allostery.vmd.tcl")
    _write_csv(residue_csv, csv_rows)
    with open(residue_json, "w", encoding="utf-8") as handle:
        json.dump(ranked, handle, indent=2)
    _plot_fast_scores(ranked, plot_png, top_n=top_residues)

    source_rows = [output_rows[i] for i in source_idx if 0 <= i < len(output_rows)]
    target_rows = [output_rows[i] for i in target_idx if 0 <= i < len(output_rows)]
    _write_vmd(
        mut_pdb=mut_pdb,
        ligand_resname=ligand_resname,
        rows_ranked=ranked,
        source_rows=source_rows,
        target_rows=target_rows,
        out_tcl=vmd_tcl,
        top_n=top_residues,
    )

    top_scores = np.asarray([float(row["fast_allostery_score"]) for row in ranked[: min(10, len(ranked))]], dtype=float)
    target_scores = np.asarray([float(output_rows[i]["fast_allostery_score"]) for i in target_idx], dtype=float) if target_idx else np.asarray([], dtype=float)
    global_score = float(0.65 * (np.mean(top_scores) if top_scores.size else 0.0) + 0.35 * (np.mean(target_scores) if target_scores.size else 0.0))
    if global_score >= 0.55:
        predicted_effect = "high"
    elif global_score >= 0.35:
        predicted_effect = "moderate"
    elif global_score >= 0.20:
        predicted_effect = "low"
    else:
        predicted_effect = "minimal"

    summary = {
        "mutation_label": mutation_label,
        "wt_pdb": wt_pdb,
        "mut_pdb": mut_pdb,
        "ligand_resname": ligand_resname,
        "mutation_specs": list(mutation_specs or []),
        "binding_cutoff_ang": cutoff_ang,
        "contact_threshold_ang": contact_threshold_ang,
        "deleted_wt_residues": deleted_wt_residues,
        "mutation_source_residues": [
            row["node_label"] for row in output_rows if bool(row.get("is_mutation_source", False))
        ],
        "source_residues": [output_rows[i]["node_label"] for i in source_idx if 0 <= i < len(output_rows)],
        "target_residues": [output_rows[i]["node_label"] for i in target_idx if 0 <= i < len(output_rows)],
        "aligned_ca_rmsd_ang": ca_rmsd_ang,
        "global_fast_allostery_score": global_score,
        "predicted_allosteric_effect": predicted_effect,
        "mean_top10_destabilization_proxy": float(np.mean([float(row["destabilization_proxy"]) for row in ranked[: min(10, len(ranked))]])),
        "top_residues": [{k: v for k, v in row.items() if k != "mut_coord_nm"} for row in ranked[: max(1, int(top_residues))]],
        "outputs": {
            "residue_csv": residue_csv,
            "residue_json": residue_json,
            "summary_json": summary_json,
            "rank_plot": plot_png,
            "vmd_script": vmd_tcl,
        },
        "method_note": (
            "Fast structural/contact/allostery proxy. Use for screening and prioritization; "
            "validate prioritized designs with replicate MD or experimental data."
        ),
    }
    with open(summary_json, "w", encoding="utf-8") as handle:
        json.dump(summary, handle, indent=2)
    return summary


def _infer_from_run_dir(run_dir: str) -> Tuple[str, str, str]:
    run_dir = os.path.abspath(run_dir)
    summary = _load_json(os.path.join(run_dir, "run_summary.json"))
    wt_pdb = _resolve_run_path(run_dir, summary["structures"]["wt_with_ligand"])
    mut_pdb = _resolve_run_path(run_dir, summary["structures"]["mutant_with_ligand"])
    label = os.path.basename(os.path.dirname(run_dir)) + "/" + os.path.basename(run_dir)
    return wt_pdb, mut_pdb, label


def main() -> None:
    parser = argparse.ArgumentParser(description="Fast topology-flexible mutation/allostery scan without MD.")
    parser.add_argument("--run-dir", default=None, help="Completed run directory; infers WT/MUT structures.")
    parser.add_argument("--wt-pdb", default=None)
    parser.add_argument("--mut-pdb", default=None)
    parser.add_argument("--mutation-label", default=None)
    parser.add_argument(
        "--mutation-spec",
        action="append",
        default=None,
        help="Reference-coordinate mutation spec, repeat/comma separated. Enables exact source mapping for compound variants.",
    )
    parser.add_argument("--ligand-resname", default="ZN")
    parser.add_argument("--cutoff-ang", type=float, default=6.0)
    parser.add_argument("--contact-threshold-ang", type=float, default=8.0)
    parser.add_argument("--source-hotspots", type=int, default=8)
    parser.add_argument("--top-residues", type=int, default=30)
    parser.add_argument("--output-dir", default=None)
    args = parser.parse_args()

    if args.run_dir:
        wt_pdb, mut_pdb, inferred_label = _infer_from_run_dir(args.run_dir)
        mutation_label = args.mutation_label or inferred_label
        output_dir = args.output_dir or os.path.join(os.path.abspath(args.run_dir), "fast_scan")
    else:
        if not args.wt_pdb or not args.mut_pdb:
            raise SystemExit("Provide --run-dir or both --wt-pdb and --mut-pdb.")
        wt_pdb = args.wt_pdb
        mut_pdb = args.mut_pdb
        mutation_label = args.mutation_label or "mutation"
        output_dir = args.output_dir or "fast_allostery_scan"

    summary = run_fast_scan(
        wt_pdb=wt_pdb,
        mut_pdb=mut_pdb,
        ligand_resname=args.ligand_resname,
        output_dir=os.path.abspath(output_dir),
        mutation_label=mutation_label,
        mutation_specs=_parse_csv_tokens(args.mutation_spec),
        cutoff_ang=args.cutoff_ang,
        contact_threshold_ang=args.contact_threshold_ang,
        source_hotspots=args.source_hotspots,
        top_residues=args.top_residues,
    )
    print(json.dumps(summary["outputs"], indent=2))


if __name__ == "__main__":
    main()
