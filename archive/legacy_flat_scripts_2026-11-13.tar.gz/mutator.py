"""
Protein Sequence Mutator 

The program applies specified mutations to a protein sequence and verifies the
changes by aligning the original sequence with the mutated one. This repaired
version uses a more advanced alignment algorithm (Needleman-Wunsch with
affine gap penalty) to produce clearer, more intuitive alignments for complex
mutations.

author = "El_Dryosa"
email = ""
version = "1.0"
"""
import re


class MutationError(Exception):
    """
    Raised when a requested mutation cannot be parsed or does not
    match the reference sequence (non-existent position, AA mismatch, etc.).

    This is intentionally a normal Python exception rather than an
    immediate program exit. Library / package code should *raise*
    MutationError and let the top-level application decide whether to:

        - catch it and handle/report the problem, or
        - not catch it, in which case the process will stop with a traceback.

    Example (recommended in a CLI script):

        from mutator import mutate_sequence, MutationError

        try:
            mutated = mutate_sequence(seq, mutations, start_pos)
        except MutationError as exc:
            print(f"ERROR: {exc}")
            raise SystemExit(1)
    """
    pass

# =============================================================================
#  1. HELPER FUNCTIONS FOR SEQUENCE MANIPULATION
# =============================================================================

def convert_to_dict(sequence, start_pos):
    """
    Converts a sequence string to a dictionary mapping position numbers to amino acids.
    This data structure is ideal for mutations because it handles insertions and
    deletions without needing to manually re-calculate list indices.
    
    Example: "AGK", start_pos=1 -> {1: 'A', 2: 'G', 3: 'K'}
    """
    return {i + start_pos: aa for i, aa in enumerate(sequence)}

def convert_to_sequence(aa_dict):
    """
    Converts an amino acid dictionary back to a continuous sequence string.
    It correctly handles any gaps in position numbers by creating a contiguous
    string from the minimum to the maximum position.
    """
    if not aa_dict:
        return ""
    # Determine the full range of the sequence after mutations.
    min_pos = min(aa_dict.keys())
    max_pos = max(aa_dict.keys())
    # Rebuild the string, getting the amino acid for each position or an empty string if a position was deleted.
    return ''.join(aa_dict.get(i, '') for i in range(min_pos, max_pos + 1))

# =============================================================================
#  2. CORE MUTATION LOGIC
# =============================================================================

def _normalize_mutation_token(mutation):
    raw_mutation = str(mutation).strip()
    if not raw_mutation:
        raise MutationError("Empty mutation token.")
    return raw_mutation, raw_mutation.upper().replace("INSDEL", "DELINS")


def _parse_mutation(mutation):
    raw_mutation, normalized = _normalize_mutation_token(mutation)

    snp_match = re.match(r'^([A-Z])(\d+)([A-Z])$', normalized)
    if snp_match:
        old_aa, pos, new_aa = snp_match.groups()
        pos = int(pos)
        return {
            "kind": "snp",
            "raw": raw_mutation,
            "start": pos,
            "end": pos,
            "old_aa": old_aa,
            "new_aa": new_aa,
        }

    range_del_match = re.match(r'^([A-Z]?)(\d+)_([A-Z]?)(\d+)DEL$', normalized)
    if range_del_match:
        start_aa, start_pos, end_aa, end_pos = range_del_match.groups()
        return {
            "kind": "del",
            "raw": raw_mutation,
            "start": int(start_pos),
            "end": int(end_pos),
            "start_aa": start_aa,
            "end_aa": end_aa,
        }
    single_del_match = re.match(r'^([A-Z]?)(\d+)DEL$', normalized)
    if single_del_match:
        start_aa, start_pos = single_del_match.groups()
        start_pos = int(start_pos)
        return {
            "kind": "del",
            "raw": raw_mutation,
            "start": start_pos,
            "end": start_pos,
            "start_aa": start_aa,
            "end_aa": start_aa,
        }

    delins_match = re.match(r'^([A-Z]?)(\d+)(?:_([A-Z]?)(\d+))?DELINS([A-Z]+)$', normalized)
    if delins_match:
        start_aa, start_pos, end_aa, end_pos, insertion = delins_match.groups()
        start_pos = int(start_pos)
        end_pos = int(end_pos) if end_pos else start_pos
        return {
            "kind": "delins",
            "raw": raw_mutation,
            "start": start_pos,
            "end": end_pos,
            "start_aa": start_aa,
            "end_aa": end_aa or start_aa,
            "insertion": insertion,
        }

    ins_match = re.match(r'^([A-Z]?)(\d+)_([A-Z]?)(\d+)INS([A-Z]+)$', normalized)
    if ins_match:
        left_aa, left_pos, right_aa, right_pos, insertion = ins_match.groups()
        return {
            "kind": "ins",
            "raw": raw_mutation,
            "start": int(left_pos),
            "end": int(left_pos),
            "right_pos": int(right_pos),
            "left_aa": left_aa,
            "right_aa": right_aa,
            "insertion": insertion,
        }

    range_dup_match = re.match(r'^([A-Z]?)(\d+)_([A-Z]?)(\d+)DUP$', normalized)
    if range_dup_match:
        start_aa, start_pos, end_aa, end_pos = range_dup_match.groups()
        return {
            "kind": "dup",
            "raw": raw_mutation,
            "start": int(start_pos),
            "end": int(end_pos),
            "start_aa": start_aa,
            "end_aa": end_aa,
        }
    single_dup_match = re.match(r'^([A-Z]?)(\d+)DUP$', normalized)
    if single_dup_match:
        start_aa, start_pos = single_dup_match.groups()
        start_pos = int(start_pos)
        return {
            "kind": "dup",
            "raw": raw_mutation,
            "start": start_pos,
            "end": start_pos,
            "start_aa": start_aa,
            "end_aa": start_aa,
        }

    raise MutationError(f"Could not parse mutation: '{raw_mutation}'.")


def _validate_range(aa_dict, start, end, raw_mutation):
    if end < start:
        raise MutationError(f"Mutation {raw_mutation} has an invalid range ({start}>{end}).")
    missing = [str(pos) for pos in range(start, end + 1) if pos not in aa_dict]
    if missing:
        raise MutationError(
            f"Mutation {raw_mutation} references missing position(s): {', '.join(missing)}."
        )


def _validate_residue(aa_dict, pos, expected_aa, raw_mutation, label):
    if expected_aa and aa_dict.get(pos) != expected_aa:
        raise MutationError(
            f"Mutation {raw_mutation} mismatch at {label} position {pos}: "
            f"found '{aa_dict.get(pos)}' but expected '{expected_aa}'."
        )


def _validate_operation(op, aa_dict):
    kind = op["kind"]
    raw = op["raw"]
    if kind == "ins":
        left_pos = op["start"]
        right_pos = op["right_pos"]
        if right_pos != left_pos + 1:
            raise MutationError(f"Insertion {raw} must be between adjacent reference positions.")
        _validate_range(aa_dict, left_pos, left_pos, raw)
        _validate_range(aa_dict, right_pos, right_pos, raw)
        _validate_residue(aa_dict, left_pos, op.get("left_aa", ""), raw, "left")
        _validate_residue(aa_dict, right_pos, op.get("right_aa", ""), raw, "right")
        return

    _validate_range(aa_dict, op["start"], op["end"], raw)
    if kind == "snp":
        _validate_residue(aa_dict, op["start"], op["old_aa"], raw, "substitution")
    else:
        _validate_residue(aa_dict, op["start"], op.get("start_aa", ""), raw, "start")
        _validate_residue(aa_dict, op["end"], op.get("end_aa", ""), raw, "end")


def _prepare_operations(ops):
    replacement_by_start = {}
    insertion_after = {}
    duplication_after = {}
    occupied_by = {}
    deleted_or_replaced_positions = set()

    for op in ops:
        kind = op["kind"]
        if kind == "ins":
            insertion_after.setdefault(op["start"], []).append(op)
            continue

        interval = set(range(op["start"], op["end"] + 1))
        overlap = sorted(pos for pos in interval if pos in occupied_by)
        if overlap:
            first = overlap[0]
            raise MutationError(
                f"Mutation {op['raw']} overlaps mutation {occupied_by[first]} at reference position {first}."
            )
        for pos in interval:
            occupied_by[pos] = op["raw"]

        if kind == "dup":
            duplication_after.setdefault(op["end"], []).append(op)
        else:
            replacement_by_start[op["start"]] = op
            if kind in {"del", "delins"}:
                deleted_or_replaced_positions.update(interval)

    for pos, insertions in insertion_after.items():
        if pos in deleted_or_replaced_positions:
            names = ", ".join(op["raw"] for op in insertions)
            raise MutationError(f"Insertion after deleted/replaced position {pos} is ambiguous: {names}.")

    return replacement_by_start, insertion_after, duplication_after


def mutate_sequence(sequence, mutations, start_pos=1):
    """
    Applies mutations to a protein sequence using reference coordinates.

    Args:
        sequence (str): The original amino acid sequence.
        mutations (list): A list of mutations in a simplified HGVS-like format.
                          Supported formats:
                          - Substitution: "A123G"
                          - Deletion: "A10del", "10_12del"
                          - Insertion: "A10_B11insGGG"
                          - Deletion-Insertion: "A10delinsGGG", "10_12delinsGGG"
                            ("insdel" is accepted as an alias)
                          - Duplication: "A10dup", "10_12dup"
                          Operation names are case-insensitive.
                          In a multi-mutation list, positions are interpreted
                          against the original/reference sequence rather than
                          shifted after each earlier indel.
        start_pos (int): The starting position number of the sequence (e.g., 1 for 1-based indexing).

    Returns:
        str: The mutated sequence.
    """
    sequence = str(sequence).strip().upper()
    aa_dict = convert_to_dict(sequence, start_pos)
    if not mutations:
        return sequence

    ops = [_parse_mutation(mutation) for mutation in mutations]
    for op in ops:
        _validate_operation(op, aa_dict)
    replacement_by_start, insertion_after, duplication_after = _prepare_operations(ops)

    result = []
    min_pos = start_pos
    max_pos = start_pos + len(sequence) - 1
    pos = min_pos
    while pos <= max_pos:
        op = replacement_by_start.get(pos)
        emitted_reference_pos = None
        if op and op["kind"] == "snp":
            result.append(op["new_aa"])
            emitted_reference_pos = pos
            pos += 1
        elif op and op["kind"] == "del":
            pos = op["end"] + 1
            continue
        elif op and op["kind"] == "delins":
            result.extend(op["insertion"])
            pos = op["end"] + 1
            continue
        else:
            result.append(aa_dict[pos])
            emitted_reference_pos = pos
            pos += 1

        for insertion in insertion_after.get(emitted_reference_pos, []):
            result.extend(insertion["insertion"])
        for duplication in duplication_after.get(emitted_reference_pos, []):
            result.extend(aa_dict[i] for i in range(duplication["start"], duplication["end"] + 1))

    return "".join(result)


def mutation_reference_map(sequence, mutations, start_pos=1):
    """
    Return the mutated sequence plus per-mutant-residue reference mapping.

    This is used by structure-level scanners so compound indels/duplications
    are interpreted by reference coordinates instead of by ambiguous sequence
    realignment alone.
    """
    sequence = str(sequence).strip().upper()
    aa_dict = convert_to_dict(sequence, start_pos)
    ops = [_parse_mutation(mutation) for mutation in mutations]
    for op in ops:
        _validate_operation(op, aa_dict)
    replacement_by_start, insertion_after, duplication_after = _prepare_operations(ops)

    rows = []
    deleted_ref_positions = []
    min_pos = start_pos
    max_pos = start_pos + len(sequence) - 1
    pos = min_pos
    while pos <= max_pos:
        op = replacement_by_start.get(pos)
        emitted_reference_pos = None
        if op and op["kind"] == "snp":
            rows.append(
                {
                    "mut_aa": op["new_aa"],
                    "ref_pos": pos,
                    "ref_span": [pos, pos],
                    "status": "substitution",
                    "is_source": True,
                    "mutation": op["raw"],
                }
            )
            emitted_reference_pos = pos
            pos += 1
        elif op and op["kind"] == "del":
            deleted_ref_positions.extend(range(op["start"], op["end"] + 1))
            pos = op["end"] + 1
            continue
        elif op and op["kind"] == "delins":
            deleted_ref_positions.extend(range(op["start"], op["end"] + 1))
            for i, aa in enumerate(op["insertion"]):
                rows.append(
                    {
                        "mut_aa": aa,
                        "ref_pos": op["start"] if i == 0 else None,
                        "ref_span": [op["start"], op["end"]],
                        "status": "delins",
                        "is_source": True,
                        "mutation": op["raw"],
                    }
                )
            pos = op["end"] + 1
            continue
        else:
            rows.append(
                {
                    "mut_aa": aa_dict[pos],
                    "ref_pos": pos,
                    "ref_span": [pos, pos],
                    "status": "unchanged",
                    "is_source": False,
                    "mutation": "",
                }
            )
            emitted_reference_pos = pos
            pos += 1

        for insertion in insertion_after.get(emitted_reference_pos, []):
            for aa in insertion["insertion"]:
                rows.append(
                    {
                        "mut_aa": aa,
                        "ref_pos": None,
                        "ref_span": [insertion["start"], insertion["right_pos"]],
                        "status": "insertion",
                        "is_source": True,
                        "mutation": insertion["raw"],
                    }
                )
        for duplication in duplication_after.get(emitted_reference_pos, []):
            for ref_pos in range(duplication["start"], duplication["end"] + 1):
                rows.append(
                    {
                        "mut_aa": aa_dict[ref_pos],
                        "ref_pos": ref_pos,
                        "ref_span": [duplication["start"], duplication["end"]],
                        "status": "duplication",
                        "is_source": True,
                        "mutation": duplication["raw"],
                    }
                )

    return {
        "mutated_sequence": "".join(row["mut_aa"] for row in rows),
        "residue_map": rows,
        "deleted_ref_positions": deleted_ref_positions,
    }

# =============================================================================
#  3. ALIGNMENT AND VERIFICATION
# =============================================================================

def needleman_wunsch_affine(seq1, seq2, match_score=1, mismatch_score=-1, gap_open=-10, gap_extend=-1):
    """
    Performs global alignment using Needleman-Wunsch with an affine gap penalty.
    This is more biologically realistic than a simple linear gap penalty because it
    penalizes opening a new gap (e.g., an insertion/deletion event) more heavily
    than extending an existing gap.
    """
    n, m = len(seq1), len(seq2)
    
    # --- DYNAMIC PROGRAMMING (DP) TABLES ---
    # M:  Score ending with a match/mismatch between seq1[i] and seq2[j].
    # Ix: Score ending with a gap in seq2 (deletion from seq1).
    # Iy: Score ending with a gap in seq1 (insertion into seq1).
    M = [[0] * (m + 1) for _ in range(n + 1)]
    Ix = [[0] * (m + 1) for _ in range(n + 1)]
    Iy = [[0] * (m + 1) for _ in range(n + 1)]
    
    # --- POINTER TABLES (for backtracking) ---
    # These tables store the path taken to achieve the optimal score at each cell.
    Ptr_M = [[None] * (m + 1) for _ in range(n + 1)]
    Ptr_Ix = [[None] * (m + 1) for _ in range(n + 1)]
    Ptr_Iy = [[None] * (m + 1) for _ in range(n + 1)]

    # --- INITIALIZATION ---
    # Initialize the first row and column. A match (M) is impossible if one sequence is empty.
    for i in range(1, n + 1):
        M[i][0], Iy[i][0] = -float('inf'), -float('inf')
        Ix[i][0] = gap_open + (i - 1) * gap_extend # Cost of a gap of length i in seq2.
    for j in range(1, m + 1):
        M[0][j], Ix[0][j] = -float('inf'), -float('inf')
        Iy[0][j] = gap_open + (j - 1) * gap_extend # Cost of a gap of length j in seq1.

    # --- FILL DP TABLES ---
    for i in range(1, n + 1):
        for j in range(1, m + 1):
            score = match_score if seq1[i-1] == seq2[j-1] else mismatch_score
            
            # Calculate score for M(i,j): coming from a previous match, insertion, or deletion.
            m_scores = { 'M': M[i-1][j-1], 'Ix': Ix[i-1][j-1], 'Iy': Iy[i-1][j-1] }
            best_prev_matrix = max(m_scores, key=m_scores.get)
            M[i][j] = score + m_scores[best_prev_matrix]
            Ptr_M[i][j] = best_prev_matrix

            # Calculate score for Ix(i,j): either opening a new gap or extending an old one.
            score_open_x = M[i-1][j] + gap_open
            score_extend_x = Ix[i-1][j] + gap_extend
            if score_open_x > score_extend_x:
                Ix[i][j] = score_open_x
                Ptr_Ix[i][j] = 'M' # Came from the Match matrix.
            else:
                Ix[i][j] = score_extend_x
                Ptr_Ix[i][j] = 'Ix' # Came from the Ix matrix (extending gap).

            # Calculate score for Iy(i,j): either opening a new gap or extending an old one.
            score_open_y = M[i][j-1] + gap_open
            score_extend_y = Iy[i][j-1] + gap_extend
            if score_open_y > score_extend_y:
                Iy[i][j] = score_open_y
                Ptr_Iy[i][j] = 'M' # Came from the Match matrix.
            else:
                Iy[i][j] = score_extend_y
                Ptr_Iy[i][j] = 'Iy' # Came from the Iy matrix (extending gap).

    # --- BACKTRACKING ---
    # Start from the bottom-right corner and trace back to the top-left using the pointers.
    align1, align2 = "", ""
    i, j = n, m
    
    # Determine which matrix (M, Ix, or Iy) had the highest score in the last cell.
    last_scores = {'M': M[i][j], 'Ix': Ix[i][j], 'Iy': Iy[i][j]}
    matrix = max(last_scores, key=last_scores.get)

    while i > 0 or j > 0:
        if matrix == 'M': # A match or mismatch step.
            align1 = seq1[i-1] + align1
            align2 = seq2[j-1] + align2
            matrix = Ptr_M[i][j] # Get the previous matrix from the pointer.
            i -= 1
            j -= 1
        elif matrix == 'Ix': # A deletion step (gap in seq2).
            align1 = seq1[i-1] + align1
            align2 = "-" + align2
            matrix = Ptr_Ix[i][j]
            i -= 1
        elif matrix == 'Iy': # An insertion step (gap in seq1).
            align1 = "-" + align1
            align2 = seq2[j-1] + align2
            matrix = Ptr_Iy[i][j]
            j -= 1
            
    return align1, align2

def verify_and_print_alignment(original_seq, mutated_seq, context_chars=20):
    """
    Aligns two sequences and prints a formatted, easy-to-read view of the differences,
    providing context around the mutated region.
    """
    print("\nAlignment Verification (Original vs. Mutated):")
    
    # Align the sequences to find the optimal alignment including gaps.
    aligned_orig, aligned_mut = needleman_wunsch_affine(original_seq, mutated_seq)
    
    # Find all indices where the aligned sequences differ.
    diff_indices = [i for i, (c1, c2) in enumerate(zip(aligned_orig, aligned_mut)) if c1 != c2]
            
    if not diff_indices:
        print("Sequences are identical. No mutations were effectively applied.")
        return

    # Determine a window around the differences to display for context.
    start_index = max(0, diff_indices[0] - context_chars)
    end_index = min(len(aligned_orig), diff_indices[-1] + context_chars + 1)

    # Extract the snippets of the alignment to be printed.
    orig_snippet = aligned_orig[start_index:end_index]
    mut_snippet = aligned_mut[start_index:end_index]
    
    # Create a "match bar" to visually highlight matches (|) and mismatches ( ).
    match_bar = "".join("|" if c1 == c2 else " " for c1, c2 in zip(orig_snippet, mut_snippet))

    # Print the final, formatted output.
    print(f"Displaying alignment from index {start_index} to {end_index}:")
    print(f"{'Original:':<10} {orig_snippet}")
    print(f"{'':<10} {match_bar}")
    print(f"{'Mutated:':<10} {mut_snippet}")


# =============================================================================
#  4. EXAMPLE USAGE (COMMENTED OUT)
# =============================================================================

# To run a test, you can uncomment the following lines:
# original_sequence = "APNQALLRILKETEFKKIKVLGSGAFGTVYKGLWIPEGEKVKIPVAIKELREATSPKANKEILDEAYVMASVDNPHVCRLLGICLTSTVQLITQLMPFGCLLDYVREHKDNIGSQYLLNWCVQIAKGMNYLEDRRLVHRDLAARNVLVKTPQHVKITDFGLAKLLGAEEKEYHAEGGKVPIKWMALESILHRIYTHQSDVWSYGVTVWELMTFGSKPYDGIPASEISSILEKGERLPQPPICTIDVYMIMVKCWMIDADSRPKFRELIIEFSKMARDPQRYLVIQGDERMHLPSPTDSNFYRALMDEEDMDDVVDADEY"
# start_pos = 698

# --- Test Case: A complex deletion-insertion and a failing substitution ---
# mutations = ['L747_M753delinsS','A755D']
# print(f"Applying mutations: {mutations}")
# mutated_sequence = mutate_sequence(original_sequence, mutations, start_pos)

# print(f"\nOriginal sequence length: {len(original_sequence)}")
# print(f"Mutated sequence length:  {len(mutated_sequence)}")

# verify_and_print_alignment(original_sequence, mutated_sequence)
