"""
Generate plots and binding-site diagnostics for a completed toy run.
"""

from __future__ import annotations

import argparse
import csv
import json
import os
from typing import Dict, List, Optional, Sequence, Set, Tuple

import matplotlib.pyplot as plt
import numpy as np
from openmm import app, unit

from topology_safe_pipeline import write_vmd_comparison_script
from mutator import needleman_wunsch_affine


AA3 = {
    "ALA",
    "ARG",
    "ASN",
    "ASP",
    "CYS",
    "GLN",
    "GLU",
    "GLY",
    "HIS",
    "ILE",
    "LEU",
    "LYS",
    "MET",
    "PHE",
    "PRO",
    "SER",
    "THR",
    "TRP",
    "TYR",
    "VAL",
}


AA3_TO_1 = {
    "ALA": "A",
    "ARG": "R",
    "ASN": "N",
    "ASP": "D",
    "CYS": "C",
    "GLN": "Q",
    "GLU": "E",
    "GLY": "G",
    "HIS": "H",
    "ILE": "I",
    "LEU": "L",
    "LYS": "K",
    "MET": "M",
    "PHE": "F",
    "PRO": "P",
    "SER": "S",
    "THR": "T",
    "TRP": "W",
    "TYR": "Y",
    "VAL": "V",
}


def _load_json(path: str) -> Dict:
    with open(path, "r", encoding="utf-8") as handle:
        return json.load(handle)


def _resolve_run_path(run_dir: str, value: str) -> str:
    if os.path.isabs(value):
        return value
    if os.path.exists(value):
        return os.path.abspath(value)
    return os.path.abspath(os.path.join(run_dir, value))


def _kabsch_align(src: np.ndarray, dst: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    src_cent = np.mean(src, axis=0)
    dst_cent = np.mean(dst, axis=0)
    src0 = src - src_cent
    dst0 = dst - dst_cent
    h = src0.T @ dst0
    u, _, vt = np.linalg.svd(h)
    rot = vt.T @ u.T
    if np.linalg.det(rot) < 0:
        vt[-1, :] *= -1.0
        rot = vt.T @ u.T
    trans = dst_cent - rot @ src_cent
    return rot, trans


def _protein_ca_records(pdb_path: str) -> List[Dict[str, object]]:
    pdb = app.PDBFile(pdb_path)
    pos_nm = np.asarray(pdb.positions.value_in_unit(unit.nanometer), dtype=float)
    out: List[Dict[str, object]] = []
    for chain in pdb.topology.chains():
        for residue in chain.residues():
            resname = residue.name.upper()
            if resname not in AA3_TO_1:
                continue
            ca_atom = None
            for atom in residue.atoms():
                if atom.name == "CA":
                    ca_atom = atom
                    break
            if ca_atom is None:
                continue
            residue_key = f"{residue.name}{residue.id}"
            out.append(
                {
                    "aa1": AA3_TO_1[resname],
                    "residue_key": residue_key,
                    "resid": str(residue.id).strip(),
                    "chain_id": chain.id,
                    "atom_index": int(ca_atom.index),
                    "coord": pos_nm[ca_atom.index].copy(),
                }
            )
    return out


def _infer_mutation_anchor_from_structure(
    wt_pdb: str,
    mut_pdb: str,
    top_n: int = 3,
) -> Tuple[np.ndarray, List[str], Dict[str, float]]:
    wt_records = _protein_ca_records(wt_pdb)
    mut_records = _protein_ca_records(mut_pdb)
    if len(wt_records) < 3 or len(mut_records) < 3:
        raise ValueError("Need at least 3 CA records in WT and MUT for mutation anchor inference.")

    wt_seq = "".join(str(rec["aa1"]) for rec in wt_records)
    mut_seq = "".join(str(rec["aa1"]) for rec in mut_records)
    aln_wt, aln_mut = needleman_wunsch_affine(wt_seq, mut_seq)

    wt_idx = 0
    mut_idx = 0
    wt_pts: List[np.ndarray] = []
    mut_pts: List[np.ndarray] = []
    mut_keys: List[str] = []
    mut_coords: List[np.ndarray] = []

    for aa_w, aa_m in zip(aln_wt, aln_mut):
        i_w: Optional[int] = None
        i_m: Optional[int] = None
        if aa_w != "-":
            i_w = wt_idx
            wt_idx += 1
        if aa_m != "-":
            i_m = mut_idx
            mut_idx += 1
        if i_w is None or i_m is None:
            continue
        wt_rec = wt_records[i_w]
        mut_rec = mut_records[i_m]
        wt_pts.append(np.asarray(wt_rec["coord"], dtype=float))
        mut_pts.append(np.asarray(mut_rec["coord"], dtype=float))
        mut_keys.append(str(mut_rec["residue_key"]))
        mut_coords.append(np.asarray(mut_rec["coord"], dtype=float))

    if len(wt_pts) < 3:
        raise ValueError("Insufficient aligned CA pairs for mutation anchor inference.")

    wt_arr = np.stack(wt_pts, axis=0)
    mut_arr = np.stack(mut_pts, axis=0)
    rot, trans = _kabsch_align(mut_arr, wt_arr)
    mut_aligned = (rot @ mut_arr.T).T + trans[None, :]
    disp = np.linalg.norm(mut_aligned - wt_arr, axis=1)

    rank = np.argsort(-disp)
    keep = rank[: max(1, min(top_n, len(rank)))]
    hotspot_keys = [mut_keys[i] for i in keep]
    hotspot_coords = np.stack([mut_coords[i] for i in keep], axis=0)
    center = np.mean(hotspot_coords, axis=0)
    disp_map = {mut_keys[i]: float(disp[i]) for i in range(len(mut_keys))}
    return center, hotspot_keys, disp_map


def _read_binding_delta_csv(path: str) -> List[Tuple[str, float]]:
    rows: List[Tuple[str, float]] = []
    with open(path, "r", encoding="utf-8") as handle:
        reader = csv.DictReader(handle)
        for row in reader:
            key = str(row.get("residue", "")).strip()
            raw = str(row.get("delta_mut_minus_wt", "")).strip()
            if not key or not raw:
                continue
            try:
                value = float(raw)
            except ValueError:
                continue
            rows.append((key, value))
    return rows


def _read_binding_residue_keys(path: str) -> List[str]:
    keys: List[str] = []
    with open(path, "r", encoding="utf-8") as handle:
        reader = csv.DictReader(handle)
        for row in reader:
            key = str(row.get("residue", "")).strip()
            if key:
                keys.append(key)
    return sorted(set(keys))


def _latent_project_ca_vectors(
    wt_pdb: str,
    mut_pdb: str,
    mut_traj_npz: Optional[str],
    latents_npz: Optional[str],
    ridge: float = 1e-3,
) -> Dict[str, np.ndarray]:
    if not mut_traj_npz or not latents_npz:
        return {}
    if not os.path.exists(mut_traj_npz) or not os.path.exists(latents_npz):
        return {}

    mut_records = _protein_ca_records(mut_pdb)
    wt_records = _protein_ca_records(wt_pdb)
    if len(mut_records) < 3 or len(wt_records) < 3:
        return {}

    mut_ca_indices = np.asarray([int(rec["atom_index"]) for rec in mut_records], dtype=int)
    traj = np.load(mut_traj_npz)
    positions = np.asarray(traj["positions"], dtype=float)
    lat = np.load(latents_npz)
    u_mut = np.asarray(lat["u_b_mut"], dtype=float)
    u_wt = np.asarray(lat["u_b_wt"], dtype=float)
    n = min(int(positions.shape[0]), int(u_mut.shape[0]))
    if n < 8:
        return {}

    positions = positions[:n]
    u_mut = u_mut[:n]

    ca_xyz = positions[:, mut_ca_indices, :]
    ref = ca_xyz[0]
    ca_aligned = np.zeros_like(ca_xyz)
    for t in range(n):
        rot, trans = _kabsch_align(ca_xyz[t], ref)
        ca_aligned[t] = (rot @ ca_xyz[t].T).T + trans[None, :]

    y = ca_aligned.reshape(n, -1)
    y = y - np.mean(y, axis=0, keepdims=True)
    x = u_mut - np.mean(u_mut, axis=0, keepdims=True)
    if x.shape[1] < 1:
        return {}

    xtx = x.T @ x + ridge * np.eye(x.shape[1], dtype=float)
    xty = x.T @ y
    try:
        w = np.linalg.solve(xtx, xty)
    except np.linalg.LinAlgError:
        w = np.linalg.pinv(xtx) @ xty

    q = np.mean(u_mut, axis=0) - np.mean(u_wt, axis=0)
    q_norm = float(np.linalg.norm(q))
    if q_norm < 1e-10:
        _, _, vt = np.linalg.svd(x, full_matrices=False)
        q = vt[0]
    proj = q @ w
    vecs_nm = proj.reshape(len(mut_records), 3)
    return {str(mut_records[i]["residue_key"]): vecs_nm[i].astype(float) for i in range(len(mut_records))}


def _write_mut_flow_vmd_script(
    wt_pdb: str,
    mut_pdb: str,
    mut_dcd: Optional[str],
    mut_traj_npz: Optional[str],
    latents_npz: Optional[str],
    ligand_resname: str,
    binding_csv: str,
    output_tcl: str,
    cutoff_ang: float,
    analysis: Optional[Dict[str, object]] = None,
    max_vectors: int = 6,
) -> str:
    mut_records = _protein_ca_records(mut_pdb)
    mut_key_to_coord = {str(rec["residue_key"]): np.asarray(rec["coord"], dtype=float) for rec in mut_records}
    mut_key_to_resid = {str(rec["residue_key"]): str(rec["resid"]) for rec in mut_records}
    mut_key_to_chain = {str(rec["residue_key"]): str(rec["chain_id"]).strip() for rec in mut_records}

    def _selection_from_key(residue_key: str) -> Optional[str]:
        resid = mut_key_to_resid.get(residue_key)
        if resid is None:
            return None
        chain_id = mut_key_to_chain.get(residue_key, "")
        if chain_id:
            return f"protein and name CA and chain {chain_id} and resid {resid}"
        return f"protein and name CA and resid {resid}"

    anchor_center, hotspot_keys, _ = _infer_mutation_anchor_from_structure(wt_pdb, mut_pdb, top_n=3)
    delta_rows = _read_binding_delta_csv(binding_csv)
    delta_rows = [(k, v) for (k, v) in delta_rows if k in mut_key_to_coord]

    proj_map = _latent_project_ca_vectors(
        wt_pdb=wt_pdb,
        mut_pdb=mut_pdb,
        mut_traj_npz=mut_traj_npz,
        latents_npz=latents_npz,
    )
    use_projection = any(key in proj_map for key, _ in delta_rows)

    if use_projection:
        delta_rows_sorted = sorted(
            [item for item in delta_rows if item[0] in proj_map],
            key=lambda item: float(np.linalg.norm(proj_map[item[0]])),
            reverse=True,
        )
    else:
        delta_rows_sorted = sorted(delta_rows, key=lambda item: abs(item[1]), reverse=True)
    delta_rows_draw = delta_rows_sorted[: max(1, int(max_vectors))]

    binding_coords = [mut_key_to_coord[k] for k, _ in delta_rows if k in mut_key_to_coord]
    if binding_coords:
        binding_center = np.mean(np.stack(binding_coords, axis=0), axis=0)
    else:
        binding_center = anchor_center.copy()

    hotspot_sels: List[str] = []
    for key in hotspot_keys:
        sel = _selection_from_key(key)
        if sel and sel not in hotspot_sels:
            hotspot_sels.append(sel)
    if not hotspot_sels and delta_rows_draw:
        fallback_sel = _selection_from_key(delta_rows_draw[0][0])
        if fallback_sel:
            hotspot_sels = [fallback_sel]
    anchor_sel_text = " or ".join(f"({sel})" for sel in hotspot_sels) if hotspot_sels else "protein and name CA"

    if use_projection:
        mags = [float(np.linalg.norm(proj_map[k])) for k, _ in delta_rows if k in proj_map]
    else:
        mags = [abs(v) for _, v in delta_rows]
    max_mag = max(mags) if mags else 1.0
    if max_mag < 1e-12:
        max_mag = 1.0
    mean_mag = float(np.mean(mags)) if mags else 0.0
    local_signal = mean_mag / max_mag
    sus_signal = 0.0
    te_signal = 0.0
    if isinstance(analysis, dict):
        try:
            sus_signal = float(analysis.get("susceptibility_delta_fro_norm", 0.0))
        except Exception:
            sus_signal = 0.0
        try:
            te_signal = abs(float(analysis.get("te_delta_mut_minus_wt", 0.0)))
        except Exception:
            te_signal = 0.0
    sus_norm = float(np.tanh(max(0.0, sus_signal) / 6.0))
    te_norm = float(np.tanh(max(0.0, te_signal) / 0.25))
    global_scale = float(np.clip(0.5 * local_signal + 0.3 * sus_norm + 0.2 * te_norm, 0.0, 1.0))
    disp_clip_ang = float(1.2 + 1.8 * max(global_scale, 0.25))

    flow_entries: List[Tuple[str, float, int]] = []
    for residue_key, delta in delta_rows_draw:
        sel_text = _selection_from_key(residue_key)
        if not sel_text:
            continue
        target = mut_key_to_coord[residue_key]
        radial = target - anchor_center
        radial_norm = float(np.linalg.norm(radial))
        if radial_norm < 1e-10:
            radial_dir = np.array([1.0, 0.0, 0.0], dtype=float)
        else:
            radial_dir = radial / radial_norm

        if use_projection and residue_key in proj_map:
            pv = np.asarray(proj_map[residue_key], dtype=float)
            proj_sign = float(np.dot(pv, radial_dir))
            raw_mag = float(np.linalg.norm(pv))
        else:
            proj_sign = float(delta)
            raw_mag = abs(float(delta))

        mag = float(np.clip(raw_mag / max_mag, 0.0, 1.0))
        sign_flag = 1 if proj_sign >= 0.0 else -1
        flow_entries.append((sel_text, mag, sign_flag))

    site_target_sels: List[str] = []
    for residue_key, _ in delta_rows:
        sel_text = _selection_from_key(residue_key)
        if sel_text and sel_text not in site_target_sels:
            site_target_sels.append(sel_text)
    for sel_text, _, _ in flow_entries:
        if sel_text not in site_target_sels:
            site_target_sels.append(sel_text)

    def _fmt_vec_ang(v_nm: np.ndarray) -> str:
        vv = 10.0 * np.asarray(v_nm, dtype=float)
        return f"{{{vv[0]:.4f} {vv[1]:.4f} {vv[2]:.4f}}}"

    flow_targets_tcl = " ".join(f"{{{{{sel}}} {mag:.6f} {sgn}}}" for sel, mag, sgn in flow_entries)
    site_targets_tcl = " ".join(f"{{{sel}}}" for sel in site_target_sels)

    latent_xy: List[Tuple[float, float]] = []
    if latents_npz and os.path.exists(latents_npz):
        try:
            lat_data = np.load(latents_npz)
            u_mut = np.asarray(lat_data["u_b_mut"], dtype=float)
            if u_mut.ndim == 2 and u_mut.shape[0] > 0:
                if u_mut.shape[1] >= 2:
                    u2 = u_mut[:, :2]
                else:
                    u2 = np.column_stack([u_mut[:, 0], np.zeros(u_mut.shape[0], dtype=float)])
                x = u2[:, 0]
                y = u2[:, 1]
                xmin = float(np.min(x))
                xmax = float(np.max(x))
                ymin = float(np.min(y))
                ymax = float(np.max(y))
                xrange = max(xmax - xmin, 1e-8)
                yrange = max(ymax - ymin, 1e-8)
                for row in u2:
                    latent_xy.append((float((row[0] - xmin) / xrange), float((row[1] - ymin) / yrange)))
        except Exception:
            latent_xy = []
    if not latent_xy:
        latent_xy = [(0.5, 0.5)]
    latent_xy_tcl = " ".join(f"{{{xy[0]:.6f} {xy[1]:.6f}}}" for xy in latent_xy)

    lines = [
        "# Auto-generated MUT-only flow view for VMD",
        "display projection Orthographic",
        "display depthcue off",
        "axes location Off",
        "color Display Background white",
        f"set mut_pdb {{{os.path.abspath(mut_pdb).replace(os.sep, '/')}}}",
        f"set mut_dcd {{{os.path.abspath(mut_dcd).replace(os.sep, '/') if mut_dcd else ''}}}",
        f"set ligand_sel {{resname {ligand_resname.upper()}}}",
        f"set site_cutoff {float(cutoff_ang):.3f}",
        f"set anchor_sel_text {{{anchor_sel_text}}}",
        f"set anchor_fallback {_fmt_vec_ang(anchor_center)}",
        f"set site_fallback {_fmt_vec_ang(binding_center)}",
        f"set latent_xy {{{latent_xy_tcl}}}",
        "",
        "mol new $mut_pdb type pdb waitfor all",
        "set mid [molinfo top]",
        "if {[string length $mut_dcd] > 0 && [file exists $mut_dcd]} {",
        "    mol addfile $mut_dcd type dcd waitfor all molid $mid",
        "}",
        "",
        "proc fit_trajectory_to_first {mid sel_text} {",
        "    set ref [atomselect $mid $sel_text frame 0]",
        "    if {[$ref num] < 3} {",
        "        $ref delete",
        "        return",
        "    }",
        "    set mob [atomselect $mid $sel_text]",
        "    set all [atomselect $mid all]",
        "    set nframes [molinfo $mid get numframes]",
        "    for {set f 0} {$f < $nframes} {incr f} {",
        "        $mob frame $f",
        "        $all frame $f",
        "        set xform [measure fit $mob $ref]",
        "        $all move $xform",
        "    }",
        "    $ref delete",
        "    $mob delete",
        "    $all delete",
        "}",
        "fit_trajectory_to_first $mid {protein and name CA}",
        "",
        "mol delrep 0 $mid",
        "",
        "mol representation NewCartoon 0.24 20.0 4.1 0",
        "mol color ColorID 6",
        "mol selection {protein}",
        "mol material AOShiny",
        "mol addrep $mid",
        "",
        "mol representation Licorice 0.20 18.0 18.0",
        "mol color Name",
        "mol selection $ligand_sel",
        "mol material Glossy",
        "mol addrep $mid",
        "",
        "mol representation QuickSurf 1.0 0.6 1.0 1.0",
        "mol color ColorID 10",
        "mol selection \"protein and within $site_cutoff of ($ligand_sel)\"",
        "mol material Transparent",
        "mol addrep $mid",
    ]

    lines += [
        "",
        "proc _clip01 {x} {",
        "    if {$x < 0.0} { return 0.0 }",
        "    if {$x > 1.0} { return 1.0 }",
        "    return $x",
        "}",
        "",
        "proc _latent_color {t} {",
        "    set tt [_clip01 $t]",
        "    set r [expr {int(46 + $tt * 194)}]",
        "    set g [expr {int(118 + $tt * -55)}]",
        "    set b [expr {int(190 + $tt * -158)}]",
        "    return [format \"#%02x%02x%02x\" $r $g $b]",
        "}",
        "",
        "proc _latent_canvas_xy {u1 u2} {",
        "    set w 560",
        "    set h 420",
        "    set m 58",
        "    set cx [expr {$m + $u1 * ($w - 2.0 * $m)}]",
        "    set cy [expr {$h - $m - $u2 * ($h - 2.0 * $m)}]",
        "    return [list $cx $cy]",
        "}",
        "",
        "proc setup_latent_window {} {",
        "    global latent_xy latent_canvas latent_marker latent_frame_text latent_plot_ready",
        "    set latent_plot_ready 0",
        "    if {[catch {",
        "        if {[winfo exists .latent2d]} {",
        "            destroy .latent2d",
        "        }",
        "        toplevel .latent2d",
        "        wm title .latent2d {MUT Latent Trajectory}",
        "        wm geometry .latent2d 560x420+80+80",
        "        canvas .latent2d.c -width 560 -height 420 -background #f4f8ff -highlightthickness 0",
        "        pack .latent2d.c -fill both -expand 1",
        "    } err]} {",
        "        puts [format {Latent 2D window not available: %s} $err]",
        "        return",
        "    }",
        "    set c .latent2d.c",
        "    set latent_canvas $c",
        "    set w 560",
        "    set h 420",
        "    set m 58",
        "    for {set i 0} {$i <= 6} {incr i} {",
        "        set x [expr {$m + $i * ($w - 2.0 * $m) / 6.0}]",
        "        set y [expr {$m + $i * ($h - 2.0 * $m) / 6.0}]",
        "        $c create line $x $m $x [expr {$h - $m}] -fill #d9e3f0 -width 1",
        "        $c create line $m $y [expr {$w - $m}] $y -fill #d9e3f0 -width 1",
        "    }",
        "    $c create line $m [expr {$h - $m}] [expr {$w - $m}] [expr {$h - $m}] -width 2 -fill black",
        "    $c create line $m [expr {$h - $m}] $m $m -width 2 -fill black",
        "    $c create text [expr {$w / 2}] 20 -text {Pocket Conformation Map} -font {Helvetica 15 bold} -fill #17324d",
        "    $c create text [expr {$w / 2}] [expr {$h - 20}] -text {State axis 1} -font {Helvetica 11} -fill #17324d",
        "    $c create text 24 [expr {$h / 2}] -text {State axis 2} -angle 90 -font {Helvetica 11} -fill #17324d",
        "    $c create text [expr {$w / 2}] 42 -text {Dot moves with the movie frame} -font {Helvetica 10 italic} -fill #45627d",
        "    set n [llength $latent_xy]",
        "    for {set i 1} {$i < $n} {incr i} {",
        "        set p0 [lindex $latent_xy [expr {$i - 1}]]",
        "        set p1 [lindex $latent_xy $i]",
        "        lassign [_latent_canvas_xy [lindex $p0 0] [lindex $p0 1]] x0 y0",
        "        lassign [_latent_canvas_xy [lindex $p1 0] [lindex $p1 1]] x1 y1",
        "        set t [expr {$i / double(max($n - 1, 1))}]",
        "        set col [_latent_color $t]",
        "        $c create line $x0 $y0 $x1 $y1 -fill $col -width 2",
        "    }",
        "    set p_init [lindex $latent_xy 0]",
        "    lassign [_latent_canvas_xy [lindex $p_init 0] [lindex $p_init 1]] x y",
        "    $c create oval [expr {$x - 5}] [expr {$y - 5}] [expr {$x + 5}] [expr {$y + 5}] -fill #22c55e -outline #14532d -width 1.5",
        "    $c create text [expr {$x + 20}] [expr {$y - 10}] -text {Start} -font {Helvetica 9 bold} -fill #14532d",
        "    set p_last [lindex $latent_xy [expr {$n - 1}]]",
        "    lassign [_latent_canvas_xy [lindex $p_last 0] [lindex $p_last 1]] xL yL",
        "    $c create oval [expr {$xL - 5}] [expr {$yL - 5}] [expr {$xL + 5}] [expr {$yL + 5}] -fill #f97316 -outline #7c2d12 -width 1.5",
        "    $c create text [expr {$xL + 22}] [expr {$yL + 12}] -text {End} -font {Helvetica 9 bold} -fill #7c2d12",
        "    set latent_marker [$c create oval [expr {$x - 8}] [expr {$y - 8}] [expr {$x + 8}] [expr {$y + 8}] -fill #2563eb -outline #0f172a -width 2]",
        "    set latent_frame_text [$c create text [expr {$w - 96}] 20 -text {Frame 0} -font {Helvetica 11 bold} -fill #17324d]",
        "    set latent_progress_text [$c create text [expr {$w - 98}] 42 -text {Progress 0%} -font {Helvetica 10} -fill #2f4b69]",
        "    set latent_plot_ready 1",
        "}",
        "",
        "proc update_latent_window {frame} {",
        "    global latent_xy latent_canvas latent_marker latent_frame_text latent_progress_text latent_plot_ready",
        "    if {![info exists latent_plot_ready] || !$latent_plot_ready} {",
        "        return",
        "    }",
        "    if {![winfo exists .latent2d] || ![winfo exists $latent_canvas]} {",
        "        set latent_plot_ready 0",
        "        return",
        "    }",
        "    set n [llength $latent_xy]",
        "    if {$n < 1} {",
        "        return",
        "    }",
        "    set idx $frame",
        "    if {$idx < 0} {",
        "        set idx 0",
        "    }",
        "    if {$idx >= $n} {",
        "        set idx [expr {$n - 1}]",
        "    }",
        "    set p [lindex $latent_xy $idx]",
        "    lassign [_latent_canvas_xy [lindex $p 0] [lindex $p 1]] x y",
        "    $latent_canvas coords $latent_marker [expr {$x - 8}] [expr {$y - 8}] [expr {$x + 8}] [expr {$y + 8}]",
        "    set tt [expr {$idx / double(max($n - 1, 1))}]",
        "    set col [_latent_color $tt]",
        "    $latent_canvas itemconfigure $latent_marker -fill $col",
        "    $latent_canvas itemconfigure $latent_frame_text -text [format {Frame %d/%d} $idx [expr {$n - 1}]]",
        "    $latent_canvas itemconfigure $latent_progress_text -text [format {Progress %.1f%%} [expr {100.0 * $tt}]]",
        "}",
        "",
        "proc draw_mut_flow_frame {mid frame} {",
        "    # Keep 3D view clean: no extra vectors or geometric overlays.",
        "    return",
        "}",
        "",
        "proc _refresh_mut_flow {name index op} {",
        "    global mid",
        "    if {[catch {molinfo $mid get frame} frame]} {",
        "        return",
        "    }",
        "    draw_mut_flow_frame $mid $frame",
        "    update_latent_window $frame",
        "}",
        "",
        "setup_latent_window",
        "draw_mut_flow_frame $mid 0",
        "update_latent_window 0",
        "catch {trace remove variable vmd_frame($mid) write _refresh_mut_flow}",
        "trace add variable vmd_frame($mid) write _refresh_mut_flow",
    ]

    lines += [
        "",
        "animate style Loop",
        "animate speed 0.7",
        "animate goto 0",
        "display resetview",
        "puts \"Loaded MUT-only perturbation-flow view.\"",
        "puts \"3D window: protein + ligand + transparent binding-site volume.\"",
        "puts \"Frames are aligned to remove global translation/rotation.\"",
        "puts \"2D window: latent conformation map, moving dot = current frame.\"",
        "puts \"Path color encodes progression from early (blue) to late (orange).\"",
    ]

    os.makedirs(os.path.dirname(output_tcl) or ".", exist_ok=True)
    with open(output_tcl, "w", encoding="utf-8") as handle:
        handle.write("\n".join(lines) + "\n")
    return output_tcl


def _plot_basin_ddg(analysis: Dict, out_png: str) -> None:
    basins = analysis["basin_ddg"]["basins"]
    labels = [str(row["basin"]) for row in basins]
    ddg = np.array([row["ddg_kcal_mol"] for row in basins], dtype=float)
    low = np.array([row["ddg_ci95_low"] for row in basins], dtype=float)
    high = np.array([row["ddg_ci95_high"] for row in basins], dtype=float)
    yerr = np.vstack([ddg - low, high - ddg])

    plt.figure(figsize=(7, 4))
    plt.bar(labels, ddg, color="#4C78A8", alpha=0.9, yerr=yerr, capsize=4)
    plt.axhline(0.0, color="black", linewidth=1)
    plt.xlabel("Basin")
    plt.ylabel("ΔΔG (kcal/mol)")
    plt.title("Pocket Basin Stabilization Shift (MUT vs WT)")
    plt.tight_layout()
    plt.savefig(out_png, dpi=200)
    plt.close()


def _plot_latent_trajectory(latents_npz: str, out_png: str) -> None:
    data = np.load(latents_npz)
    wt = np.asarray(data["u_b_wt"], dtype=float)
    mut = np.asarray(data["u_b_mut"], dtype=float)

    def _pad2(x: np.ndarray) -> np.ndarray:
        if x.shape[1] >= 2:
            return x[:, :2]
        return np.column_stack([x[:, 0], np.zeros(len(x))])

    wt2 = _pad2(wt)
    mut2 = _pad2(mut)

    plt.figure(figsize=(7, 6))
    plt.plot(wt2[:, 0], wt2[:, 1], color="#1f77b4", alpha=0.6, label="WT path")
    plt.plot(mut2[:, 0], mut2[:, 1], color="#d62728", alpha=0.6, label="MUT path")
    plt.scatter(wt2[:, 0], wt2[:, 1], color="#1f77b4", s=14)
    plt.scatter(mut2[:, 0], mut2[:, 1], color="#d62728", s=14)

    for arr, color in [(wt2, "#1f77b4"), (mut2, "#d62728")]:
        d = arr[1:] - arr[:-1]
        plt.quiver(
            arr[:-1, 0],
            arr[:-1, 1],
            d[:, 0],
            d[:, 1],
            angles="xy",
            scale_units="xy",
            scale=1,
            width=0.003,
            color=color,
            alpha=0.35,
        )

    plt.xlabel("Pocket latent 1")
    plt.ylabel("Pocket latent 2")
    plt.title("Pocket Latent Trajectories with Local Flow Vectors")
    plt.legend(frameon=False)
    plt.tight_layout()
    plt.savefig(out_png, dpi=200)
    plt.close()


def _plot_te(analysis: Dict, out_png: str) -> None:
    wt = analysis["te_wt_p_to_b_given_l"]
    mut = analysis["te_mut_p_to_b_given_l"]
    names = ["P→B|L", "B→P|L"]
    wt_vals = [wt["te_driver_to_target"], wt["te_target_to_driver"]]
    mut_vals = [mut["te_driver_to_target"], mut["te_target_to_driver"]]

    x = np.arange(len(names))
    width = 0.35
    plt.figure(figsize=(6.8, 4.2))
    plt.bar(x - width / 2, wt_vals, width=width, label="WT", color="#1f77b4")
    plt.bar(x + width / 2, mut_vals, width=width, label="MUT", color="#d62728")
    plt.xticks(x, names)
    plt.ylabel("TE (nats)")
    plt.title("Directed Predictive Dependence (Linear-Gaussian TE)")
    plt.legend(frameon=False)
    plt.tight_layout()
    plt.savefig(out_png, dpi=200)
    plt.close()


def _plot_susceptibility_quiver(analysis: Dict, out_png: str) -> None:
    gamma_wt = np.asarray(analysis["susceptibility_wt"]["gamma_matrix"], dtype=float)
    gamma_mut = np.asarray(analysis["susceptibility_mut"]["gamma_matrix"], dtype=float)
    g_wt = gamma_wt[:2, :2]
    g_mut = gamma_mut[:2, :2]

    grid = np.linspace(-2.0, 2.0, 11)
    xx, yy = np.meshgrid(grid, grid)
    pts = np.stack([xx.ravel(), yy.ravel()], axis=1)

    vec_wt = pts @ g_wt.T
    vec_mut = pts @ g_mut.T

    fig, axes = plt.subplots(1, 2, figsize=(11, 4.5), sharex=True, sharey=True)
    axes[0].quiver(pts[:, 0], pts[:, 1], vec_wt[:, 0], vec_wt[:, 1], color="#1f77b4")
    axes[0].set_title("WT susceptibility field")
    axes[1].quiver(pts[:, 0], pts[:, 1], vec_mut[:, 0], vec_mut[:, 1], color="#d62728")
    axes[1].set_title("MUT susceptibility field")
    for ax in axes:
        ax.set_xlabel("Context latent 1")
        ax.set_ylabel("Context latent 2")
        ax.axhline(0.0, color="black", linewidth=0.6)
        ax.axvline(0.0, color="black", linewidth=0.6)
    fig.suptitle("Estimated Context→Pocket Linear Response (Γ)")
    fig.tight_layout()
    fig.savefig(out_png, dpi=200)
    plt.close(fig)


def _binding_site_residues(
    pdb_path: str,
    ligand_resname: str,
    cutoff_ang: float,
) -> List[Tuple[str, str, float]]:
    pdb = app.PDBFile(pdb_path)
    pos_nm = np.asarray(pdb.positions.value_in_unit(unit.nanometer), dtype=float)
    cutoff_nm = cutoff_ang * 0.1

    ligand_indices = []
    for atom in pdb.topology.atoms():
        if atom.residue.name.upper() == ligand_resname.upper():
            ligand_indices.append(atom.index)
    if not ligand_indices:
        return []

    lig_xyz = pos_nm[ligand_indices]
    result = []
    for residue in pdb.topology.residues():
        if residue.name.upper() not in AA3:
            continue
        atom_indices = [a.index for a in residue.atoms() if (a.element is None or a.element.symbol != "H")]
        if not atom_indices:
            continue
        xyz = pos_nm[atom_indices]
        d = np.linalg.norm(xyz[:, None, :] - lig_xyz[None, :, :], axis=2)
        min_d = float(np.min(d)) * 10.0
        if min_d <= cutoff_ang:
            result.append((residue.chain.id, f"{residue.name}{residue.id}", min_d))
    result.sort(key=lambda x: x[2])
    return result


def _write_binding_csv(
    wt_pdb: str,
    mut_pdb: str,
    ligand_resname: str,
    cutoff_ang: float,
    out_csv: str,
) -> None:
    wt = _binding_site_residues(wt_pdb, ligand_resname, cutoff_ang)
    mut = _binding_site_residues(mut_pdb, ligand_resname, cutoff_ang)

    wt_map = {row[1]: row[2] for row in wt}
    mut_map = {row[1]: row[2] for row in mut}
    keys = sorted(set(wt_map) | set(mut_map))
    with open(out_csv, "w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(["residue", "wt_min_dist_ang", "mut_min_dist_ang", "delta_mut_minus_wt"])
        for key in keys:
            w = wt_map.get(key)
            m = mut_map.get(key)
            delta = None if (w is None or m is None) else (m - w)
            writer.writerow(
                [
                    key,
                    "" if w is None else f"{w:.3f}",
                    "" if m is None else f"{m:.3f}",
                    "" if delta is None else f"{delta:.3f}",
                ]
            )


def _aligned_ca_pair_records(wt_pdb: str, mut_pdb: str) -> List[Dict[str, object]]:
    wt_records = _protein_ca_records(wt_pdb)
    mut_records = _protein_ca_records(mut_pdb)
    if len(wt_records) < 3 or len(mut_records) < 3:
        raise ValueError("Need at least 3 CA residues in both WT and MUT.")

    wt_seq = "".join(str(rec["aa1"]) for rec in wt_records)
    mut_seq = "".join(str(rec["aa1"]) for rec in mut_records)
    aln_wt, aln_mut = needleman_wunsch_affine(wt_seq, mut_seq)

    wt_idx = 0
    mut_idx = 0
    out: List[Dict[str, object]] = []
    for aa_w, aa_m in zip(aln_wt, aln_mut):
        iw: Optional[int] = None
        im: Optional[int] = None
        if aa_w != "-":
            iw = wt_idx
            wt_idx += 1
        if aa_m != "-":
            im = mut_idx
            mut_idx += 1
        if iw is None or im is None:
            continue
        wt_rec = wt_records[iw]
        mut_rec = mut_records[im]
        chain_id = str(mut_rec["chain_id"]).strip()
        resid = str(mut_rec["resid"]).strip()
        mut_reskey = str(mut_rec["residue_key"]).strip()
        node_label = f"{chain_id}:{mut_reskey}" if chain_id else mut_reskey
        out.append(
            {
                "node_label": node_label,
                "chain_id": chain_id,
                "resid": resid,
                "mut_residue_key": mut_reskey,
                "wt_residue_key": str(wt_rec["residue_key"]).strip(),
                "mut_atom_index": int(mut_rec["atom_index"]),
                "wt_atom_index": int(wt_rec["atom_index"]),
                "mut_coord_nm": np.asarray(mut_rec["coord"], dtype=float),
            }
        )
    if len(out) < 4:
        raise ValueError("Insufficient aligned CA pairs for residue-flow analysis.")
    return out


def _align_positions_and_velocities(
    positions_nm: np.ndarray,
    velocities_nmps: np.ndarray,
) -> Tuple[np.ndarray, np.ndarray]:
    ref = np.asarray(positions_nm[0], dtype=float)
    pos_aligned = np.zeros_like(positions_nm, dtype=float)
    vel_aligned = np.zeros_like(velocities_nmps, dtype=float)
    for frame in range(int(positions_nm.shape[0])):
        rot, trans = _kabsch_align(np.asarray(positions_nm[frame], dtype=float), ref)
        pos_aligned[frame] = (rot @ positions_nm[frame].T).T + trans[None, :]
        vel_aligned[frame] = (rot @ velocities_nmps[frame].T).T
    return pos_aligned, vel_aligned


def _zscore_columns(x: np.ndarray) -> np.ndarray:
    x = np.asarray(x, dtype=float)
    mean = np.mean(x, axis=0, keepdims=True)
    std = np.std(x, axis=0, keepdims=True)
    std = np.where(std < 1e-8, 1.0, std)
    return (x - mean) / std


def _build_residue_motion_signals(
    positions_nm: np.ndarray,
    velocities_nmps: np.ndarray,
    velocity_weight: float = 0.35,
) -> np.ndarray:
    disp = np.linalg.norm(positions_nm - np.mean(positions_nm, axis=0, keepdims=True), axis=2)
    speed = np.linalg.norm(velocities_nmps, axis=2)
    disp_z = _zscore_columns(disp)
    speed_z = _zscore_columns(speed)
    return disp_z + float(velocity_weight) * speed_z


def _residual_variance(x: np.ndarray, y: np.ndarray, ridge: float = 1e-5) -> float:
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    xtx = x.T @ x + ridge * np.eye(x.shape[1], dtype=float)
    xty = x.T @ y
    try:
        beta = np.linalg.solve(xtx, xty)
    except np.linalg.LinAlgError:
        beta = np.linalg.pinv(xtx) @ xty
    resid = y - x @ beta
    var = float(np.var(resid))
    if not np.isfinite(var):
        return 1e-10
    return max(var, 1e-10)


def _pairwise_te_matrix(signal: np.ndarray, lag: int = 1) -> np.ndarray:
    signal = np.asarray(signal, dtype=float)
    t, n = signal.shape
    te = np.zeros((n, n), dtype=float)
    if t <= lag + 3:
        return te
    y_all = signal[lag:, :]
    yp_all = signal[:-lag, :]
    ones = np.ones((t - lag, 1), dtype=float)
    for target in range(n):
        y = y_all[:, target]
        yp = yp_all[:, target : target + 1]
        xr = np.hstack([ones, yp])
        var_r = _residual_variance(xr, y)
        for source in range(n):
            if source == target:
                continue
            xp = yp_all[:, source : source + 1]
            xf = np.hstack([ones, yp, xp])
            var_f = _residual_variance(xf, y)
            value = 0.5 * np.log(var_r / var_f)
            if np.isfinite(value):
                te[source, target] = max(0.0, float(value))
    return te


def _indices_from_mut_residue_keys(pair_records: Sequence[Dict[str, object]], keys: Sequence[str]) -> List[int]:
    keyset = {str(k).strip() for k in keys if str(k).strip()}
    indices: List[int] = []
    for idx, rec in enumerate(pair_records):
        chain_id = str(rec["chain_id"]).strip()
        resid = str(rec["resid"]).strip()
        mut_key = str(rec["mut_residue_key"]).strip()
        if (
            mut_key in keyset
            or (chain_id and f"{chain_id}:{mut_key}" in keyset)
            or (chain_id and f"{chain_id}:{resid}" in keyset)
        ):
            indices.append(idx)
    return sorted(set(indices))


def _source_target_indices(
    pair_records: Sequence[Dict[str, object]],
    wt_pdb: str,
    mut_pdb: str,
    binding_csv: str,
) -> Tuple[List[int], List[int]]:
    try:
        _, hotspot_keys, _ = _infer_mutation_anchor_from_structure(wt_pdb, mut_pdb, top_n=4)
    except Exception:
        hotspot_keys = []
    binding_keys = _read_binding_residue_keys(binding_csv)
    source_idx = _indices_from_mut_residue_keys(pair_records, hotspot_keys)
    target_idx = _indices_from_mut_residue_keys(pair_records, binding_keys)
    if not source_idx and len(pair_records) > 0:
        source_idx = [0]
    if not target_idx and len(pair_records) > 1:
        target_idx = [len(pair_records) - 1]
    src_set = set(source_idx)
    filtered_targets = [idx for idx in target_idx if idx not in src_set]
    if filtered_targets:
        target_idx = filtered_targets
    if not target_idx and source_idx:
        target_idx = [source_idx[0]]
    return source_idx, target_idx


def _flow_score(te: np.ndarray, source_idx: Sequence[int], target_idx: Sequence[int]) -> float:
    if not source_idx or not target_idx:
        return 0.0
    src = np.asarray(source_idx, dtype=int)
    tgt = np.asarray(target_idx, dtype=int)
    direct = float(np.sum(te[np.ix_(src, tgt)]))
    src_set = set(int(i) for i in src.tolist())
    tgt_set = set(int(i) for i in tgt.tolist())
    relay = 0.0
    for k in range(int(te.shape[0])):
        if k in src_set or k in tgt_set:
            continue
        smax = float(np.max(te[src, k])) if len(src) else 0.0
        tmax = float(np.max(te[k, tgt])) if len(tgt) else 0.0
        relay += smax * tmax
    return direct + 0.5 * relay


def _relay_scores(te_delta_pos: np.ndarray, source_idx: Sequence[int], target_idx: Sequence[int]) -> np.ndarray:
    n = int(te_delta_pos.shape[0])
    relay = np.zeros(n, dtype=float)
    src_set = set(int(i) for i in source_idx)
    tgt_set = set(int(i) for i in target_idx)
    for s in source_idx:
        for t in target_idx:
            for k in range(n):
                if k in src_set or k in tgt_set:
                    continue
                relay[k] += min(float(te_delta_pos[s, k]), float(te_delta_pos[k, t]))
    scale = float(np.max(relay))
    if scale > 1e-12:
        relay = relay / scale
    return relay


def _top_delta_edges(
    te_wt: np.ndarray,
    te_mut: np.ndarray,
    pair_records: Sequence[Dict[str, object]],
    top_n: int = 24,
    min_delta: float = 1e-5,
) -> List[Dict[str, object]]:
    delta = te_mut - te_wt
    edges: List[Dict[str, object]] = []
    n = int(delta.shape[0])
    for source in range(n):
        for target in range(n):
            if source == target:
                continue
            dv = float(delta[source, target])
            if dv <= min_delta:
                continue
            edges.append(
                {
                    "src_index": source,
                    "dst_index": target,
                    "src_residue": str(pair_records[source]["node_label"]),
                    "dst_residue": str(pair_records[target]["node_label"]),
                    "te_wt": float(te_wt[source, target]),
                    "te_mut": float(te_mut[source, target]),
                    "delta": dv,
                }
            )
    edges.sort(key=lambda row: row["delta"], reverse=True)
    return edges[: max(1, int(top_n))]


def _top_paths(
    te_delta_pos: np.ndarray,
    source_idx: Sequence[int],
    target_idx: Sequence[int],
    pair_records: Sequence[Dict[str, object]],
    top_n: int = 12,
) -> List[Dict[str, object]]:
    n = int(te_delta_pos.shape[0])
    candidates: List[Dict[str, object]] = []
    for s in source_idx:
        for t in target_idx:
            direct = float(te_delta_pos[s, t])
            if direct > 0.0:
                candidates.append(
                    {
                        "kind": "direct",
                        "path": [str(pair_records[s]["node_label"]), str(pair_records[t]["node_label"])],
                        "score": direct,
                    }
                )
            for k in range(n):
                if k == s or k == t:
                    continue
                score = min(float(te_delta_pos[s, k]), float(te_delta_pos[k, t]))
                if score <= 0.0:
                    continue
                candidates.append(
                    {
                        "kind": "relay",
                        "path": [
                            str(pair_records[s]["node_label"]),
                            str(pair_records[k]["node_label"]),
                            str(pair_records[t]["node_label"]),
                        ],
                        "score": score,
                    }
                )
    candidates.sort(key=lambda row: float(row["score"]), reverse=True)
    return candidates[: max(1, int(top_n))]


def _windowed_flow_timeseries(
    signal_wt: np.ndarray,
    signal_mut: np.ndarray,
    time_ps: np.ndarray,
    source_idx: Sequence[int],
    target_idx: Sequence[int],
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, Dict[str, int]]:
    n = min(int(signal_wt.shape[0]), int(signal_mut.shape[0]), int(time_ps.shape[0]))
    if n < 10:
        te_wt = _pairwise_te_matrix(signal_wt[:n], lag=1)
        te_mut = _pairwise_te_matrix(signal_mut[:n], lag=1)
        fw = _flow_score(te_wt, source_idx, target_idx)
        fm = _flow_score(te_mut, source_idx, target_idx)
        return (
            np.asarray([float(np.mean(time_ps[:n]))], dtype=float),
            np.asarray([fw], dtype=float),
            np.asarray([fm], dtype=float),
            np.asarray([fm - fw], dtype=float),
            {"window_frames": n, "step_frames": n},
        )

    window = max(24, min(90, n // 3))
    if window >= n:
        window = max(8, n - 1)
    step = max(3, window // 6)

    t_center: List[float] = []
    flow_wt: List[float] = []
    flow_mut: List[float] = []
    for start in range(0, n - window + 1, step):
        end = start + window
        te_w = _pairwise_te_matrix(signal_wt[start:end], lag=1)
        te_m = _pairwise_te_matrix(signal_mut[start:end], lag=1)
        t_center.append(float(np.mean(time_ps[start:end])))
        flow_wt.append(_flow_score(te_w, source_idx, target_idx))
        flow_mut.append(_flow_score(te_m, source_idx, target_idx))
    if not t_center:
        te_w = _pairwise_te_matrix(signal_wt[:n], lag=1)
        te_m = _pairwise_te_matrix(signal_mut[:n], lag=1)
        t_center = [float(np.mean(time_ps[:n]))]
        flow_wt = [_flow_score(te_w, source_idx, target_idx)]
        flow_mut = [_flow_score(te_m, source_idx, target_idx)]

    time_arr = np.asarray(t_center, dtype=float)
    wt_arr = np.asarray(flow_wt, dtype=float)
    mut_arr = np.asarray(flow_mut, dtype=float)
    return time_arr, wt_arr, mut_arr, mut_arr - wt_arr, {"window_frames": window, "step_frames": step}


def _plot_flow_timeseries(
    time_ps: np.ndarray,
    flow_wt: np.ndarray,
    flow_mut: np.ndarray,
    flow_delta: np.ndarray,
    out_png: str,
) -> None:
    time_ns = np.asarray(time_ps, dtype=float) * 1e-3
    fig, axes = plt.subplots(2, 1, figsize=(8.0, 6.0), sharex=True)
    axes[0].plot(time_ns, flow_wt, color="#1f77b4", linewidth=2.0, label="WT flow score")
    axes[0].plot(time_ns, flow_mut, color="#d62728", linewidth=2.0, label="MUT flow score")
    axes[0].set_ylabel("Flow score")
    axes[0].set_title("Mutation→Binding-Site Information-Flow Proxy")
    axes[0].legend(frameon=False, loc="upper left")
    axes[0].grid(alpha=0.25, linewidth=0.8)

    axes[1].axhline(0.0, color="black", linewidth=1.0)
    axes[1].plot(time_ns, flow_delta, color="#8c564b", linewidth=2.0, label="Δ flow (MUT−WT)")
    axes[1].fill_between(time_ns, 0.0, flow_delta, where=(flow_delta >= 0.0), color="#ff9896", alpha=0.35)
    axes[1].fill_between(time_ns, 0.0, flow_delta, where=(flow_delta < 0.0), color="#9ecae1", alpha=0.35)
    axes[1].set_xlabel("Time (ns)")
    axes[1].set_ylabel("Δ flow")
    axes[1].legend(frameon=False, loc="upper left")
    axes[1].grid(alpha=0.25, linewidth=0.8)

    fig.tight_layout()
    fig.savefig(out_png, dpi=220)
    plt.close(fig)


def _selection_from_indices(pair_records: Sequence[Dict[str, object]], indices: Sequence[int]) -> str:
    terms: List[str] = []
    seen: Set[Tuple[str, str]] = set()
    for idx in indices:
        if idx < 0 or idx >= len(pair_records):
            continue
        chain_id = str(pair_records[idx]["chain_id"]).strip()
        resid = str(pair_records[idx]["resid"]).strip()
        key = (chain_id, resid)
        if key in seen:
            continue
        seen.add(key)
        if chain_id:
            terms.append(f"(chain {chain_id} and resid {resid})")
        else:
            terms.append(f"(resid {resid})")
    if not terms:
        return "none"
    return "protein and (" + " or ".join(terms) + ")"


def _write_flow_network_vmd_script(
    mut_pdb: str,
    mut_dcd: Optional[str],
    ligand_resname: str,
    pair_records: Sequence[Dict[str, object]],
    top_edges: Sequence[Dict[str, object]],
    source_idx: Sequence[int],
    target_idx: Sequence[int],
    relay_scores: np.ndarray,
    flow_delta_series: np.ndarray,
    output_tcl: str,
    top_paths: Optional[Sequence[Dict[str, object]]] = None,
) -> str:
    source_sel = _selection_from_indices(pair_records, source_idx)
    target_sel = _selection_from_indices(pair_records, target_idx)

    def _fmt_vec_ang(v_nm: np.ndarray) -> str:
        vv = 10.0 * np.asarray(v_nm, dtype=float)
        return f"{{{vv[0]:.4f} {vv[1]:.4f} {vv[2]:.4f}}}"

    def _mean_coord(indices: Sequence[int]) -> Optional[np.ndarray]:
        coords = []
        for idx in indices:
            if idx < 0 or idx >= len(pair_records):
                continue
            coords.append(np.asarray(pair_records[idx]["mut_coord_nm"], dtype=float))
        if not coords:
            return None
        return np.mean(np.stack(coords, axis=0), axis=0)

    source_center = _mean_coord(source_idx)
    target_center = _mean_coord(target_idx)
    label_to_coord = {
        str(rec["node_label"]): np.asarray(rec["mut_coord_nm"], dtype=float)
        for rec in pair_records
    }
    waypoint_labels: List[str] = []
    if top_paths:
        for row in top_paths:
            path_raw = row.get("path") if isinstance(row, dict) else None
            if not isinstance(path_raw, list):
                continue
            candidate = [str(label) for label in path_raw if str(label) in label_to_coord]
            if len(candidate) >= 2:
                waypoint_labels = candidate
                break
    if not waypoint_labels and source_idx and target_idx:
        src_label = str(pair_records[int(source_idx[0])]["node_label"])
        dst_label = str(pair_records[int(target_idx[0])]["node_label"])
        if src_label in label_to_coord and dst_label in label_to_coord:
            waypoint_labels = [src_label, dst_label]

    waypoint_coords: List[np.ndarray] = []
    for label in waypoint_labels:
        if label not in label_to_coord:
            continue
        coord = label_to_coord[label]
        if waypoint_coords and np.linalg.norm(coord - waypoint_coords[-1]) < 1e-10:
            continue
        waypoint_coords.append(coord)
    if len(waypoint_coords) < 2 and source_center is not None and target_center is not None:
        waypoint_coords = [source_center, target_center]
    if len(waypoint_coords) < 2 and len(pair_records) >= 2:
        waypoint_coords = [
            np.asarray(pair_records[0]["mut_coord_nm"], dtype=float),
            np.asarray(pair_records[-1]["mut_coord_nm"], dtype=float),
        ]
    if not waypoint_coords and len(pair_records) > 0:
        waypoint_coords = [np.asarray(pair_records[0]["mut_coord_nm"], dtype=float)]
    if len(waypoint_coords) == 1:
        waypoint_coords = [waypoint_coords[0], waypoint_coords[0]]

    flow_waypoints_tcl = " ".join(_fmt_vec_ang(coord) for coord in waypoint_coords)

    flow_delta = np.asarray(flow_delta_series, dtype=float).reshape(-1)
    if flow_delta.size < 1:
        flow_delta = np.asarray([0.0], dtype=float)
    flow_delta_tcl = " ".join(f"{float(v):.6f}" for v in flow_delta.tolist())

    lines = [
        "# Auto-generated mutation-flow network view for VMD",
        "display projection Orthographic",
        "display depthcue off",
        "axes location Off",
        "color Display Background white",
        f"set mut_pdb {{{os.path.abspath(mut_pdb).replace(os.sep, '/')}}}",
        f"set mut_dcd {{{os.path.abspath(mut_dcd).replace(os.sep, '/') if mut_dcd else ''}}}",
        f"set ligand_sel {{resname {ligand_resname.upper()}}}",
        f"set source_sel {{{source_sel}}}",
        f"set target_sel {{{target_sel}}}",
        f"set flow_waypoints {{{flow_waypoints_tcl}}}",
        f"set flow_delta {{{flow_delta_tcl}}}",
        "",
        "mol new $mut_pdb type pdb waitfor all",
        "set mid [molinfo top]",
        "if {[string length $mut_dcd] > 0 && [file exists $mut_dcd]} {",
        "    mol addfile $mut_dcd type dcd waitfor all molid $mid",
        "}",
        "",
        "proc fit_to_first {mid sel_text} {",
        "    set ref [atomselect $mid $sel_text frame 0]",
        "    if {[$ref num] < 3} {",
        "        $ref delete",
        "        return",
        "    }",
        "    set mob [atomselect $mid $sel_text]",
        "    set all [atomselect $mid all]",
        "    set nf [molinfo $mid get numframes]",
        "    for {set f 0} {$f < $nf} {incr f} {",
        "        $mob frame $f",
        "        $all frame $f",
        "        set xf [measure fit $mob $ref]",
        "        $all move $xf",
        "    }",
        "    $ref delete",
        "    $mob delete",
        "    $all delete",
        "}",
        "fit_to_first $mid {protein and name CA}",
        "",
        "mol delrep 0 $mid",
        "mol representation NewCartoon 0.22 24.0 4.2 0",
        "mol color Structure",
        "mol selection {protein}",
        "mol material AOChalky",
        "mol addrep $mid",
        "",
        "mol representation Licorice 0.24 20.0 20.0",
        "mol color Name",
        "mol selection $ligand_sel",
        "mol material Glossy",
        "mol addrep $mid",
    ]

    if source_sel != "none":
        lines += [
            "",
            "mol representation Licorice 0.22 20.0 20.0",
            "mol color ColorID 1",
            "mol selection ($source_sel) and not hydrogen",
            "mol material Glossy",
            "mol addrep $mid",
        ]
    if target_sel != "none":
        lines += [
            "",
            "mol representation Licorice 0.22 20.0 20.0",
            "mol color ColorID 10",
            "mol selection ($target_sel) and not hydrogen",
            "mol material Glossy",
            "mol addrep $mid",
        ]
    if target_sel != "none":
        lines += [
            "",
            "mol representation QuickSurf 1.0 0.5 1.0 1.0",
            "mol color ColorID 10",
            "mol selection $target_sel",
            "mol material Transparent",
            "mol addrep $mid",
        ]

    lines += [
        "",
        "proc _clip01 {x} {",
        "    if {$x < 0.0} { return 0.0 }",
        "    if {$x > 1.0} { return 1.0 }",
        "    return $x",
        "}",
        "",
        "proc _frame_to_flow_index {frame} {",
        "    global mid flow_delta",
        "    set n [llength $flow_delta]",
        "    if {$n < 1} { return 0 }",
        "    if {[catch {set nf [molinfo $mid get numframes]}]} { return 0 }",
        "    if {$nf < 2} {",
        "        set idx 0",
        "    } else {",
        "        set idx [expr {int(round($frame * ($n - 1) / double($nf - 1)))}]",
        "    }",
        "    if {$idx < 0} { set idx 0 }",
        "    if {$idx >= $n} { set idx [expr {$n - 1}] }",
        "    return $idx",
        "}",
        "",
        "proc _interp_flow_point {alpha} {",
        "    global flow_waypoints",
        "    set n [llength $flow_waypoints]",
        "    if {$n < 1} { return {0.0 0.0 0.0} }",
        "    if {$n == 1} { return [lindex $flow_waypoints 0] }",
        "    set a [_clip01 $alpha]",
        "    set seg [expr {$n - 1}]",
        "    set x [expr {$a * $seg}]",
        "    set i [expr {int(floor($x))}]",
        "    if {$i >= $seg} {",
        "        set i [expr {$seg - 1}]",
        "        set frac 1.0",
        "    } else {",
        "        set frac [expr {$x - $i}]",
        "    }",
        "    set p0 [lindex $flow_waypoints $i]",
        "    set p1 [lindex $flow_waypoints [expr {$i + 1}]]",
        "    return [vecadd [vecscale [expr {1.0 - $frac}] $p0] [vecscale $frac $p1]]",
        "}",
        "",
        "proc draw_flow_path {mid} {",
        "    global flow_waypoints",
        "    set n [llength $flow_waypoints]",
        "    if {$n < 2} { return }",
        "    for {set i 1} {$i < $n} {incr i} {",
        "        set p0 [lindex $flow_waypoints [expr {$i - 1}]]",
        "        set p1 [lindex $flow_waypoints $i]",
        "        graphics $mid color 17",
        "        graphics $mid cylinder $p0 $p1 radius 0.18 resolution 28 filled yes",
        "    }",
        "    set p_start [lindex $flow_waypoints 0]",
        "    set p_end [lindex $flow_waypoints [expr {$n - 1}]]",
        "    graphics $mid color 1",
        "    graphics $mid sphere $p_start radius 0.34 resolution 26",
        "    graphics $mid color 10",
        "    graphics $mid sphere $p_end radius 0.34 resolution 26",
        "}",
        "",
        "proc update_flow_ball {frame} {",
        "    global mid flow_ball_id flow_delta",
        "    set idx [_frame_to_flow_index $frame]",
        "    set n [llength $flow_delta]",
        "    if {$n < 1} {",
        "        set val 0.0",
        "    } else {",
        "        set val [lindex $flow_delta $idx]",
        "    }",
        "    if {[catch {set nf [molinfo $mid get numframes]}]} {",
        "        set alpha 0.0",
        "    } elseif {$nf < 2} {",
        "        set alpha 0.0",
        "    } else {",
        "        set alpha [expr {$frame / double($nf - 1)}]",
        "    }",
        "    set p [_interp_flow_point $alpha]",
        "    if {[info exists flow_ball_id] && $flow_ball_id >= 0} {",
        "        catch {graphics $mid delete $flow_ball_id}",
        "    }",
        "    set mag [expr {abs($val)}]",
        "    set rad [expr {0.38 + 0.55 * min(1.0, $mag)}]",
        "    if {$val >= 0.0} {",
        "        graphics $mid color 1",
        "    } else {",
        "        graphics $mid color 0",
        "    }",
        "    set flow_ball_id [graphics $mid sphere $p radius $rad resolution 30]",
        "}",
        "",
        "proc _flow_canvas_xy {idx val} {",
        "    global flow_delta_ymax",
        "    set w 560",
        "    set h 290",
        "    set m 52",
        "    set n [llength $::flow_delta]",
        "    if {$n < 2} {",
        "        set frac 0.0",
        "    } else {",
        "        set frac [expr {$idx / double($n - 1)}]",
        "    }",
        "    set x [expr {$m + $frac * ($w - 2.0 * $m)}]",
        "    set yy [expr {$val / max($flow_delta_ymax, 1e-6)}]",
        "    set y [expr {$h / 2.0 - $yy * (($h / 2.0) - $m)}]",
        "    return [list $x $y]",
        "}",
        "",
        "proc setup_flow_panel {} {",
        "    global flow_delta flow_canvas flow_marker flow_frame_text flow_mag_text flow_delta_ymax flow_ready",
        "    set flow_ready 0",
        "    if {[catch {",
        "        if {[winfo exists .flowpanel]} { destroy .flowpanel }",
        "        toplevel .flowpanel",
        "        wm title .flowpanel {Mutation->Binding Flow (Delta)}",
        "        wm geometry .flowpanel 520x260+90+520",
        "        canvas .flowpanel.c -width 520 -height 260 -background #f7fbff -highlightthickness 0",
        "        pack .flowpanel.c -fill both -expand 1",
        "    } err]} {",
        "        puts [format {Flow panel unavailable: %s} $err]",
        "        return",
        "    }",
        "    set c .flowpanel.c",
        "    set flow_canvas $c",
        "    set flow_delta_ymax 1e-6",
        "    foreach v $flow_delta {",
        "        set av [expr {abs($v)}]",
        "        if {$av > $flow_delta_ymax} {",
        "            set flow_delta_ymax $av",
        "        }",
        "    }",
        "    set w 560",
        "    set h 290",
        "    set m 52",
        "    set hmid [expr {$h / 2.0}]",
        "    $c create line $m [expr {$h / 2.0}] [expr {$w - $m}] [expr {$h / 2.0}] -fill #5f7891 -width 2",
        "    $c create line $m $m $m [expr {$h - $m}] -fill #5f7891 -width 2",
        "    $c create text [expr {$w / 2.0}] 16 -text {Delta Flow Over Time (MUT - WT)} -font {Helvetica 12 bold} -fill #17324d",
        "    $c create text [expr {$w / 2.0}] [expr {$h - 16}] -text {X axis: Time window index} -font {Helvetica 11 bold} -fill #0f2a43",
        "    $c create text 78 24 -text {Y axis: Delta flow (MUT-WT)} -font {Helvetica 11 bold} -fill #0f2a43",
        "    $c create text [expr {$m - 10}] [expr {$m + 4}] -text [format {%.2f} $flow_delta_ymax] -font {Helvetica 9} -fill #577590",
        "    $c create text [expr {$m - 10}] [expr {$h - $m - 4}] -text [format {%.2f} [expr {-$flow_delta_ymax}]] -font {Helvetica 9} -fill #577590",
        "    $c create text [expr {$m + 8}] [expr {$h - $m + 12}] -text {0} -font {Helvetica 9} -fill #577590",
        "    $c create text [expr {$w - $m}] [expr {$h - $m + 12}] -text [format {%d} [expr {[llength $flow_delta] - 1}]] -font {Helvetica 9} -fill #577590",
        "    set n [llength $flow_delta]",
        "    for {set i 1} {$i < $n} {incr i} {",
        "        set v0 [lindex $flow_delta [expr {$i - 1}]]",
        "        set v1 [lindex $flow_delta $i]",
        "        lassign [_flow_canvas_xy [expr {$i - 1}] $v0] x0 y0",
        "        lassign [_flow_canvas_xy $i $v1] x1 y1",
        "        set col [expr {$v1 >= 0.0 ? \"#d94841\" : \"#3182bd\"}]",
        "        $c create line $x0 $y0 $x1 $y1 -fill $col -width 2",
        "    }",
        "    set v0 [lindex $flow_delta 0]",
        "    lassign [_flow_canvas_xy 0 $v0] x y",
        "    set flow_marker [$c create oval [expr {$x - 7}] [expr {$y - 7}] [expr {$x + 7}] [expr {$y + 7}] -fill #f59e0b -outline #7c2d12 -width 2]",
        "    set flow_frame_text [$c create text [expr {$w - 88}] 16 -text {Frame 0} -font {Helvetica 10 bold} -fill #17324d]",
        "    set flow_mag_text [$c create text [expr {$w - 90}] 36 -text {Delta 0.00} -font {Helvetica 10} -fill #2f4b69]",
        "    set flow_ready 1",
        "}",
        "",
        "proc update_flow_panel {frame} {",
        "    global mid flow_delta flow_canvas flow_marker flow_frame_text flow_mag_text flow_ready",
        "    if {![info exists flow_ready] || !$flow_ready} { return }",
        "    if {![winfo exists .flowpanel] || ![winfo exists $flow_canvas]} {",
        "        set flow_ready 0",
        "        return",
        "    }",
        "    set n [llength $flow_delta]",
        "    if {$n < 1} { return }",
        "    set idx [_frame_to_flow_index $frame]",
        "    set v [lindex $flow_delta $idx]",
        "    lassign [_flow_canvas_xy $idx $v] x y",
        "    $flow_canvas coords $flow_marker [expr {$x - 7}] [expr {$y - 7}] [expr {$x + 7}] [expr {$y + 7}]",
        "    $flow_canvas itemconfigure $flow_marker -fill [expr {$v >= 0.0 ? \"#d94841\" : \"#3182bd\"}]",
        "    $flow_canvas itemconfigure $flow_frame_text -text [format {Frame %d} $frame]",
        "    $flow_canvas itemconfigure $flow_mag_text -text [format {Delta %.3f} $v]",
        "}",
        "",
        "proc _refresh_flow_network {name index op} {",
        "    global mid",
        "    if {[catch {set f [molinfo $mid get frame]}]} { return }",
        "    update_flow_panel $f",
        "    update_flow_ball $f",
        "}",
        "proc _poll_flow_network {} {",
        "    global mid",
        "    if {[catch {set f [molinfo $mid get frame]}]} {",
        "        after 80 _poll_flow_network",
        "        return",
        "    }",
        "    update_flow_panel $f",
        "    update_flow_ball $f",
        "    after 80 _poll_flow_network",
        "}",
        "",
        "set flow_ball_id -1",
        "draw_flow_path $mid",
        "setup_flow_panel",
        "update_flow_panel 0",
        "update_flow_ball 0",
        "catch {trace remove variable vmd_frame($mid) write _refresh_flow_network}",
        "trace add variable vmd_frame($mid) write _refresh_flow_network",
        "after 80 _poll_flow_network",
        "",
        "animate style Loop",
        "animate speed 0.7",
        "animate goto 0",
        "after 200 {animate forward}",
        "display resetview",
        "puts \"Loaded residue-flow network view.\"",
        "puts \"Red spheres: mutation source residues. Cyan spheres: binding-site targets.\"",
        "puts \"Gold ball moves along the strongest inferred mutation->site route.\"",
        "puts \"Bottom panel shows dynamic Δflow score with labeled axes.\"",
    ]

    os.makedirs(os.path.dirname(output_tcl) or ".", exist_ok=True)
    with open(output_tcl, "w", encoding="utf-8") as handle:
        handle.write("\n".join(lines) + "\n")
    return output_tcl


def _run_residue_flow_analysis(
    wt_pdb: str,
    mut_pdb: str,
    wt_traj_npz: str,
    mut_traj_npz: str,
    mut_dcd: Optional[str],
    binding_csv: str,
    ligand_resname: str,
    output_dir: str,
) -> Dict[str, str]:
    pair_records = _aligned_ca_pair_records(wt_pdb, mut_pdb)
    wt_idx = np.asarray([int(rec["wt_atom_index"]) for rec in pair_records], dtype=int)
    mut_idx = np.asarray([int(rec["mut_atom_index"]) for rec in pair_records], dtype=int)

    wt_data = np.load(wt_traj_npz)
    mut_data = np.load(mut_traj_npz)
    n = min(int(wt_data["positions"].shape[0]), int(mut_data["positions"].shape[0]))
    if n < 10:
        raise ValueError("Not enough frames for residue-flow analysis.")

    wt_pos_raw = np.asarray(wt_data["positions"][:n, wt_idx, :], dtype=float)
    wt_vel_raw = np.asarray(wt_data["velocities"][:n, wt_idx, :], dtype=float)
    mut_pos_raw = np.asarray(mut_data["positions"][:n, mut_idx, :], dtype=float)
    mut_vel_raw = np.asarray(mut_data["velocities"][:n, mut_idx, :], dtype=float)

    wt_pos, wt_vel = _align_positions_and_velocities(wt_pos_raw, wt_vel_raw)
    mut_pos, mut_vel = _align_positions_and_velocities(mut_pos_raw, mut_vel_raw)

    signal_wt = _build_residue_motion_signals(wt_pos, wt_vel, velocity_weight=0.35)
    signal_mut = _build_residue_motion_signals(mut_pos, mut_vel, velocity_weight=0.35)

    source_idx, target_idx = _source_target_indices(pair_records, wt_pdb=wt_pdb, mut_pdb=mut_pdb, binding_csv=binding_csv)
    te_wt = _pairwise_te_matrix(signal_wt, lag=1)
    te_mut = _pairwise_te_matrix(signal_mut, lag=1)
    te_delta = te_mut - te_wt
    te_delta_pos = np.clip(te_delta, 0.0, None)

    relay_score = _relay_scores(te_delta_pos, source_idx=source_idx, target_idx=target_idx)
    top_edges = _top_delta_edges(te_wt=te_wt, te_mut=te_mut, pair_records=pair_records, top_n=28)
    top_paths = _top_paths(te_delta_pos=te_delta_pos, source_idx=source_idx, target_idx=target_idx, pair_records=pair_records, top_n=14)

    if "time_ps" in wt_data.files:
        time_ps = np.asarray(wt_data["time_ps"][:n], dtype=float)
    else:
        dt_ps = 1.0
        if "dt_ps" in wt_data.files:
            dt_ps = float(np.asarray(wt_data["dt_ps"], dtype=float).reshape(-1)[0])
        time_ps = np.arange(n, dtype=float) * dt_ps
    t_win, flow_wt, flow_mut, flow_delta, window_cfg = _windowed_flow_timeseries(
        signal_wt=signal_wt,
        signal_mut=signal_mut,
        time_ps=time_ps,
        source_idx=source_idx,
        target_idx=target_idx,
    )

    total_wt = _flow_score(te_wt, source_idx=source_idx, target_idx=target_idx)
    total_mut = _flow_score(te_mut, source_idx=source_idx, target_idx=target_idx)

    graph_npz = os.path.join(output_dir, "residue_flow_graph.npz")
    np.savez_compressed(
        graph_npz,
        node_label=np.asarray([str(rec["node_label"]) for rec in pair_records], dtype=str),
        chain_id=np.asarray([str(rec["chain_id"]) for rec in pair_records], dtype=str),
        resid=np.asarray([str(rec["resid"]) for rec in pair_records], dtype=str),
        mut_residue_key=np.asarray([str(rec["mut_residue_key"]) for rec in pair_records], dtype=str),
        source_index=np.asarray(source_idx, dtype=int),
        target_index=np.asarray(target_idx, dtype=int),
        te_wt=te_wt,
        te_mut=te_mut,
        te_delta=te_delta,
        relay_score=relay_score,
        flow_time_ps=t_win,
        flow_wt=flow_wt,
        flow_mut=flow_mut,
        flow_delta=flow_delta,
    )

    flow_summary = {
        "nodes": int(len(pair_records)),
        "frames": int(n),
        "source_residues": [str(pair_records[i]["node_label"]) for i in source_idx],
        "target_residues": [str(pair_records[i]["node_label"]) for i in target_idx],
        "window_config": window_cfg,
        "total_flow_wt": float(total_wt),
        "total_flow_mut": float(total_mut),
        "total_flow_delta_mut_minus_wt": float(total_mut - total_wt),
        "top_delta_edges": top_edges,
        "top_mutation_to_binding_paths": top_paths,
        "time_series": {
            "time_ps": [float(v) for v in t_win.tolist()],
            "flow_wt": [float(v) for v in flow_wt.tolist()],
            "flow_mut": [float(v) for v in flow_mut.tolist()],
            "flow_delta": [float(v) for v in flow_delta.tolist()],
        },
    }
    summary_path = os.path.join(output_dir, "flow_summary.json")
    with open(summary_path, "w", encoding="utf-8") as handle:
        json.dump(flow_summary, handle, indent=2)

    flow_plot = os.path.join(output_dir, "plot_flow_timeseries.png")
    _plot_flow_timeseries(t_win, flow_wt, flow_mut, flow_delta, out_png=flow_plot)

    flow_vmd = _write_flow_network_vmd_script(
        mut_pdb=mut_pdb,
        mut_dcd=mut_dcd,
        ligand_resname=ligand_resname,
        pair_records=pair_records,
        top_edges=top_edges,
        source_idx=source_idx,
        target_idx=target_idx,
        relay_scores=relay_score,
        flow_delta_series=flow_delta,
        top_paths=top_paths,
        output_tcl=os.path.join(output_dir, "view_flow_network.vmd.tcl"),
    )

    return {
        "graph_npz": graph_npz,
        "summary_json": summary_path,
        "plot_png": flow_plot,
        "vmd_script": flow_vmd,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-dir", required=True, help="Pipeline run directory (contains run_summary.json).")
    parser.add_argument("--ligand-resname", default="ZN", help="Ligand residue name to define binding-site shell.")
    parser.add_argument("--cutoff-ang", type=float, default=6.0, help="Binding-site cutoff around ligand.")
    args = parser.parse_args()

    run_dir = args.run_dir
    summary = _load_json(os.path.join(run_dir, "run_summary.json"))
    analysis = summary["analysis"]
    analysis_dir = os.path.join(run_dir, "analysis")
    os.makedirs(analysis_dir, exist_ok=True)

    _plot_basin_ddg(analysis, os.path.join(analysis_dir, "plot_basin_ddg.png"))
    _plot_latent_trajectory(os.path.join(analysis_dir, "latents.npz"), os.path.join(analysis_dir, "plot_latent_trajectory.png"))
    _plot_te(analysis, os.path.join(analysis_dir, "plot_te.png"))
    _plot_susceptibility_quiver(analysis, os.path.join(analysis_dir, "plot_susceptibility_quiver.png"))

    _write_binding_csv(
        wt_pdb=_resolve_run_path(run_dir, summary["md"]["wt"]["prepared_pdb"]),
        mut_pdb=_resolve_run_path(run_dir, summary["md"]["mut"]["prepared_pdb"]),
        ligand_resname=args.ligand_resname,
        cutoff_ang=args.cutoff_ang,
        out_csv=os.path.join(analysis_dir, "binding_site_residues.csv"),
    )

    vmd_script = None
    if isinstance(summary.get("visualization"), dict):
        vmd_script = summary["visualization"].get("vmd_script")
    if vmd_script:
        vmd_script = _resolve_run_path(run_dir, vmd_script)
    if not vmd_script or not os.path.exists(vmd_script):
        vmd_script = os.path.join(analysis_dir, "view_wt_mut.vmd.tcl")
        write_vmd_comparison_script(
            wt_pdb=_resolve_run_path(run_dir, summary["md"]["wt"]["prepared_pdb"]),
            wt_dcd=_resolve_run_path(run_dir, summary["md"]["wt"]["traj_dcd"])
            if summary["md"]["wt"].get("traj_dcd")
            else None,
            mut_pdb=_resolve_run_path(run_dir, summary["md"]["mut"]["prepared_pdb"]),
            mut_dcd=_resolve_run_path(run_dir, summary["md"]["mut"]["traj_dcd"])
            if summary["md"]["mut"].get("traj_dcd")
            else None,
            ligand_resnames=[args.ligand_resname],
            output_tcl=vmd_script,
            site_cutoff_ang=args.cutoff_ang,
            latents_npz=os.path.join(analysis_dir, "latents.npz"),
        )

    flow_outputs = _run_residue_flow_analysis(
        wt_pdb=_resolve_run_path(run_dir, summary["md"]["wt"]["prepared_pdb"]),
        mut_pdb=_resolve_run_path(run_dir, summary["md"]["mut"]["prepared_pdb"]),
        wt_traj_npz=_resolve_run_path(run_dir, summary["md"]["wt"]["traj_npz"]),
        mut_traj_npz=_resolve_run_path(run_dir, summary["md"]["mut"]["traj_npz"]),
        mut_dcd=_resolve_run_path(run_dir, summary["md"]["mut"]["traj_dcd"])
        if summary["md"]["mut"].get("traj_dcd")
        else None,
        binding_csv=os.path.join(analysis_dir, "binding_site_residues.csv"),
        ligand_resname=args.ligand_resname,
        output_dir=analysis_dir,
    )

    script_path = os.path.relpath(vmd_script, run_dir) if vmd_script else None
    mut_flow_script = _write_mut_flow_vmd_script(
        wt_pdb=_resolve_run_path(run_dir, summary["md"]["wt"]["prepared_pdb"]),
        mut_pdb=_resolve_run_path(run_dir, summary["md"]["mut"]["prepared_pdb"]),
        mut_dcd=_resolve_run_path(run_dir, summary["md"]["mut"]["traj_dcd"])
        if summary["md"]["mut"].get("traj_dcd")
        else None,
        mut_traj_npz=_resolve_run_path(run_dir, summary["md"]["mut"]["traj_npz"])
        if summary["md"]["mut"].get("traj_npz")
        else None,
        latents_npz=os.path.join(analysis_dir, "latents.npz"),
        ligand_resname=args.ligand_resname,
        binding_csv=os.path.join(analysis_dir, "binding_site_residues.csv"),
        output_tcl=os.path.join(analysis_dir, "view_mut_flow.vmd.tcl"),
        cutoff_ang=args.cutoff_ang,
        analysis=analysis,
    )
    mut_flow_rel = os.path.relpath(mut_flow_script, run_dir)
    manifest = {
        "plots": [
            "analysis/plot_basin_ddg.png",
            "analysis/plot_latent_trajectory.png",
            "analysis/plot_te.png",
            "analysis/plot_susceptibility_quiver.png",
            os.path.relpath(flow_outputs["plot_png"], run_dir),
        ],
        "tables": [
            "analysis/binding_site_residues.csv",
            os.path.relpath(flow_outputs["summary_json"], run_dir),
        ],
        "artifacts": [
            os.path.relpath(flow_outputs["graph_npz"], run_dir),
        ],
    }
    scripts: List[str] = []
    if script_path is not None:
        scripts.append(script_path)
    scripts.append(mut_flow_rel)
    scripts.append(os.path.relpath(flow_outputs["vmd_script"], run_dir))
    manifest["scripts"] = scripts
    with open(os.path.join(analysis_dir, "plot_manifest.json"), "w", encoding="utf-8") as handle:
        json.dump(manifest, handle, indent=2)
    print(json.dumps(manifest, indent=2))


if __name__ == "__main__":
    main()
