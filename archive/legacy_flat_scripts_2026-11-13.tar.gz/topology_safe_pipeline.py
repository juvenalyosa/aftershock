"""
Topology-safe WT/MUT MD comparison pipeline.

This module implements an end-to-end workflow that:
1) builds a mutant structure with `genmodels.buildm` + `mutator`,
2) transfers ligand coordinates from a WT reference PDB to the mutant,
3) runs WT/MUT MD with OpenMM 8.x,
4) computes topology-safe pocket/context/ligand embeddings in a moving pocket frame,
5) compares ensembles with basin ΔΔG, distribution shift, and linear-Gaussian TE/Granger.
"""

from __future__ import annotations

import argparse
import json
import math
import os
import re
import shutil
from contextlib import contextmanager
from dataclasses import dataclass, replace
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np

try:
    from openmm import MonteCarloBarostat, Platform, Vec3, unit
    from openmm import LangevinMiddleIntegrator
    from openmm import app
except Exception:  # pragma: no cover - validated at runtime by ensure_openmm()
    MonteCarloBarostat = None
    Platform = None
    Vec3 = None
    unit = None
    LangevinMiddleIntegrator = None
    app = None

try:
    from sklearn.linear_model import LogisticRegression
    from sklearn.mixture import GaussianMixture
except Exception:  # pragma: no cover - validated at runtime by ensure_sklearn()
    LogisticRegression = None
    GaussianMixture = None

try:
    from scipy import stats as scipy_stats
except Exception:  # pragma: no cover
    scipy_stats = None

from mutator import MutationError, mutate_sequence, needleman_wunsch_affine


AA3_TO_1 = {
    "ALA": "A",
    "ARG": "R",
    "ASN": "N",
    "ASP": "D",
    "CYS": "C",
    "GLN": "Q",
    "GLU": "E",
    "GLY": "G",
    "HIS": "H",
    "HID": "H",
    "HIE": "H",
    "HIP": "H",
    "ILE": "I",
    "LEU": "L",
    "LYS": "K",
    "MET": "M",
    "PHE": "F",
    "PRO": "P",
    "SER": "S",
    "THR": "T",
    "TRP": "W",
    "TYR": "Y",
    "VAL": "V",
    "SEC": "U",
    "PYL": "O",
    "MSE": "M",
}

WATER_RESNAMES = {"HOH", "WAT", "TIP3", "TIP3P", "SOL", "H2O"}
HALOGENS = {"F", "CL", "BR", "I"}
METALS = {
    "LI",
    "NA",
    "K",
    "RB",
    "CS",
    "MG",
    "CA",
    "SR",
    "BA",
    "ZN",
    "CU",
    "MN",
    "FE",
    "CO",
    "NI",
    "CD",
    "HG",
    "AL",
}

TYPE_BINS = ["C", "N", "O", "S", "P", "H", "HALOGEN", "METAL", "OTHER"]
TYPE_TO_INDEX = {name: i for i, name in enumerate(TYPE_BINS)}


def ensure_openmm() -> None:
    if app is None or unit is None:
        raise ImportError(
            "OpenMM is required but not available. Install OpenMM 8.x "
            "(e.g., `conda install -c conda-forge openmm`)."
        )


def ensure_sklearn() -> None:
    if GaussianMixture is None or LogisticRegression is None:
        raise ImportError(
            "scikit-learn is required for GMM/JS components. "
            "Install with `pip install scikit-learn`."
        )


@contextmanager
def pushd(path: str) -> Iterable[None]:
    old = os.getcwd()
    os.makedirs(path, exist_ok=True)
    os.chdir(path)
    try:
        yield
    finally:
        os.chdir(old)


@dataclass
class BuildConfig:
    reference_pdb: str
    ligand_xml: str
    ligand_resnames: List[str]
    mutations: List[str]
    templates: List[str]
    chain_id: Optional[str] = "A"
    original_sequence: Optional[str] = None
    start_pos: Optional[int] = None
    num_models: int = 50
    num_processors: int = 4
    modeller_seed: Optional[int] = None


@dataclass
class MDConfig:
    temperature_k: float = 300.0
    friction_per_ps: float = 1.0
    timestep_fs: float = 2.0
    pressure_bar: float = 1.0
    barostat_interval: int = 25
    nonbonded_method: str = "PME"
    nonbonded_cutoff_nm: float = 1.0
    add_solvent: bool = True
    water_model: str = "tip3p"
    solvent_padding_nm: float = 1.0
    ionic_strength_m: float = 0.15
    neutralize: bool = True
    positive_ion: str = "Na+"
    negative_ion: str = "Cl-"
    minimization_max_iterations: int = 500
    heating_initial_temperature_k: float = 50.0
    heating_steps: int = 5000
    heating_stages: int = 10
    equilibration_steps: int = 5000
    production_steps: int = 50000
    report_interval: int = 100
    platform: str = "CPU"
    random_seed: Optional[int] = None


@dataclass
class FieldConfig:
    rb_ang: float = 6.0
    rp_ang: float = 12.0
    grid_spacing_ang: float = 1.2
    sigma_ang: float = 1.2
    max_grid_points: int = 512
    include_velocity: bool = True
    remove_com: bool = True
    density_normalize: bool = True
    append_type_counts: bool = True


@dataclass
class LatentConfig:
    lag: int = 5
    m_b: int = 10
    m_p: int = 10
    m_l: int = 6
    reg: float = 1e-6


@dataclass
class TEConfig:
    max_order: int = 6
    ridge_values: Tuple[float, ...] = (1e-8, 1e-6, 1e-4, 1e-2)
    surrogates: int = 64
    whiteness_lag: int = 10
    whiteness_threshold: float = 0.2
    random_seed: int = 13


@dataclass
class PreparedStructures:
    wt_pdb: str
    mutant_raw_pdb: str
    mutant_ligand_pdb: str
    original_sequence: str
    mutated_sequence: str
    start_pos: int
    alignment_pairs: int
    local_alignment_pairs: int
    local_alignment_rmsd_ang: float
    ligand_atoms: int


@dataclass
class MDRunArtifacts:
    prepared_pdb: str
    trajectory_npz: str
    trajectory_dcd: Optional[str]
    log_path: str
    dt_ps: float
    n_frames: int


def parse_csv_or_repeat(values: Sequence[str]) -> List[str]:
    out: List[str] = []
    for value in values:
        for token in value.split(","):
            token = token.strip()
            if token:
                out.append(token)
    return out


def _tcl_braced_path(path: Optional[str]) -> str:
    if not path:
        return "{}"
    norm = os.path.abspath(path).replace("\\", "/").replace("}", "\\}")
    return "{" + norm + "}"


def _binding_site_keys_from_pdb(
    pdb_path: str,
    ligand_resnames: Sequence[str],
    cutoff_ang: float,
) -> List[Tuple[str, str]]:
    ensure_openmm()
    ligand_set = {name.strip().upper() for name in ligand_resnames if name.strip()}
    if not ligand_set:
        return []
    pdb = app.PDBFile(pdb_path)
    pos_nm = np.asarray(pdb.positions.value_in_unit(unit.nanometer), dtype=float)
    lig_idx = [atom.index for atom in pdb.topology.atoms() if atom.residue.name.upper() in ligand_set]
    if not lig_idx:
        return []
    lig_xyz = pos_nm[lig_idx]
    cutoff_nm = float(cutoff_ang) * 0.1
    keys: List[Tuple[str, str]] = []
    for chain in pdb.topology.chains():
        chain_id = (chain.id or "").strip()
        for residue in chain.residues():
            if residue.name.upper() not in AA3_TO_1:
                continue
            atom_idx = [a.index for a in residue.atoms() if (a.element is None or a.element.symbol != "H")]
            if not atom_idx:
                continue
            xyz = pos_nm[atom_idx]
            d = np.linalg.norm(xyz[:, None, :] - lig_xyz[None, :, :], axis=2)
            if float(np.min(d)) <= cutoff_nm:
                keys.append((chain_id, str(residue.id).strip()))
    return sorted(set(keys))


def _site_selection_from_keys(keys: Sequence[Tuple[str, str]]) -> str:
    if not keys:
        return "none"
    terms: List[str] = []
    for chain_id, resid in keys:
        if chain_id:
            terms.append(f"(chain {chain_id} and resid {resid})")
        else:
            terms.append(f"(resid {resid})")
    return "protein and (" + " or ".join(terms) + ")"


def write_vmd_comparison_script(
    wt_pdb: str,
    mut_pdb: str,
    output_tcl: str,
    ligand_resnames: Sequence[str],
    wt_dcd: Optional[str] = None,
    mut_dcd: Optional[str] = None,
    site_cutoff_ang: float = 6.0,
    latents_npz: Optional[str] = None,
) -> str:
    ligand_tokens = [name.strip().upper() for name in ligand_resnames if name.strip()]
    if ligand_tokens:
        ligand_sel = " or ".join([f"resname {name}" for name in ligand_tokens])
    else:
        ligand_sel = "none"

    delta_latent_xy: List[Tuple[float, float]] = [(0.0, 0.0)]
    if latents_npz and os.path.exists(latents_npz):
        try:
            lat = np.load(latents_npz)
            u_wt = np.asarray(lat["u_b_wt"], dtype=float)
            u_mut = np.asarray(lat["u_b_mut"], dtype=float)
            n = min(int(u_wt.shape[0]), int(u_mut.shape[0]))
            if n > 0:
                d = min(int(u_wt.shape[1]), int(u_mut.shape[1]))
                if d >= 2:
                    du = u_mut[:n, :2] - u_wt[:n, :2]
                elif d == 1:
                    du = np.column_stack([u_mut[:n, 0] - u_wt[:n, 0], np.zeros(n, dtype=float)])
                else:
                    du = np.zeros((n, 2), dtype=float)
                sx = max(float(np.max(np.abs(du[:, 0]))), 1e-8)
                sy = max(float(np.max(np.abs(du[:, 1]))), 1e-8)
                delta_latent_xy = [(float(row[0] / sx), float(row[1] / sy)) for row in du]
                if not delta_latent_xy:
                    delta_latent_xy = [(0.0, 0.0)]
        except Exception:
            delta_latent_xy = [(0.0, 0.0)]
    delta_latent_xy_tcl = " ".join(f"{{{xy[0]:.6f} {xy[1]:.6f}}}" for xy in delta_latent_xy)

    wt_site_keys = set(_binding_site_keys_from_pdb(wt_pdb, ligand_tokens, site_cutoff_ang))
    mut_site_keys = set(_binding_site_keys_from_pdb(mut_pdb, ligand_tokens, site_cutoff_ang))
    wt_diff_sel = _site_selection_from_keys(sorted(wt_site_keys - mut_site_keys))
    mut_diff_sel = _site_selection_from_keys(sorted(mut_site_keys - wt_site_keys))

    lines = [
        "# Auto-generated WT/MUT comparison view for VMD",
        "display projection Orthographic",
        "display depthcue off",
        "axes location Off",
        "color Display Background white",
        "",
        f"set wt_pdb {_tcl_braced_path(wt_pdb)}",
        f"set wt_dcd {_tcl_braced_path(wt_dcd)}",
        f"set mut_pdb {_tcl_braced_path(mut_pdb)}",
        f"set mut_dcd {_tcl_braced_path(mut_dcd)}",
        f"set ligand_sel {{{ligand_sel}}}",
        f"set site_cutoff {float(site_cutoff_ang):.3f}",
        f"set delta_latent_xy {{{delta_latent_xy_tcl}}}",
        f"set wt_diff_site_sel {{{wt_diff_sel}}}",
        f"set mut_diff_site_sel {{{mut_diff_sel}}}",
        "",
        "proc align_to_first {mid sel_text} {",
        "    set ref [atomselect $mid $sel_text frame 0]",
        "    if {[$ref num] < 3} {",
        "        $ref delete",
        "        return",
        "    }",
        "    set mob [atomselect $mid $sel_text]",
        "    set all [atomselect $mid all]",
        "    set nframes [molinfo $mid get numframes]",
        "    for {set f 0} {$f < $nframes} {incr f} {",
        "        $mob frame $f",
        "        $all frame $f",
        "        set xf [measure fit $mob $ref]",
        "        $all move $xf",
        "    }",
        "    $ref delete",
        "    $mob delete",
        "    $all delete",
        "}",
        "",
        "proc pick_alignment_selection {ref_mol mob_mol ligand_sel} {",
        "    set ref [atomselect $ref_mol \"protein and name CA\" frame 0]",
        "    set mob [atomselect $mob_mol \"protein and name CA\" frame 0]",
        "    set ok [expr {[$ref num] > 2 && [$ref num] == [$mob num]}]",
        "    $ref delete",
        "    $mob delete",
        "    if {$ok} {",
        "        return {protein and name CA}",
        "    }",
        "    if {$ligand_sel ne \"none\"} {",
        "        set ref [atomselect $ref_mol \"($ligand_sel) and not hydrogen\" frame 0]",
        "        set mob [atomselect $mob_mol \"($ligand_sel) and not hydrogen\" frame 0]",
        "        set ok [expr {[$ref num] > 2 && [$ref num] == [$mob num]}]",
        "        $ref delete",
        "        $mob delete",
        "        if {$ok} {",
        "            return \"($ligand_sel) and not hydrogen\"",
        "        }",
        "    }",
        "    return {}",
        "}",
        "",
        "proc fit_mobile_to_ref_per_frame {ref_mol mob_mol ligand_sel} {",
        "    set sel [pick_alignment_selection $ref_mol $mob_mol $ligand_sel]",
        "    if {$sel eq \"\"} {",
        "        return",
        "    }",
        "    set nref [molinfo $ref_mol get numframes]",
        "    set nmob [molinfo $mob_mol get numframes]",
        "    set nframes [expr {$nref < $nmob ? $nref : $nmob}]",
        "    for {set f 0} {$f < $nframes} {incr f} {",
        "        set ref [atomselect $ref_mol $sel frame $f]",
        "        set mob [atomselect $mob_mol $sel frame $f]",
        "        if {[$ref num] > 2 && [$ref num] == [$mob num]} {",
        "            set xf [measure fit $mob $ref]",
        "            set all [atomselect $mob_mol all]",
        "            $all frame $f",
        "            $all move $xf",
        "            $all delete",
        "        }",
        "        $ref delete",
        "        $mob delete",
        "    }",
        "}",
        "",
        "proc load_system_view {pdb_path dcd_path ligand_sel site_cutoff site_sel_text prot_color lig_color site_color prot_material site_material site_rad show_protein mol_name} {",
        "    mol new $pdb_path type pdb waitfor all",
        "    set mid [molinfo top]",
        "    if {[string length $dcd_path] > 0 && [file exists $dcd_path]} {",
        "        mol addfile $dcd_path type dcd waitfor all molid $mid",
        "    }",
        "    align_to_first $mid {protein and name CA}",
        "    mol rename $mid $mol_name",
        "    mol delrep 0 $mid",
        "",
        "    if {$show_protein > 0} {",
        "        mol representation NewCartoon 0.24 20.0 4.1 0",
        "        mol color ColorID $prot_color",
        "        mol selection {protein}",
        "        mol material $prot_material",
        "        mol addrep $mid",
        "    }",
        "",
        "    mol representation Licorice 0.20 18.0 18.0",
        "    mol color ColorID $lig_color",
        "    mol selection $ligand_sel",
        "    mol material Glossy",
        "    mol addrep $mid",
        "",
        "    if {$site_sel_text ne \"none\"} {",
        "        mol representation QuickSurf $site_rad 0.6 1.0 1.0",
        "        mol color ColorID $site_color",
        "        mol selection $site_sel_text",
        "        mol material $site_material",
        "        mol addrep $mid",
        "    }",
        "",
        "    return $mid",
        "}",
        "",
        "set wt_side [load_system_view $wt_pdb $wt_dcd $ligand_sel $site_cutoff {none} 6 4 10 AOShiny Transparent 1.0 1 WT_SIDE]",
        "set mut_side [load_system_view $mut_pdb $mut_dcd $ligand_sel $site_cutoff {none} 1 3 9 AOShiny Transparent 1.0 1 MUT_SIDE]",
        "fit_mobile_to_ref_per_frame $wt_side $mut_side $ligand_sel",
        "",
        "set wt_all [atomselect $wt_side all]",
        "$wt_all moveby {-18.0 0.0 0.0}",
        "$wt_all delete",
        "set mut_all [atomselect $mut_side all]",
        "$mut_all moveby {18.0 0.0 0.0}",
        "$mut_all delete",
        "",
        "set wt_overlay [load_system_view $wt_pdb $wt_dcd $ligand_sel $site_cutoff $wt_diff_site_sel 10 4 10 Transparent Transparent 1.0 0 WT_OVERLAY]",
        "set mut_overlay [load_system_view $mut_pdb $mut_dcd $ligand_sel $site_cutoff $mut_diff_site_sel 3 3 27 Transparent Transparent 1.22 0 MUT_OVERLAY]",
        "fit_mobile_to_ref_per_frame $wt_overlay $mut_overlay $ligand_sel",
        "",
        "set wt_overlay_all [atomselect $wt_overlay all]",
        "$wt_overlay_all moveby {0.0 0.0 0.0}",
        "$wt_overlay_all delete",
        "set mut_overlay_all [atomselect $mut_overlay all]",
        "$mut_overlay_all moveby {0.0 0.0 0.0}",
        "$mut_overlay_all delete",
        "",
        "mol top $wt_side",
        "",
        "proc _clip01 {x} {",
        "    if {$x < 0.0} { return 0.0 }",
        "    if {$x > 1.0} { return 1.0 }",
        "    return $x",
        "}",
        "",
        "proc _delta_time_color {t} {",
        "    set tt [_clip01 $t]",
        "    set r [expr {int(56 + 184 * $tt)}]",
        "    set g [expr {int(136 + 10 * $tt)}]",
        "    set b [expr {int(192 - 150 * $tt)}]",
        "    return [format \"#%02x%02x%02x\" $r $g $b]",
        "}",
        "",
        "proc _delta_canvas_xy {dx dy} {",
        "    set w 560",
        "    set h 420",
        "    set m 58",
        "    set x [expr {$w / 2.0 + $dx * (($w / 2.0) - $m)}]",
        "    set y [expr {$h / 2.0 - $dy * (($h / 2.0) - $m)}]",
        "    return [list $x $y]",
        "}",
        "",
        "proc setup_delta_latent_window {} {",
        "    global delta_latent_xy delta_canvas delta_marker delta_frame_text delta_mag_text delta_ready",
        "    set delta_ready 0",
        "    if {[catch {",
        "        if {[winfo exists .delta2d]} { destroy .delta2d }",
        "        toplevel .delta2d",
        "        wm title .delta2d {WT vs MUT Delta Latent Map}",
        "        wm geometry .delta2d 560x420+700+80",
        "        canvas .delta2d.c -width 560 -height 420 -background #f5f9ff -highlightthickness 0",
        "        pack .delta2d.c -fill both -expand 1",
        "    } err]} {",
        "        puts [format {Delta latent window unavailable: %s} $err]",
        "        return",
        "    }",
        "    set c .delta2d.c",
        "    set delta_canvas $c",
        "    set w 560",
        "    set h 420",
        "    set m 58",
        "    for {set i 0} {$i <= 6} {incr i} {",
        "        set x [expr {$m + $i * ($w - 2.0 * $m) / 6.0}]",
        "        set y [expr {$m + $i * ($h - 2.0 * $m) / 6.0}]",
        "        $c create line $x $m $x [expr {$h - $m}] -fill #d8e3f2 -width 1",
        "        $c create line $m $y [expr {$w - $m}] $y -fill #d8e3f2 -width 1",
        "    }",
        "    $c create line $m [expr {$h / 2.0}] [expr {$w - $m}] [expr {$h / 2.0}] -fill #607992 -width 2",
        "    $c create line [expr {$w / 2.0}] $m [expr {$w / 2.0}] [expr {$h - $m}] -fill #607992 -width 2",
        "    $c create text [expr {$w / 2.0}] 20 -text {Delta Latent Map (MUT - WT)} -font {Helvetica 15 bold} -fill #17324d",
        "    $c create text [expr {$w / 2.0}] 42 -text {Center = no difference; farther = larger difference} -font {Helvetica 10 italic} -fill #47657f",
        "    $c create text [expr {$w / 2.0}] [expr {$h - 20}] -text {Delta axis 1} -font {Helvetica 11} -fill #17324d",
        "    $c create text 24 [expr {$h / 2.0}] -text {Delta axis 2} -angle 90 -font {Helvetica 11} -fill #17324d",
        "    set n [llength $delta_latent_xy]",
        "    for {set i 1} {$i < $n} {incr i} {",
        "        set p0 [lindex $delta_latent_xy [expr {$i - 1}]]",
        "        set p1 [lindex $delta_latent_xy $i]",
        "        lassign [_delta_canvas_xy [lindex $p0 0] [lindex $p0 1]] x0 y0",
        "        lassign [_delta_canvas_xy [lindex $p1 0] [lindex $p1 1]] x1 y1",
        "        set t [expr {$i / double(max($n - 1, 1))}]",
        "        $c create line $x0 $y0 $x1 $y1 -fill [_delta_time_color $t] -width 2",
        "    }",
        "    set p_init [lindex $delta_latent_xy 0]",
        "    lassign [_delta_canvas_xy [lindex $p_init 0] [lindex $p_init 1]] x y",
        "    set delta_marker [$c create oval [expr {$x - 8}] [expr {$y - 8}] [expr {$x + 8}] [expr {$y + 8}] -fill #2563eb -outline #0f172a -width 2]",
        "    set delta_frame_text [$c create text [expr {$w - 102}] 20 -text {Frame 0} -font {Helvetica 11 bold} -fill #17324d]",
        "    set delta_mag_text [$c create text [expr {$w - 108}] 42 -text {Delta 0.00} -font {Helvetica 10} -fill #2f4b69]",
        "    set delta_ready 1",
        "}",
        "",
        "proc update_delta_latent_window {frame} {",
        "    global delta_latent_xy delta_canvas delta_marker delta_frame_text delta_mag_text delta_ready",
        "    if {![info exists delta_ready] || !$delta_ready} { return }",
        "    if {![winfo exists .delta2d] || ![winfo exists $delta_canvas]} {",
        "        set delta_ready 0",
        "        return",
        "    }",
        "    set n [llength $delta_latent_xy]",
        "    if {$n < 1} { return }",
        "    set idx $frame",
        "    if {$idx < 0} { set idx 0 }",
        "    if {$idx >= $n} { set idx [expr {$n - 1}] }",
        "    set p [lindex $delta_latent_xy $idx]",
        "    set dx [lindex $p 0]",
        "    set dy [lindex $p 1]",
        "    lassign [_delta_canvas_xy $dx $dy] x y",
        "    $delta_canvas coords $delta_marker [expr {$x - 8}] [expr {$y - 8}] [expr {$x + 8}] [expr {$y + 8}]",
        "    set mag [expr {sqrt($dx*$dx + $dy*$dy)}]",
        "    set tt [expr {$idx / double(max($n - 1, 1))}]",
        "    $delta_canvas itemconfigure $delta_marker -fill [_delta_time_color $tt]",
        "    $delta_canvas itemconfigure $delta_frame_text -text [format {Frame %d/%d} $idx [expr {$n - 1}]]",
        "    $delta_canvas itemconfigure $delta_mag_text -text [format {Delta %.2f} $mag]",
        "}",
        "",
        "proc sync_comparison_frames {name index op} {",
        "    global wt_side mut_side wt_overlay mut_overlay",
        "    if {[catch {set f [molinfo $wt_side get frame]}]} {",
        "        return",
        "    }",
        "    foreach m [list $mut_side $wt_overlay $mut_overlay] {",
        "        if {[catch {set nf [molinfo $m get numframes]}]} {",
        "            continue",
        "        }",
        "        if {$nf < 1} {",
        "            continue",
        "        }",
        "        set ff $f",
        "        if {$ff >= $nf} {",
        "            set ff [expr {$nf - 1}]",
        "        }",
        "        molinfo $m set frame $ff",
        "    }",
        "    update_delta_latent_window $f",
        "}",
        "proc poll_delta_sync {} {",
        "    global wt_side",
        "    if {[catch {set f [molinfo $wt_side get frame]}]} {",
        "        after 80 poll_delta_sync",
        "        return",
        "    }",
        "    sync_comparison_frames _ _ _",
        "    after 80 poll_delta_sync",
        "}",
        "setup_delta_latent_window",
        "catch {trace remove variable vmd_frame($wt_side) write sync_comparison_frames}",
        "trace add variable vmd_frame($wt_side) write sync_comparison_frames",
        "after 80 poll_delta_sync",
        "",
        "animate style Loop",
        "animate speed 0.7",
        "animate goto 0",
        "sync_comparison_frames _ _ _",
        "after 200 {animate forward}",
        "display resetview",
        "puts \"Loaded WT/MUT comparison.\"",
        "puts \"Left: WT (blue). Right: MUT (red). Center: WT/MUT transparent overlay.\"",
        "puts \"All views are aligned frame-by-frame before comparison.\"",
        "puts \"Delta Latent window shows (MUT-WT) trajectory; moving dot follows current frame.\"",
        "puts \"Center in Delta Latent means similar states; larger distance means stronger divergence.\"",
        "puts \"Center view shows only differential shells: WT-only (cyan) and MUT-only (purple).\"",
    ]
    os.makedirs(os.path.dirname(output_tcl) or ".", exist_ok=True)
    with open(output_tcl, "w", encoding="utf-8") as handle:
        handle.write("\n".join(lines) + "\n")
    return output_tcl


def is_protein_residue(resname: str) -> bool:
    return resname.upper() in AA3_TO_1


def residue_to_aa1(resname: str) -> Optional[str]:
    return AA3_TO_1.get(resname.upper())


def parse_residue_number(residue_id: str) -> Optional[int]:
    match = re.search(r"-?\d+", str(residue_id))
    if match:
        return int(match.group(0))
    return None


def atom_type_bin(symbol: Optional[str]) -> int:
    if not symbol:
        return TYPE_TO_INDEX["OTHER"]
    sym = symbol.upper()
    if sym in TYPE_TO_INDEX:
        return TYPE_TO_INDEX[sym]
    if sym in HALOGENS:
        return TYPE_TO_INDEX["HALOGEN"]
    if sym in METALS:
        return TYPE_TO_INDEX["METAL"]
    return TYPE_TO_INDEX["OTHER"]


def sequence_and_start_from_pdb(pdb_path: str, chain_id: Optional[str]) -> Tuple[str, int]:
    ensure_openmm()
    pdb = app.PDBFile(pdb_path)
    seq_chars: List[str] = []
    first_pos: Optional[int] = None
    for chain in pdb.topology.chains():
        if chain_id and chain.id != chain_id:
            continue
        for residue in chain.residues():
            if not is_protein_residue(residue.name):
                continue
            aa1 = residue_to_aa1(residue.name)
            if aa1 is None:
                continue
            seq_chars.append(aa1)
            if first_pos is None:
                parsed = parse_residue_number(residue.id)
                if parsed is not None:
                    first_pos = parsed
        if seq_chars:
            break
    if not seq_chars:
        raise ValueError(
            f"No protein residues found in chain '{chain_id}' for {pdb_path}."
        )
    if first_pos is None:
        first_pos = 1
    return "".join(seq_chars), first_pos


def _extract_ligand_subset(
    topology: "app.Topology",
    positions: "unit.Quantity",
    ligand_resnames: Sequence[str],
) -> Tuple["app.Topology", List["unit.Quantity"], List[int]]:
    ensure_openmm()
    ligand_names = {name.upper() for name in ligand_resnames}
    lig_top = app.Topology()
    atom_map = {}
    selected_indices: List[int] = []
    lig_positions: List[unit.Quantity] = []
    chain_cache = {}

    for chain in topology.chains():
        for residue in chain.residues():
            if residue.name.upper() not in ligand_names:
                continue
            if chain not in chain_cache:
                chain_cache[chain] = lig_top.addChain(chain.id)
            new_chain = chain_cache[chain]
            new_res = lig_top.addResidue(
                residue.name,
                new_chain,
                id=residue.id,
                insertionCode=residue.insertionCode,
            )
            for atom in residue.atoms():
                new_atom = lig_top.addAtom(
                    atom.name,
                    atom.element,
                    new_res,
                    id=atom.id,
                    formalCharge=atom.formalCharge,
                )
                atom_map[atom] = new_atom
                selected_indices.append(atom.index)
                lig_positions.append(positions[atom.index])

    for atom1, atom2 in topology.bonds():
        if atom1 in atom_map and atom2 in atom_map:
            try:
                lig_top.addBond(atom_map[atom1], atom_map[atom2], type=None, order=None)
            except TypeError:
                lig_top.addBond(atom_map[atom1], atom_map[atom2])

    return lig_top, lig_positions, selected_indices


def _protein_ca_records(
    topology: "app.Topology",
    positions: "unit.Quantity",
    chain_id: Optional[str],
) -> List[Tuple[str, np.ndarray]]:
    ensure_openmm()
    pos_nm = np.asarray(positions.value_in_unit(unit.nanometer), dtype=float)
    records: List[Tuple[str, np.ndarray]] = []
    for chain in topology.chains():
        if chain_id and chain.id != chain_id:
            continue
        for residue in chain.residues():
            if not is_protein_residue(residue.name):
                continue
            aa1 = residue_to_aa1(residue.name)
            if aa1 is None:
                continue
            ca_atom = None
            for atom in residue.atoms():
                if atom.name == "CA":
                    ca_atom = atom
                    break
            if ca_atom is None:
                continue
            records.append((aa1, pos_nm[ca_atom.index].copy()))
        if records:
            break
    return records


def _align_index_pairs(seq_ref: str, seq_mut: str) -> List[Tuple[int, int]]:
    aligned_ref, aligned_mut = needleman_wunsch_affine(seq_ref, seq_mut)
    pairs: List[Tuple[int, int]] = []
    idx_ref = 0
    idx_mut = 0
    for aa_ref, aa_mut in zip(aligned_ref, aligned_mut):
        ref_here = None
        mut_here = None
        if aa_ref != "-":
            ref_here = idx_ref
            idx_ref += 1
        if aa_mut != "-":
            mut_here = idx_mut
            idx_mut += 1
        if ref_here is not None and mut_here is not None:
            pairs.append((ref_here, mut_here))
    return pairs


def _kabsch(src_points: np.ndarray, dst_points: np.ndarray) -> Tuple[np.ndarray, np.ndarray, float]:
    if src_points.shape != dst_points.shape:
        raise ValueError("Kabsch source and destination arrays must have equal shape.")
    if src_points.shape[0] < 3:
        raise ValueError("At least 3 points are required for Kabsch alignment.")

    src_centroid = src_points.mean(axis=0)
    dst_centroid = dst_points.mean(axis=0)
    src_centered = src_points - src_centroid
    dst_centered = dst_points - dst_centroid
    h = src_centered.T @ dst_centered
    u, _, vt = np.linalg.svd(h)
    rot = vt.T @ u.T
    if np.linalg.det(rot) < 0:
        vt[-1, :] *= -1.0
        rot = vt.T @ u.T
    trans = dst_centroid - (rot @ src_centroid)
    transformed = (rot @ src_points.T).T + trans
    rmsd = float(np.sqrt(np.mean(np.sum((transformed - dst_points) ** 2, axis=1))))
    return rot, trans, rmsd


def transfer_ligand_by_local_alignment(
    reference_pdb: str,
    mutant_pdb: str,
    output_pdb: str,
    ligand_resnames: Sequence[str],
    chain_id: Optional[str],
    local_radius_ang: float = 12.0,
) -> Dict[str, float]:
    ensure_openmm()
    ref = app.PDBFile(reference_pdb)
    mut = app.PDBFile(mutant_pdb)
    lig_top, lig_positions, lig_indices = _extract_ligand_subset(
        ref.topology, ref.positions, ligand_resnames
    )
    if not lig_indices:
        raise ValueError(
            f"No ligand residues {ligand_resnames} found in reference PDB '{reference_pdb}'."
        )

    ref_pos_nm = np.asarray(ref.positions.value_in_unit(unit.nanometer), dtype=float)
    lig_pos_nm = ref_pos_nm[lig_indices]
    lig_centroid = lig_pos_nm.mean(axis=0)

    ref_records = _protein_ca_records(ref.topology, ref.positions, chain_id)
    mut_records = _protein_ca_records(mut.topology, mut.positions, chain_id)
    if len(ref_records) < 3 or len(mut_records) < 3:
        raise ValueError("Insufficient CA anchors for protein alignment.")

    ref_seq = "".join(aa for aa, _ in ref_records)
    mut_seq = "".join(aa for aa, _ in mut_records)
    pairs = _align_index_pairs(ref_seq, mut_seq)
    if len(pairs) < 3:
        raise ValueError("Insufficient aligned residue pairs for ligand transfer.")

    local_radius_nm = local_radius_ang * 0.1
    ref_points_all = np.asarray([ref_records[i][1] for i, _ in pairs], dtype=float)
    mut_points_all = np.asarray([mut_records[j][1] for _, j in pairs], dtype=float)
    distances = np.linalg.norm(ref_points_all - lig_centroid[None, :], axis=1)
    local_mask = distances <= local_radius_nm

    if int(np.sum(local_mask)) >= 6:
        ref_points = ref_points_all[local_mask]
        mut_points = mut_points_all[local_mask]
        local_pairs = int(np.sum(local_mask))
    else:
        ref_points = ref_points_all
        mut_points = mut_points_all
        local_pairs = len(pairs)

    rot, trans, rmsd_nm = _kabsch(ref_points, mut_points)
    transformed_lig = (rot @ lig_pos_nm.T).T + trans
    transformed_lig_qty = [Vec3(*xyz) * unit.nanometer for xyz in transformed_lig]

    modeller = app.Modeller(mut.topology, mut.positions)
    existing_lig_residues = []
    ligand_names = {name.upper() for name in ligand_resnames}
    for chain in modeller.topology.chains():
        for residue in chain.residues():
            if residue.name.upper() in ligand_names:
                existing_lig_residues.append(residue)
    if existing_lig_residues:
        modeller.delete(existing_lig_residues)

    modeller.add(lig_top, transformed_lig_qty)
    with open(output_pdb, "w", encoding="utf-8") as handle:
        app.PDBFile.writeFile(modeller.topology, modeller.positions, handle, keepIds=True)

    return {
        "alignment_pairs": float(len(pairs)),
        "local_alignment_pairs": float(local_pairs),
        "local_alignment_rmsd_ang": float(rmsd_nm * 10.0),
        "ligand_atoms": float(len(lig_indices)),
    }


def prepare_structures(config: BuildConfig, output_dir: str) -> PreparedStructures:
    ensure_openmm()
    try:
        from genmodels import buildm
    except Exception as exc:
        raise ImportError(
            "Could not import `buildm` from genmodels. Ensure MODELLER and project dependencies are installed."
        ) from exc

    os.makedirs(output_dir, exist_ok=True)
    structure_dir = os.path.join(output_dir, "structures")
    model_dir = os.path.join(output_dir, "model_build")
    os.makedirs(structure_dir, exist_ok=True)

    reference_pdb = os.path.abspath(config.reference_pdb)
    wt_out = os.path.join(structure_dir, "wt_with_ligand.pdb")
    mutant_raw_out = os.path.join(structure_dir, "mutant_raw.pdb")
    mutant_ligand_out = os.path.join(structure_dir, "mutant_with_ligand.pdb")

    if config.original_sequence:
        original_sequence = config.original_sequence.strip().upper()
    else:
        seq_from_pdb, inferred_start = sequence_and_start_from_pdb(reference_pdb, config.chain_id)
        original_sequence = seq_from_pdb
        if config.start_pos is None:
            config.start_pos = inferred_start

    if config.start_pos is None:
        _, inferred_start = sequence_and_start_from_pdb(reference_pdb, config.chain_id)
        config.start_pos = inferred_start

    start_pos = int(config.start_pos)
    try:
        mutated_sequence = mutate_sequence(original_sequence, config.mutations, start_pos)
    except MutationError as exc:
        raise ValueError(f"Mutation specification is invalid: {exc}") from exc

    with pushd(model_dir):
        best_rel = buildm(
            sequence=original_sequence,
            templates=config.templates,
            mutation=config.mutations,
            num_models=config.num_models,
            start_pos=start_pos,
            num_processors=config.num_processors,
            modeller_seed=config.modeller_seed,
            modeller_deterministic=config.modeller_seed is not None,
        )
        if not best_rel:
            raise RuntimeError("MODELLER did not return a best model path.")
        best_abs = os.path.abspath(best_rel)

    shutil.copy2(reference_pdb, wt_out)
    shutil.copy2(best_abs, mutant_raw_out)

    transfer_info = transfer_ligand_by_local_alignment(
        reference_pdb=reference_pdb,
        mutant_pdb=mutant_raw_out,
        output_pdb=mutant_ligand_out,
        ligand_resnames=config.ligand_resnames,
        chain_id=config.chain_id,
    )
    return PreparedStructures(
        wt_pdb=wt_out,
        mutant_raw_pdb=mutant_raw_out,
        mutant_ligand_pdb=mutant_ligand_out,
        original_sequence=original_sequence,
        mutated_sequence=mutated_sequence,
        start_pos=start_pos,
        alignment_pairs=int(transfer_info["alignment_pairs"]),
        local_alignment_pairs=int(transfer_info["local_alignment_pairs"]),
        local_alignment_rmsd_ang=float(transfer_info["local_alignment_rmsd_ang"]),
        ligand_atoms=int(transfer_info["ligand_atoms"]),
    )


def _resolve_nonbonded_method(name: str):
    key = (name or "PME").strip().upper()
    mapping = {
        "PME": app.PME,
        "EWALD": app.Ewald,
        "CUTOFFPERIODIC": app.CutoffPeriodic,
        "CUTOFFNONPERIODIC": app.CutoffNonPeriodic,
        "NOCUTOFF": app.NoCutoff,
    }
    if key not in mapping:
        raise ValueError(
            f"Unsupported nonbonded_method '{name}'. "
            "Use one of PME, Ewald, CutoffPeriodic, CutoffNonPeriodic, NoCutoff."
        )
    return mapping[key]


def _is_periodic_nonbonded_method(method) -> bool:
    return method in (app.PME, app.Ewald, app.CutoffPeriodic)


def _available_openmm_platform_names() -> List[str]:
    ensure_openmm()
    names: List[str] = []
    count = int(Platform.getNumPlatforms())
    for index in range(count):
        names.append(str(Platform.getPlatform(index).getName()))
    return names


def _select_openmm_platform(requested: str) -> Tuple["Platform", str, List[str]]:
    ensure_openmm()
    available = _available_openmm_platform_names()
    if not available:
        raise RuntimeError("No OpenMM platforms are available in this environment.")

    by_upper = {name.upper(): name for name in available}
    requested_clean = (requested or "AUTO").strip()
    requested_upper = requested_clean.upper()

    preference = ["CUDA", "OPENCL", "CPU", "REFERENCE"]

    selected_name: Optional[str] = None
    if requested_upper == "AUTO":
        for pref in preference:
            if pref in by_upper:
                selected_name = by_upper[pref]
                break
        if selected_name is None:
            selected_name = available[0]
    elif requested_upper in by_upper:
        selected_name = by_upper[requested_upper]
    else:
        for pref in preference:
            if pref in by_upper:
                selected_name = by_upper[pref]
                break
        if selected_name is None:
            selected_name = available[0]
        print(
            f"[OpenMM] Requested platform '{requested_clean}' not available. "
            f"Falling back to '{selected_name}'. Available: {', '.join(available)}"
        )

    platform = Platform.getPlatformByName(selected_name)
    return platform, selected_name, available


def run_openmm_md(
    input_pdb: str,
    ligand_xml: str,
    md_config: MDConfig,
    output_prefix: str,
) -> MDRunArtifacts:
    ensure_openmm()
    output_dir = os.path.dirname(output_prefix)
    if output_dir:
        os.makedirs(output_dir, exist_ok=True)

    forcefield = app.ForceField("amber14-all.xml", "amber14/tip3pfb.xml", ligand_xml)
    pdb = app.PDBFile(input_pdb)
    clean_top, clean_pos = _sanitize_topology_for_forcefield(pdb.topology, pdb.positions)
    modeller = app.Modeller(clean_top, clean_pos)
    modeller.addHydrogens(forcefield)

    nonbonded_method = _resolve_nonbonded_method(md_config.nonbonded_method)
    if md_config.add_solvent:
        modeller.addSolvent(
            forcefield,
            model=md_config.water_model,
            padding=md_config.solvent_padding_nm * unit.nanometer,
            neutralize=md_config.neutralize,
            ionicStrength=md_config.ionic_strength_m * unit.molar,
            positiveIon=md_config.positive_ion,
            negativeIon=md_config.negative_ion,
        )

    topology = modeller.topology
    create_kwargs = {
        "nonbondedMethod": nonbonded_method,
        "constraints": app.HBonds,
    }
    if nonbonded_method != app.NoCutoff:
        create_kwargs["nonbondedCutoff"] = md_config.nonbonded_cutoff_nm * unit.nanometer
    system = forcefield.createSystem(topology, **create_kwargs)

    barostat = None
    if _is_periodic_nonbonded_method(nonbonded_method) and md_config.pressure_bar > 0 and md_config.barostat_interval > 0:
        barostat = MonteCarloBarostat(
            md_config.pressure_bar * unit.bar,
            md_config.temperature_k * unit.kelvin,
            int(md_config.barostat_interval),
        )
        if md_config.random_seed is not None and hasattr(barostat, "setRandomNumberSeed"):
            barostat.setRandomNumberSeed(int(md_config.random_seed) + 7919)
        system.addForce(barostat)

    integrator = LangevinMiddleIntegrator(
        md_config.temperature_k * unit.kelvin,
        md_config.friction_per_ps / unit.picosecond,
        md_config.timestep_fs * unit.femtoseconds,
    )
    if md_config.random_seed is not None:
        integrator.setRandomNumberSeed(int(md_config.random_seed))

    requested_platform_name = str(md_config.platform or "AUTO")
    platform, selected_platform_name, available_platforms = _select_openmm_platform(requested_platform_name)
    if requested_platform_name.strip().upper() == "AUTO":
        print(
            f"[OpenMM] AUTO platform selected '{selected_platform_name}'. "
            f"Available: {', '.join(available_platforms)}"
        )
    simulation = app.Simulation(topology, system, integrator, platform)
    simulation.context.setPositions(modeller.positions)
    simulation.minimizeEnergy(maxIterations=md_config.minimization_max_iterations)

    start_temp = max(1.0, float(md_config.heating_initial_temperature_k))
    target_temp = float(md_config.temperature_k)
    if md_config.random_seed is not None:
        simulation.context.setVelocitiesToTemperature(start_temp * unit.kelvin, int(md_config.random_seed))
    else:
        simulation.context.setVelocitiesToTemperature(start_temp * unit.kelvin)

    if md_config.heating_steps > 0 and start_temp < target_temp:
        stages = max(1, int(md_config.heating_stages))
        steps_per_stage = int(md_config.heating_steps) // stages
        remainder = int(md_config.heating_steps) - (steps_per_stage * stages)
        for stage in range(stages):
            frac = float(stage + 1) / float(stages)
            stage_temp = start_temp + frac * (target_temp - start_temp)
            integrator.setTemperature(stage_temp * unit.kelvin)
            if barostat is not None:
                barostat.setDefaultTemperature(stage_temp * unit.kelvin)
            if steps_per_stage > 0:
                simulation.step(steps_per_stage)
        if remainder > 0:
            simulation.step(remainder)
    else:
        integrator.setTemperature(target_temp * unit.kelvin)
        if barostat is not None:
            barostat.setDefaultTemperature(target_temp * unit.kelvin)

    integrator.setTemperature(target_temp * unit.kelvin)
    if barostat is not None:
        barostat.setDefaultTemperature(target_temp * unit.kelvin)
    if md_config.equilibration_steps > 0:
        simulation.step(md_config.equilibration_steps)

    prepared_pdb = f"{output_prefix}_prepared.pdb"
    state_eq = simulation.context.getState(getPositions=True, getVelocities=True)
    with open(prepared_pdb, "w", encoding="utf-8") as handle:
        app.PDBFile.writeFile(topology, state_eq.getPositions(), handle, keepIds=True)

    dcd_path: Optional[str] = None
    if md_config.production_steps > 0 and md_config.report_interval > 0:
        dcd_interval = max(1, min(int(md_config.report_interval), int(md_config.production_steps)))
        dcd_path = f"{output_prefix}_traj.dcd"
        simulation.reporters.append(
            app.DCDReporter(
                dcd_path,
                dcd_interval,
                enforcePeriodicBox=_is_periodic_nonbonded_method(nonbonded_method),
            )
        )

    pos_frames: List[np.ndarray] = []
    vel_frames: List[np.ndarray] = []
    time_ps: List[float] = []

    def capture_frame(steps_done: int) -> None:
        state = simulation.context.getState(getPositions=True, getVelocities=True)
        pos_nm = np.asarray(
            state.getPositions(asNumpy=True).value_in_unit(unit.nanometer),
            dtype=np.float64,
        )
        vel_nm_ps = np.asarray(
            state.getVelocities(asNumpy=True).value_in_unit(unit.nanometer / unit.picosecond),
            dtype=np.float64,
        )
        pos_frames.append(pos_nm)
        vel_frames.append(vel_nm_ps)
        time_ps.append(steps_done * md_config.timestep_fs / 1000.0)

    steps_done = 0
    capture_frame(steps_done)
    while steps_done < md_config.production_steps:
        step = min(md_config.report_interval, md_config.production_steps - steps_done)
        simulation.step(step)
        steps_done += step
        capture_frame(steps_done)

    positions = np.stack(pos_frames, axis=0)
    velocities = np.stack(vel_frames, axis=0)
    time_ps_arr = np.asarray(time_ps, dtype=np.float64)
    dt_ps = md_config.report_interval * md_config.timestep_fs / 1000.0

    npz_path = f"{output_prefix}_traj.npz"
    np.savez_compressed(
        npz_path,
        positions=positions,
        velocities=velocities,
        time_ps=time_ps_arr,
        dt_ps=np.asarray([dt_ps], dtype=np.float64),
    )

    log_path = f"{output_prefix}_md.json"
    water_residues = 0
    ion_residues = 0
    for residue in topology.residues():
        resname = residue.name.upper()
        if resname in WATER_RESNAMES:
            water_residues += 1
            continue
        atoms = list(residue.atoms())
        if len(atoms) == 1 and not is_protein_residue(resname):
            ion_residues += 1

    state_box = simulation.context.getState()
    box_vectors = state_box.getPeriodicBoxVectors()
    box_nm = None
    if box_vectors is not None:
        try:
            box_nm_arr = np.asarray(box_vectors.value_in_unit(unit.nanometer), dtype=float)
        except Exception:
            box_nm_arr = np.asarray(
                [[float(vec.x), float(vec.y), float(vec.z)] for vec in box_vectors],
                dtype=float,
            )
        box_nm = box_nm_arr.tolist()

    log_payload = {
        "input_pdb": input_pdb,
        "prepared_pdb": prepared_pdb,
        "trajectory_dcd": dcd_path,
        "ligand_xml": ligand_xml,
        "temperature_k": md_config.temperature_k,
        "heating_initial_temperature_k": md_config.heating_initial_temperature_k,
        "heating_steps": md_config.heating_steps,
        "heating_stages": md_config.heating_stages,
        "timestep_fs": md_config.timestep_fs,
        "pressure_bar": md_config.pressure_bar,
        "barostat_interval": md_config.barostat_interval,
        "platform_requested": requested_platform_name,
        "platform_selected": selected_platform_name,
        "platforms_available": available_platforms,
        "nonbonded_method": md_config.nonbonded_method,
        "nonbonded_cutoff_nm": md_config.nonbonded_cutoff_nm,
        "add_solvent": md_config.add_solvent,
        "water_model": md_config.water_model,
        "solvent_padding_nm": md_config.solvent_padding_nm,
        "ionic_strength_m": md_config.ionic_strength_m,
        "neutralize": md_config.neutralize,
        "positive_ion": md_config.positive_ion,
        "negative_ion": md_config.negative_ion,
        "report_interval": md_config.report_interval,
        "production_steps": md_config.production_steps,
        "equilibration_steps": md_config.equilibration_steps,
        "frames": int(positions.shape[0]),
        "num_atoms": int(topology.getNumAtoms()),
        "num_residues": int(sum(1 for _ in topology.residues())),
        "water_residues": int(water_residues),
        "ion_like_residues": int(ion_residues),
        "box_vectors_nm": box_nm,
    }
    with open(log_path, "w", encoding="utf-8") as handle:
        json.dump(log_payload, handle, indent=2)

    return MDRunArtifacts(
        prepared_pdb=prepared_pdb,
        trajectory_npz=npz_path,
        trajectory_dcd=dcd_path,
        log_path=log_path,
        dt_ps=dt_ps,
        n_frames=int(positions.shape[0]),
    )


def load_traj_npz(path: str) -> Tuple[np.ndarray, np.ndarray, float]:
    data = np.load(path)
    positions = np.asarray(data["positions"], dtype=np.float64)
    velocities = np.asarray(data["velocities"], dtype=np.float64)
    if "dt_ps" in data:
        dt_ps = float(np.asarray(data["dt_ps"]).reshape(-1)[0])
    elif "time_ps" in data and len(data["time_ps"]) > 1:
        t = np.asarray(data["time_ps"], dtype=np.float64)
        dt_ps = float(np.median(np.diff(t)))
    else:
        dt_ps = 1.0
    return positions, velocities, dt_ps


def _build_grid_points(rp_nm: float, spacing_nm: float, max_points: int) -> np.ndarray:
    axis = np.arange(-rp_nm, rp_nm + 1e-12, spacing_nm, dtype=np.float64)
    xx, yy, zz = np.meshgrid(axis, axis, axis, indexing="ij")
    points = np.stack([xx.ravel(), yy.ravel(), zz.ravel()], axis=1)
    mask = np.linalg.norm(points, axis=1) <= rp_nm + 1e-12
    points = points[mask]
    if len(points) > max_points:
        keep = np.linspace(0, len(points) - 1, max_points, dtype=int)
        points = points[keep]
    return points


def _finite_difference(values: np.ndarray, dt: float) -> np.ndarray:
    out = np.zeros_like(values)
    if len(values) == 1:
        return out
    out[0] = (values[1] - values[0]) / dt
    out[-1] = (values[-1] - values[-2]) / dt
    if len(values) > 2:
        out[1:-1] = (values[2:] - values[:-2]) / (2.0 * dt)
    return out


def _rotation_to_omega(rotations: np.ndarray, dt_ps: float) -> np.ndarray:
    r_dot = _finite_difference(rotations, dt_ps)
    omega = np.zeros((rotations.shape[0], 3), dtype=np.float64)
    for t in range(rotations.shape[0]):
        omega_hat = r_dot[t] @ rotations[t].T
        omega[t, 0] = 0.5 * (omega_hat[2, 1] - omega_hat[1, 2])
        omega[t, 1] = 0.5 * (omega_hat[0, 2] - omega_hat[2, 0])
        omega[t, 2] = 0.5 * (omega_hat[1, 0] - omega_hat[0, 1])
    return omega


def _compute_anchor_frame_series(
    positions: np.ndarray,
    anchor_indices: np.ndarray,
    reference_anchor_coords: Optional[np.ndarray] = None,
) -> Tuple[np.ndarray, np.ndarray]:
    num_frames = positions.shape[0]
    centers = np.zeros((num_frames, 3), dtype=np.float64)
    rotations = np.zeros((num_frames, 3, 3), dtype=np.float64)
    prev_rot = np.eye(3, dtype=np.float64)

    if reference_anchor_coords is None:
        reference_anchor_coords = positions[0, anchor_indices, :].copy()
    ref_center = reference_anchor_coords.mean(axis=0)
    ref_centered = reference_anchor_coords - ref_center

    for t in range(num_frames):
        anchors = positions[t, anchor_indices, :]
        center = anchors.mean(axis=0)
        centers[t] = center
        cur_centered = anchors - center
        if np.linalg.matrix_rank(cur_centered) < 2:
            rotations[t] = prev_rot
            continue

        h = cur_centered.T @ ref_centered
        u, _, vt = np.linalg.svd(h)
        q = vt.T @ u.T  # current -> reference
        if np.linalg.det(q) < 0:
            vt[-1, :] *= -1.0
            q = vt.T @ u.T
        r_world = q.T
        if np.linalg.norm(r_world - prev_rot, ord="fro") > 2.5:
            # Guard against abrupt frame flips in near-symmetric anchors.
            r_world = prev_rot
        rotations[t] = r_world
        prev_rot = r_world

    return centers, rotations


def _lagged_kernel_fields(
    coords: np.ndarray,
    vels: np.ndarray,
    type_ids: np.ndarray,
    atom_indices: np.ndarray,
    grid: np.ndarray,
    sigma_nm: float,
    include_velocity: bool,
    density_normalize: bool,
    append_type_counts: bool,
) -> np.ndarray:
    n_grid = grid.shape[0]
    n_types = len(TYPE_BINS)
    phi = np.zeros((n_grid, n_types), dtype=np.float64)
    if include_velocity:
        psi = np.zeros((n_grid, n_types, 3), dtype=np.float64)
    else:
        psi = None
    type_counts = np.zeros(n_types, dtype=np.float64)

    if atom_indices.size == 0:
        parts: List[np.ndarray] = [phi.ravel()]
        if include_velocity and psi is not None:
            parts.append(psi.ravel())
        if append_type_counts:
            parts.append(type_counts)
        return np.concatenate(parts)

    sel_coords = coords[atom_indices]
    sel_vels = vels[atom_indices]
    sel_types = type_ids[atom_indices]
    type_counts = np.bincount(sel_types, minlength=n_types).astype(np.float64)
    diff = sel_coords[:, None, :] - grid[None, :, :]
    dist2 = np.sum(diff * diff, axis=2)
    cutoff2 = (3.0 * sigma_nm) ** 2
    weights = np.exp(-dist2 / (2.0 * sigma_nm * sigma_nm))
    weights[dist2 > cutoff2] = 0.0

    for a in range(n_types):
        mask = sel_types == a
        if not np.any(mask):
            continue
        w = weights[mask]
        phi[:, a] = np.sum(w, axis=0)
        if include_velocity and psi is not None:
            vel_a = sel_vels[mask]
            for axis in range(3):
                psi[:, a, axis] = w.T @ vel_a[:, axis]

    if density_normalize:
        denom = max(1.0, float(atom_indices.size))
        phi /= denom
        if include_velocity and psi is not None:
            psi /= denom
        count_features = type_counts / denom
    else:
        count_features = np.log1p(type_counts)

    parts = [phi.ravel()]
    if include_velocity and psi is not None:
        parts.append(psi.ravel())
    if append_type_counts:
        parts.append(count_features)
    return np.concatenate(parts)


def _classify_atoms(
    topology: "app.Topology",
    ligand_resnames: Sequence[str],
) -> Dict[str, np.ndarray]:
    ligand_names = {name.upper() for name in ligand_resnames}
    n_atoms = topology.getNumAtoms()
    is_ligand = np.zeros(n_atoms, dtype=bool)
    is_protein = np.zeros(n_atoms, dtype=bool)
    is_cofactor = np.zeros(n_atoms, dtype=bool)
    is_water = np.zeros(n_atoms, dtype=bool)
    type_ids = np.zeros(n_atoms, dtype=np.int32)
    masses = np.ones(n_atoms, dtype=np.float64)

    for atom in topology.atoms():
        idx = atom.index
        resname = atom.residue.name.upper()
        if resname in ligand_names:
            is_ligand[idx] = True
        elif resname in WATER_RESNAMES:
            is_water[idx] = True
        elif is_protein_residue(resname):
            is_protein[idx] = True
        else:
            is_cofactor[idx] = True

        symbol = atom.element.symbol if atom.element else None
        type_ids[idx] = atom_type_bin(symbol)
        if atom.element is not None:
            masses[idx] = atom.element.mass.value_in_unit(unit.dalton)

    return {
        "is_ligand": is_ligand,
        "is_protein": is_protein,
        "is_cofactor": is_cofactor,
        "is_water": is_water,
        "type_ids": type_ids,
        "masses": masses,
    }


def _sanitize_topology_for_forcefield(
    topology: "app.Topology",
    positions: "unit.Quantity",
) -> Tuple["app.Topology", "unit.Quantity"]:
    """
    Rebuild topology while removing cross-bonds between protein and non-protein
    residues, which frequently break template matching for metalloproteins.
    """
    ensure_openmm()
    pos_nm = np.asarray(positions.value_in_unit(unit.nanometer), dtype=np.float64)
    new_top = app.Topology()
    atom_map = {}
    new_positions = []

    for chain in topology.chains():
        new_chain = new_top.addChain(chain.id)
        for residue in chain.residues():
            new_res = new_top.addResidue(
                residue.name,
                new_chain,
                id=residue.id,
                insertionCode=residue.insertionCode,
            )
            for atom in residue.atoms():
                new_atom = new_top.addAtom(
                    atom.name,
                    atom.element,
                    new_res,
                    id=atom.id,
                    formalCharge=atom.formalCharge,
                )
                atom_map[atom] = new_atom
                xyz = pos_nm[atom.index]
                new_positions.append(Vec3(float(xyz[0]), float(xyz[1]), float(xyz[2])))

    def _is_protein_res(resname: str) -> bool:
        return is_protein_residue(resname)

    # Rebuild canonical protein bonding from residue templates to avoid
    # nonstandard topology artifacts from modeled PDB files.
    new_top.createStandardBonds()

    # Preserve ligand/cofactor intra-residue bonds from the source topology.
    for atom1, atom2 in topology.bonds():
        res1 = atom1.residue
        res2 = atom2.residue
        same_residue = res1 is res2
        p1 = _is_protein_res(res1.name.upper())
        p2 = _is_protein_res(res2.name.upper())
        if not same_residue:
            continue
        if p1 and p2:
            continue
        try:
            new_top.addBond(atom_map[atom1], atom_map[atom2], type=None, order=None)
        except TypeError:
            new_top.addBond(atom_map[atom1], atom_map[atom2])

    pos_qty = new_positions * unit.nanometer
    try:
        new_top.createDisulfideBonds(pos_qty)
    except Exception:
        pass
    return new_top, pos_qty


def _select_anchor_indices(
    topology: "app.Topology",
    ligand_resnames: Sequence[str],
) -> np.ndarray:
    ligand_names = {name.upper() for name in ligand_resnames}
    heavy: List[int] = []
    all_ligand: List[int] = []
    ca_fallback: List[int] = []

    for atom in topology.atoms():
        if atom.name == "CA":
            ca_fallback.append(atom.index)
        if atom.residue.name.upper() in ligand_names:
            all_ligand.append(atom.index)
            if atom.element is None or atom.element.symbol.upper() != "H":
                heavy.append(atom.index)

    if len(heavy) >= 3:
        return np.asarray(heavy, dtype=np.int32)
    if len(all_ligand) >= 3:
        return np.asarray(all_ligand, dtype=np.int32)
    if len(ca_fallback) >= 3:
        return np.asarray(ca_fallback[:20], dtype=np.int32)
    raise ValueError("Could not select at least 3 anchor atoms for pocket frame.")


def compute_region_features(
    topology: "app.Topology",
    positions: np.ndarray,
    velocities: np.ndarray,
    dt_ps: float,
    ligand_resnames: Sequence[str],
    field_cfg: FieldConfig,
) -> Dict[str, np.ndarray]:
    atom_info = _classify_atoms(topology, ligand_resnames)
    masses = atom_info["masses"]
    total_mass = float(np.sum(masses))
    pos = positions.copy()
    vel = velocities.copy()

    if field_cfg.remove_com and total_mass > 0:
        com = np.sum(pos * masses[None, :, None], axis=1) / total_mass
        com_v = np.sum(vel * masses[None, :, None], axis=1) / total_mass
        pos -= com[:, None, :]
        vel -= com_v[:, None, :]

    anchor_indices = _select_anchor_indices(topology, ligand_resnames)
    centers, rotations = _compute_anchor_frame_series(pos, anchor_indices)
    c_dot = _finite_difference(centers, dt_ps)
    omega = _rotation_to_omega(rotations, dt_ps)

    rb_nm = field_cfg.rb_ang * 0.1
    rp_nm = field_cfg.rp_ang * 0.1
    sigma_nm = field_cfg.sigma_ang * 0.1
    grid = _build_grid_points(
        rp_nm=rp_nm,
        spacing_nm=field_cfg.grid_spacing_ang * 0.1,
        max_points=field_cfg.max_grid_points,
    )

    protein_or_cofactor = atom_info["is_protein"] | atom_info["is_cofactor"]
    protein_only = atom_info["is_protein"]
    ligand_only = atom_info["is_ligand"]
    type_ids = atom_info["type_ids"]
    n_frames = pos.shape[0]

    feat_b: List[np.ndarray] = []
    feat_p: List[np.ndarray] = []
    feat_l: List[np.ndarray] = []

    for t in range(n_frames):
        r_rel = pos[t] - centers[t][None, :]
        r_prime = (rotations[t].T @ r_rel.T).T
        v_rel = vel[t] - c_dot[t][None, :]
        v_prime = (rotations[t].T @ v_rel.T).T - np.cross(omega[t][None, :], r_prime)
        radial = np.linalg.norm(r_prime, axis=1)

        idx_b = np.where(
            protein_or_cofactor & (~ligand_only) & (radial <= rb_nm)
        )[0].astype(np.int32)
        idx_p = np.where(
            protein_only & (radial > rb_nm) & (radial <= rp_nm)
        )[0].astype(np.int32)
        idx_l = np.where(ligand_only)[0].astype(np.int32)

        feat_b.append(
            _lagged_kernel_fields(
                coords=r_prime,
                vels=v_prime,
                type_ids=type_ids,
                atom_indices=idx_b,
                grid=grid,
                sigma_nm=sigma_nm,
                include_velocity=field_cfg.include_velocity,
                density_normalize=field_cfg.density_normalize,
                append_type_counts=field_cfg.append_type_counts,
            )
        )
        feat_p.append(
            _lagged_kernel_fields(
                coords=r_prime,
                vels=v_prime,
                type_ids=type_ids,
                atom_indices=idx_p,
                grid=grid,
                sigma_nm=sigma_nm,
                include_velocity=field_cfg.include_velocity,
                density_normalize=field_cfg.density_normalize,
                append_type_counts=field_cfg.append_type_counts,
            )
        )
        feat_l.append(
            _lagged_kernel_fields(
                coords=r_prime,
                vels=v_prime,
                type_ids=type_ids,
                atom_indices=idx_l,
                grid=grid,
                sigma_nm=sigma_nm,
                include_velocity=field_cfg.include_velocity,
                density_normalize=field_cfg.density_normalize,
                append_type_counts=field_cfg.append_type_counts,
            )
        )

    return {
        "B": np.asarray(feat_b, dtype=np.float64),
        "P": np.asarray(feat_p, dtype=np.float64),
        "L": np.asarray(feat_l, dtype=np.float64),
        "grid": grid,
    }


def _symmetric_invsqrt(matrix: np.ndarray, eps: float) -> np.ndarray:
    vals, vecs = np.linalg.eigh(matrix)
    vals = np.clip(vals, eps, None)
    invsqrt = vecs @ np.diag(1.0 / np.sqrt(vals)) @ vecs.T
    return invsqrt


class LinearVAMP:
    def __init__(self, lag: int, n_components: int, reg: float = 1e-6):
        self.lag = int(lag)
        self.n_components = int(n_components)
        self.reg = float(reg)
        self.mean_: Optional[np.ndarray] = None
        self.proj_: Optional[np.ndarray] = None
        self.svals_: Optional[np.ndarray] = None

    def fit_from_trajectories(self, trajectories: Sequence[np.ndarray]) -> "LinearVAMP":
        x0_list: List[np.ndarray] = []
        x1_list: List[np.ndarray] = []
        for x in trajectories:
            if x.shape[0] <= self.lag:
                continue
            x0_list.append(x[:-self.lag])
            x1_list.append(x[self.lag :])
        if not x0_list:
            raise ValueError("Not enough trajectory frames for requested VAMP lag.")
        x0 = np.vstack(x0_list)
        x1 = np.vstack(x1_list)
        return self.fit_pairs(x0, x1)

    def fit_pairs(self, x0: np.ndarray, x1: np.ndarray) -> "LinearVAMP":
        if x0.shape != x1.shape:
            raise ValueError("x0/x1 must have equal shape.")
        n_samples, n_feat = x0.shape
        if n_samples < 3:
            raise ValueError("At least 3 lagged pairs are required for VAMP.")

        self.mean_ = x0.mean(axis=0)
        xc0 = x0 - self.mean_[None, :]
        xc1 = x1 - self.mean_[None, :]

        c00 = (xc0.T @ xc0) / max(1, n_samples - 1) + self.reg * np.eye(n_feat)
        c11 = (xc1.T @ xc1) / max(1, n_samples - 1) + self.reg * np.eye(n_feat)
        c01 = (xc0.T @ xc1) / max(1, n_samples - 1)

        w0 = _symmetric_invsqrt(c00, self.reg)
        w1 = _symmetric_invsqrt(c11, self.reg)
        k = w0 @ c01 @ w1
        u, s, _ = np.linalg.svd(k, full_matrices=False)

        n_keep = int(min(self.n_components, u.shape[1]))
        self.proj_ = w0 @ u[:, :n_keep]
        self.svals_ = s[:n_keep]
        return self

    def transform(self, x: np.ndarray) -> np.ndarray:
        if self.mean_ is None or self.proj_ is None:
            raise RuntimeError("LinearVAMP must be fit before transform.")
        return (x - self.mean_[None, :]) @ self.proj_


def fit_bic_gmm(data: np.ndarray, max_components: int, random_seed: int = 13) -> GaussianMixture:
    ensure_sklearn()
    max_components = max(1, min(max_components, data.shape[0] - 1))
    best_model = None
    best_bic = float("inf")
    for k in range(1, max_components + 1):
        model = GaussianMixture(
            n_components=k,
            covariance_type="full",
            reg_covar=1e-6,
            random_state=random_seed,
        )
        model.fit(data)
        bic = model.bic(data)
        if bic < best_bic:
            best_bic = bic
            best_model = model
    if best_model is None:
        raise RuntimeError("Could not fit GaussianMixture model.")
    return best_model


def _iat_from_series(x: np.ndarray, max_lag: Optional[int] = None) -> float:
    x = np.asarray(x, dtype=np.float64)
    x = x - np.mean(x)
    var = np.var(x)
    if var <= 1e-12:
        return 1.0
    n = x.shape[0]
    if max_lag is None:
        max_lag = min(n // 2, 2000)
    tau = 1.0
    for lag in range(1, max_lag + 1):
        c = np.dot(x[:-lag], x[lag:]) / (n - lag)
        rho = c / var
        if rho <= 0:
            break
        tau += 2.0 * rho
    return max(1.0, tau)


def _bootstrap_labels(labels: np.ndarray, block_len: int, rng: np.random.Generator) -> np.ndarray:
    n = labels.shape[0]
    if block_len <= 1:
        return labels[rng.integers(0, n, size=n)]
    out = np.empty(n, dtype=labels.dtype)
    write = 0
    while write < n:
        start = int(rng.integers(0, max(1, n - block_len + 1)))
        end = min(start + block_len, n)
        span = end - start
        span = min(span, n - write)
        out[write : write + span] = labels[start : start + span]
        write += span
    return out


def compute_basin_ddg(
    u_wt: np.ndarray,
    u_mut: np.ndarray,
    temperature_k: float,
    n_bootstrap: int = 400,
    random_seed: int = 13,
) -> Dict[str, object]:
    gmm = fit_bic_gmm(np.vstack([u_wt, u_mut]), max_components=8, random_seed=random_seed)
    labels_wt = gmm.predict(u_wt)
    labels_mut = gmm.predict(u_mut)
    n_basins = int(gmm.n_components)
    kbt = 0.0019872041 * temperature_k
    eps = 1e-10

    counts_wt = np.bincount(labels_wt, minlength=n_basins).astype(float)
    counts_mut = np.bincount(labels_mut, minlength=n_basins).astype(float)
    p_wt = (counts_wt + eps) / (len(labels_wt) + eps * n_basins)
    p_mut = (counts_mut + eps) / (len(labels_mut) + eps * n_basins)
    ddg = -kbt * np.log(p_mut / p_wt)

    taus = []
    for basin in range(n_basins):
        taus.append(_iat_from_series((labels_wt == basin).astype(float)))
        taus.append(_iat_from_series((labels_mut == basin).astype(float)))
    tau = float(max(taus) if taus else 1.0)
    block_len = max(1, int(math.ceil(5.0 * tau)))
    n_eff_wt = float(len(labels_wt) / tau)
    n_eff_mut = float(len(labels_mut) / tau)

    rng = np.random.default_rng(random_seed)
    ddg_boot = np.zeros((n_bootstrap, n_basins), dtype=np.float64)
    for b in range(n_bootstrap):
        boot_wt = _bootstrap_labels(labels_wt, block_len, rng)
        boot_mut = _bootstrap_labels(labels_mut, block_len, rng)
        c_wt = np.bincount(boot_wt, minlength=n_basins).astype(float)
        c_mut = np.bincount(boot_mut, minlength=n_basins).astype(float)
        p_wt_b = (c_wt + eps) / (len(boot_wt) + eps * n_basins)
        p_mut_b = (c_mut + eps) / (len(boot_mut) + eps * n_basins)
        ddg_boot[b] = -kbt * np.log(p_mut_b / p_wt_b)

    ci_low = np.percentile(ddg_boot, 2.5, axis=0)
    ci_high = np.percentile(ddg_boot, 97.5, axis=0)

    basin_rows = []
    for basin in range(n_basins):
        basin_rows.append(
            {
                "basin": basin,
                "p_wt": float(p_wt[basin]),
                "p_mut": float(p_mut[basin]),
                "ddg_kcal_mol": float(ddg[basin]),
                "ddg_ci95_low": float(ci_low[basin]),
                "ddg_ci95_high": float(ci_high[basin]),
            }
        )

    return {
        "n_basins": n_basins,
        "effective_samples_wt": n_eff_wt,
        "effective_samples_mut": n_eff_mut,
        "iat": tau,
        "block_len": block_len,
        "basins": basin_rows,
    }


def gaussianity_diagnostics(data: np.ndarray, random_seed: int = 13) -> Dict[str, object]:
    ensure_sklearn()
    gmm1 = fit_bic_gmm(data, max_components=1, random_seed=random_seed)
    gmm2 = fit_bic_gmm(data, max_components=2, random_seed=random_seed)
    bic1 = float(gmm1.bic(data))
    bic2 = float(gmm2.bic(data))
    unimodal_pref = bic1 <= bic2 + 2.0

    min_p = None
    if scipy_stats is not None and data.shape[0] >= 20:
        pvals = []
        for d in range(data.shape[1]):
            try:
                stat, p = scipy_stats.normaltest(data[:, d])
                pvals.append(float(p))
            except Exception:
                continue
        if pvals:
            min_p = float(min(pvals))
    passed = unimodal_pref and (min_p is None or min_p > 1e-2)
    return {
        "bic_1_component": bic1,
        "bic_2_component": bic2,
        "unimodal_preferred": unimodal_pref,
        "normality_min_pvalue": min_p,
        "passed_for_gaussian_kl": passed,
    }


def gaussian_kl_divergence(
    mean0: np.ndarray,
    cov0: np.ndarray,
    mean1: np.ndarray,
    cov1: np.ndarray,
    reg: float = 1e-8,
) -> float:
    dim = mean0.shape[0]
    cov0r = cov0 + reg * np.eye(dim)
    cov1r = cov1 + reg * np.eye(dim)
    inv1 = np.linalg.inv(cov1r)
    diff = (mean1 - mean0)[:, None]
    sign0, logdet0 = np.linalg.slogdet(cov0r)
    sign1, logdet1 = np.linalg.slogdet(cov1r)
    if sign0 <= 0 or sign1 <= 0:
        raise ValueError("Covariance determinant is non-positive.")
    term = (
        np.trace(inv1 @ cov0r)
        + float((diff.T @ inv1 @ diff).reshape(()))
        - dim
        + (logdet1 - logdet0)
    )
    return 0.5 * float(term)


def gmm_kl_monte_carlo(
    data0: np.ndarray,
    data1: np.ndarray,
    samples: int = 10000,
    random_seed: int = 13,
) -> float:
    ensure_sklearn()
    g0 = fit_bic_gmm(data0, max_components=6, random_seed=random_seed)
    g1 = fit_bic_gmm(data1, max_components=6, random_seed=random_seed)
    x, _ = g0.sample(samples)
    log_p0 = g0.score_samples(x)
    log_p1 = g1.score_samples(x)
    return float(np.mean(log_p0 - log_p1))


def js_divergence_density_ratio(
    data0: np.ndarray,
    data1: np.ndarray,
    random_seed: int = 13,
) -> float:
    ensure_sklearn()
    x = np.vstack([data0, data1])
    y = np.concatenate([np.zeros(data0.shape[0]), np.ones(data1.shape[0])], axis=0)
    clf = LogisticRegression(max_iter=2000, random_state=random_seed)
    clf.fit(x, y)
    probs = np.clip(clf.predict_proba(x)[:, 1], 1e-6, 1.0 - 1e-6)
    ratio = probs / (1.0 - probs)
    r0 = ratio[: data0.shape[0]]
    r1 = ratio[data0.shape[0] :]

    js = 0.5 * (
        np.mean(np.log(2.0 / (1.0 + r0))) + np.mean(np.log(2.0 * r1 / (1.0 + r1)))
    )
    return float(np.clip(js, 0.0, np.log(2.0)))


def distribution_shift(u_wt: np.ndarray, u_mut: np.ndarray) -> Dict[str, object]:
    diag_wt = gaussianity_diagnostics(u_wt)
    diag_mut = gaussianity_diagnostics(u_mut)
    gaussian_ok = bool(diag_wt["passed_for_gaussian_kl"] and diag_mut["passed_for_gaussian_kl"])

    if gaussian_ok:
        mean0 = np.mean(u_wt, axis=0)
        mean1 = np.mean(u_mut, axis=0)
        cov0 = np.cov(u_wt, rowvar=False)
        cov1 = np.cov(u_mut, rowvar=False)
        dkl = gaussian_kl_divergence(mean0, cov0, mean1, cov1)
        return {
            "method": "gaussian_kl",
            "gaussian_diagnostics_wt": diag_wt,
            "gaussian_diagnostics_mut": diag_mut,
            "kl_wt_to_mut": float(dkl),
        }

    dkl_gmm = gmm_kl_monte_carlo(u_wt, u_mut)
    js = js_divergence_density_ratio(u_wt, u_mut)
    return {
        "method": "fallback_gmm_kl_js",
        "gaussian_diagnostics_wt": diag_wt,
        "gaussian_diagnostics_mut": diag_mut,
        "gmm_kl_wt_to_mut": float(dkl_gmm),
        "js_divergence": float(js),
    }


def _lag_matrix(series: np.ndarray, p: int) -> np.ndarray:
    t, d = series.shape
    rows = t - p
    blocks = []
    for lag in range(1, p + 1):
        blocks.append(series[p - lag : t - lag, :])
    return np.hstack(blocks).reshape(rows, p * d)


def _fit_ridge_multivariate(x: np.ndarray, y: np.ndarray, ridge: float) -> Tuple[np.ndarray, np.ndarray]:
    xtx = x.T @ x
    n_feat = xtx.shape[0]
    beta = np.linalg.solve(xtx + ridge * np.eye(n_feat), x.T @ y)
    resid = y - x @ beta
    return beta, resid


def _residual_cov(resid: np.ndarray) -> np.ndarray:
    cov = np.cov(resid, rowvar=False, bias=False)
    if cov.ndim == 0:
        cov = np.asarray([[float(cov)]], dtype=np.float64)
    cov = cov + 1e-10 * np.eye(cov.shape[0])
    return cov


def _bic_from_residual_cov(resid: np.ndarray, n_params: int) -> float:
    n = resid.shape[0]
    m = resid.shape[1]
    cov = _residual_cov(resid)
    sign, logdet = np.linalg.slogdet(cov)
    if sign <= 0:
        logdet = 1e6
    ll = -0.5 * n * (m * np.log(2.0 * np.pi) + logdet + m)
    bic = -2.0 * ll + n_params * np.log(max(2, n))
    return float(bic)


def _max_abs_resid_autocorr(resid: np.ndarray, lag_max: int) -> float:
    resid = resid - np.mean(resid, axis=0, keepdims=True)
    worst = 0.0
    for d in range(resid.shape[1]):
        x = resid[:, d]
        var = np.var(x)
        if var <= 1e-12:
            continue
        for lag in range(1, min(lag_max, len(x) - 1) + 1):
            c = np.dot(x[:-lag], x[lag:]) / (len(x) - lag)
            worst = max(worst, abs(float(c / var)))
    return worst


def _y_stability(beta_full: np.ndarray, y_dim: int, p: int) -> float:
    if p < 1:
        return 0.0
    companion = np.zeros((y_dim * p, y_dim * p), dtype=np.float64)
    for lag in range(p):
        sl = slice(lag * y_dim, (lag + 1) * y_dim)
        companion[0:y_dim, sl] = beta_full[sl, :].T
    if p > 1:
        companion[y_dim:, :-y_dim] = np.eye(y_dim * (p - 1))
    eigvals = np.linalg.eigvals(companion)
    return float(np.max(np.abs(eigvals)))


def _blocked_cv_mse(x: np.ndarray, y: np.ndarray, ridge: float, folds: int = 3) -> float:
    n = x.shape[0]
    if n < folds + 5:
        _, resid = _fit_ridge_multivariate(x, y, ridge)
        return float(np.mean(resid * resid))
    splits = np.linspace(0, n, folds + 1, dtype=int)
    mse_vals = []
    for i in range(folds):
        a = splits[i]
        b = splits[i + 1]
        if b - a < 2:
            continue
        mask = np.ones(n, dtype=bool)
        mask[a:b] = False
        x_train = x[mask]
        y_train = y[mask]
        x_valid = x[a:b]
        y_valid = y[a:b]
        beta, _ = _fit_ridge_multivariate(x_train, y_train, ridge)
        resid = y_valid - x_valid @ beta
        mse_vals.append(float(np.mean(resid * resid)))
    if not mse_vals:
        _, resid = _fit_ridge_multivariate(x, y, ridge)
        return float(np.mean(resid * resid))
    return float(np.mean(mse_vals))


def _phase_randomize(ts: np.ndarray, rng: np.random.Generator) -> np.ndarray:
    n, d = ts.shape
    out = np.zeros_like(ts)
    for dim in range(d):
        x = ts[:, dim]
        x0 = x - np.mean(x)
        fx = np.fft.rfft(x0)
        if fx.shape[0] > 2:
            random_phase = rng.uniform(0.0, 2.0 * np.pi, size=fx.shape[0] - 2)
            fx[1:-1] *= np.exp(1j * random_phase)
        xr = np.fft.irfft(fx, n=n)
        out[:, dim] = xr + np.mean(x)
    return out


def _te_with_fixed_model(
    y: np.ndarray,
    x: np.ndarray,
    w: Optional[np.ndarray],
    p: int,
    ridge: float,
) -> float:
    y_target = y[p:, :]
    x_parts = [_lag_matrix(y, p)]
    if w is not None and w.shape[1] > 0:
        x_parts.append(_lag_matrix(w, p))
    xr = np.hstack(x_parts)
    xf = np.hstack([xr, _lag_matrix(x, p)])

    _, resid_r = _fit_ridge_multivariate(xr, y_target, ridge)
    _, resid_f = _fit_ridge_multivariate(xf, y_target, ridge)
    cov_r = _residual_cov(resid_r)
    cov_f = _residual_cov(resid_f)
    _, logdet_r = np.linalg.slogdet(cov_r)
    _, logdet_f = np.linalg.slogdet(cov_f)
    return float(0.5 * (logdet_r - logdet_f))


def conditional_te_linear_gaussian(
    y: np.ndarray,
    x: np.ndarray,
    w: Optional[np.ndarray],
    cfg: TEConfig,
) -> Dict[str, object]:
    n = min(len(y), len(x), len(w) if w is not None else len(y))
    y = y[-n:]
    x = x[-n:]
    if w is not None:
        w = w[-n:]

    candidates = []
    for p in range(1, cfg.max_order + 1):
        if n <= p + 5:
            continue
        y_target = y[p:, :]
        parts = [_lag_matrix(y, p)]
        if w is not None and w.shape[1] > 0:
            parts.append(_lag_matrix(w, p))
        xr = np.hstack(parts)
        xf = np.hstack([xr, _lag_matrix(x, p)])

        best_ridge = None
        best_cv = float("inf")
        for ridge in cfg.ridge_values:
            cv = _blocked_cv_mse(xf, y_target, ridge=ridge, folds=3)
            if cv < best_cv:
                best_cv = cv
                best_ridge = ridge
        ridge = float(best_ridge if best_ridge is not None else cfg.ridge_values[0])

        beta_r, resid_r = _fit_ridge_multivariate(xr, y_target, ridge)
        beta_f, resid_f = _fit_ridge_multivariate(xf, y_target, ridge)
        cov_r = _residual_cov(resid_r)
        cov_f = _residual_cov(resid_f)
        _, logdet_r = np.linalg.slogdet(cov_r)
        _, logdet_f = np.linalg.slogdet(cov_f)
        te = 0.5 * (logdet_r - logdet_f)

        n_params = beta_f.size
        bic = _bic_from_residual_cov(resid_f, n_params=n_params)
        whiten = _max_abs_resid_autocorr(resid_f, lag_max=cfg.whiteness_lag)
        spectral_radius = _y_stability(beta_f, y_dim=y.shape[1], p=p)
        accepted = (whiten <= cfg.whiteness_threshold) and (spectral_radius < 1.0)
        candidates.append(
            {
                "p": p,
                "ridge": ridge,
                "te": float(te),
                "bic": float(bic),
                "whiteness_max_abs_acf": float(whiten),
                "spectral_radius": float(spectral_radius),
                "accepted": bool(accepted),
            }
        )

    if not candidates:
        raise ValueError("Insufficient data for VAR/TE estimation.")

    accepted = [c for c in candidates if c["accepted"]]
    chosen_pool = accepted if accepted else candidates
    chosen = min(chosen_pool, key=lambda c: c["bic"])

    p_sel = int(chosen["p"])
    ridge_sel = float(chosen["ridge"])
    te_obs = _te_with_fixed_model(y, x, w, p=p_sel, ridge=ridge_sel)
    reverse_obs = _te_with_fixed_model(x, y, w, p=p_sel, ridge=ridge_sel)

    rng = np.random.default_rng(cfg.random_seed)
    surrogate_vals = []
    for _ in range(cfg.surrogates):
        x_surr = _phase_randomize(x, rng)
        te_s = _te_with_fixed_model(y, x_surr, w, p=p_sel, ridge=ridge_sel)
        surrogate_vals.append(float(te_s))
    surrogate_vals_arr = np.asarray(surrogate_vals, dtype=np.float64)
    p_value = float((1 + np.sum(surrogate_vals_arr >= te_obs)) / (cfg.surrogates + 1))

    return {
        "selected_order": p_sel,
        "selected_ridge": ridge_sel,
        "te_driver_to_target": float(te_obs),
        "te_target_to_driver": float(reverse_obs),
        "directionality_delta": float(te_obs - reverse_obs),
        "surrogate_pvalue": p_value,
        "surrogate_te_mean": float(np.mean(surrogate_vals_arr)),
        "surrogate_te_std": float(np.std(surrogate_vals_arr)),
        "model_candidates": candidates,
    }


def susceptibility_gamma(
    u_b: np.ndarray,
    u_p: np.ndarray,
    n_bootstrap: int = 300,
    random_seed: int = 13,
) -> Dict[str, object]:
    n = min(len(u_b), len(u_p))
    ub = u_b[-n:]
    up = u_p[-n:]
    cov_b = np.cov(ub, rowvar=False)
    cov_p = np.cov(up, rowvar=False) + 1e-8 * np.eye(up.shape[1])
    cov_bp = np.cov(np.hstack([ub, up]).T)[: ub.shape[1], ub.shape[1] :]
    gamma = cov_bp @ np.linalg.inv(cov_p)
    gamma_norm = float(np.linalg.norm(gamma, ord="fro"))
    gamma_sv = np.linalg.svd(gamma, compute_uv=False)
    gamma_top_sv = float(gamma_sv[0] if len(gamma_sv) else 0.0)

    tau = _iat_from_series(ub[:, 0])
    block_len = max(1, int(math.ceil(5.0 * tau)))
    rng = np.random.default_rng(random_seed)
    norms = []
    svs = []
    for _ in range(n_bootstrap):
        idx = _bootstrap_labels(np.arange(n), block_len, rng).astype(int)
        ub_b = ub[idx]
        up_b = up[idx]
        cov_p_b = np.cov(up_b, rowvar=False) + 1e-8 * np.eye(up_b.shape[1])
        cov_bp_b = np.cov(np.hstack([ub_b, up_b]).T)[: ub.shape[1], ub.shape[1] :]
        gamma_b = cov_bp_b @ np.linalg.inv(cov_p_b)
        norms.append(float(np.linalg.norm(gamma_b, ord="fro")))
        sv = np.linalg.svd(gamma_b, compute_uv=False)
        svs.append(float(sv[0] if len(sv) else 0.0))

    return {
        "gamma_matrix": gamma.tolist(),
        "fro_norm": gamma_norm,
        "top_singular_value": gamma_top_sv,
        "fro_norm_ci95_low": float(np.percentile(norms, 2.5)),
        "fro_norm_ci95_high": float(np.percentile(norms, 97.5)),
        "top_singular_ci95_low": float(np.percentile(svs, 2.5)),
        "top_singular_ci95_high": float(np.percentile(svs, 97.5)),
    }


def run_topology_safe_analysis(
    wt_pdb: str,
    wt_traj_npz: str,
    mut_pdb: str,
    mut_traj_npz: str,
    ligand_resnames: Sequence[str],
    temperature_k: float,
    field_cfg: FieldConfig,
    latent_cfg: LatentConfig,
    te_cfg: TEConfig,
    output_dir: str,
) -> Dict[str, object]:
    ensure_openmm()
    os.makedirs(output_dir, exist_ok=True)

    wt_positions, wt_velocities, wt_dt_ps = load_traj_npz(wt_traj_npz)
    mut_positions, mut_velocities, mut_dt_ps = load_traj_npz(mut_traj_npz)
    if not np.isclose(wt_dt_ps, mut_dt_ps):
        raise ValueError(
            f"WT and MUT dt mismatch: {wt_dt_ps} ps vs {mut_dt_ps} ps. "
            "Use comparable sampling for TE/VAMP."
        )

    wt_top = app.PDBFile(wt_pdb).topology
    mut_top = app.PDBFile(mut_pdb).topology

    wt_feat = compute_region_features(
        topology=wt_top,
        positions=wt_positions,
        velocities=wt_velocities,
        dt_ps=wt_dt_ps,
        ligand_resnames=ligand_resnames,
        field_cfg=field_cfg,
    )
    mut_feat = compute_region_features(
        topology=mut_top,
        positions=mut_positions,
        velocities=mut_velocities,
        dt_ps=mut_dt_ps,
        ligand_resnames=ligand_resnames,
        field_cfg=field_cfg,
    )

    vamp_b = LinearVAMP(lag=latent_cfg.lag, n_components=latent_cfg.m_b, reg=latent_cfg.reg)
    vamp_p = LinearVAMP(lag=latent_cfg.lag, n_components=latent_cfg.m_p, reg=latent_cfg.reg)
    vamp_l = LinearVAMP(lag=latent_cfg.lag, n_components=latent_cfg.m_l, reg=latent_cfg.reg)
    vamp_b.fit_from_trajectories([wt_feat["B"], mut_feat["B"]])
    vamp_p.fit_from_trajectories([wt_feat["P"], mut_feat["P"]])
    vamp_l.fit_from_trajectories([wt_feat["L"], mut_feat["L"]])

    u_b_wt = vamp_b.transform(wt_feat["B"])
    u_b_mut = vamp_b.transform(mut_feat["B"])
    u_p_wt = vamp_p.transform(wt_feat["P"])
    u_p_mut = vamp_p.transform(mut_feat["P"])
    u_l_wt = vamp_l.transform(wt_feat["L"])
    u_l_mut = vamp_l.transform(mut_feat["L"])

    basin = compute_basin_ddg(
        u_wt=u_b_wt,
        u_mut=u_b_mut,
        temperature_k=temperature_k,
        n_bootstrap=400,
        random_seed=te_cfg.random_seed,
    )

    dist_shift = distribution_shift(u_b_wt, u_b_mut)

    te_wt = conditional_te_linear_gaussian(y=u_b_wt, x=u_p_wt, w=u_l_wt, cfg=te_cfg)
    te_mut = conditional_te_linear_gaussian(y=u_b_mut, x=u_p_mut, w=u_l_mut, cfg=te_cfg)

    gamma_wt = susceptibility_gamma(u_b_wt, u_p_wt, random_seed=te_cfg.random_seed)
    gamma_mut = susceptibility_gamma(u_b_mut, u_p_mut, random_seed=te_cfg.random_seed + 1)

    delta_gamma = np.asarray(gamma_mut["gamma_matrix"]) - np.asarray(gamma_wt["gamma_matrix"])
    delta_gamma_norm = float(np.linalg.norm(delta_gamma, ord="fro"))

    np.savez_compressed(
        os.path.join(output_dir, "latents.npz"),
        u_b_wt=u_b_wt,
        u_b_mut=u_b_mut,
        u_p_wt=u_p_wt,
        u_p_mut=u_p_mut,
        u_l_wt=u_l_wt,
        u_l_mut=u_l_mut,
    )

    results = {
        "topology_constraint": "No WT↔MUT atom/residue one-to-one mapping is used in embedding/estimands.",
        "temperature_k": temperature_k,
        "field_config": {
            "rb_ang": field_cfg.rb_ang,
            "rp_ang": field_cfg.rp_ang,
            "grid_spacing_ang": field_cfg.grid_spacing_ang,
            "sigma_ang": field_cfg.sigma_ang,
            "max_grid_points": field_cfg.max_grid_points,
            "include_velocity": field_cfg.include_velocity,
            "remove_com": field_cfg.remove_com,
            "density_normalize": field_cfg.density_normalize,
            "append_type_counts": field_cfg.append_type_counts,
        },
        "latent_config": {
            "lag": latent_cfg.lag,
            "m_b": latent_cfg.m_b,
            "m_p": latent_cfg.m_p,
            "m_l": latent_cfg.m_l,
            "reg": latent_cfg.reg,
        },
        "basin_ddg": basin,
        "distribution_shift": dist_shift,
        "te_wt_p_to_b_given_l": te_wt,
        "te_mut_p_to_b_given_l": te_mut,
        "te_delta_mut_minus_wt": float(
            te_mut["te_driver_to_target"] - te_wt["te_driver_to_target"]
        ),
        "susceptibility_wt": gamma_wt,
        "susceptibility_mut": gamma_mut,
        "susceptibility_delta_fro_norm": delta_gamma_norm,
    }
    with open(os.path.join(output_dir, "analysis_results.json"), "w", encoding="utf-8") as handle:
        json.dump(results, handle, indent=2)
    return results


def run_full_pipeline(
    build_cfg: BuildConfig,
    md_cfg: MDConfig,
    field_cfg: FieldConfig,
    latent_cfg: LatentConfig,
    te_cfg: TEConfig,
    output_dir: str,
) -> Dict[str, object]:
    os.makedirs(output_dir, exist_ok=True)
    prep = prepare_structures(build_cfg, output_dir=output_dir)
    md_dir = os.path.join(output_dir, "md")
    os.makedirs(md_dir, exist_ok=True)

    wt_md = run_openmm_md(
        input_pdb=prep.wt_pdb,
        ligand_xml=build_cfg.ligand_xml,
        md_config=md_cfg,
        output_prefix=os.path.join(md_dir, "wt"),
    )
    md_cfg_mut = md_cfg
    if md_cfg.random_seed is not None:
        md_cfg_mut = replace(md_cfg, random_seed=int(md_cfg.random_seed) + 1)
    mut_md = run_openmm_md(
        input_pdb=prep.mutant_ligand_pdb,
        ligand_xml=build_cfg.ligand_xml,
        md_config=md_cfg_mut,
        output_prefix=os.path.join(md_dir, "mut"),
    )

    analysis_dir = os.path.join(output_dir, "analysis")
    analysis = run_topology_safe_analysis(
        wt_pdb=wt_md.prepared_pdb,
        wt_traj_npz=wt_md.trajectory_npz,
        mut_pdb=mut_md.prepared_pdb,
        mut_traj_npz=mut_md.trajectory_npz,
        ligand_resnames=build_cfg.ligand_resnames,
        temperature_k=md_cfg.temperature_k,
        field_cfg=field_cfg,
        latent_cfg=latent_cfg,
        te_cfg=te_cfg,
        output_dir=analysis_dir,
    )
    vmd_script = write_vmd_comparison_script(
        wt_pdb=wt_md.prepared_pdb,
        wt_dcd=wt_md.trajectory_dcd,
        mut_pdb=mut_md.prepared_pdb,
        mut_dcd=mut_md.trajectory_dcd,
        ligand_resnames=build_cfg.ligand_resnames,
        output_tcl=os.path.join(analysis_dir, "view_wt_mut.vmd.tcl"),
        latents_npz=os.path.join(analysis_dir, "latents.npz"),
    )
    summary = {
        "structures": {
            "wt_with_ligand": prep.wt_pdb,
            "mutant_raw": prep.mutant_raw_pdb,
            "mutant_with_ligand": prep.mutant_ligand_pdb,
            "sequence_start_pos": prep.start_pos,
            "alignment_pairs": prep.alignment_pairs,
            "local_alignment_pairs": prep.local_alignment_pairs,
            "local_alignment_rmsd_ang": prep.local_alignment_rmsd_ang,
            "ligand_atoms": prep.ligand_atoms,
        },
        "md": {
            "wt": {
                "prepared_pdb": wt_md.prepared_pdb,
                "traj_npz": wt_md.trajectory_npz,
                "traj_dcd": wt_md.trajectory_dcd,
                "frames": wt_md.n_frames,
            },
            "mut": {
                "prepared_pdb": mut_md.prepared_pdb,
                "traj_npz": mut_md.trajectory_npz,
                "traj_dcd": mut_md.trajectory_dcd,
                "frames": mut_md.n_frames,
            },
        },
        "analysis_path": os.path.join(analysis_dir, "analysis_results.json"),
        "analysis": analysis,
        "visualization": {
            "vmd_script": vmd_script,
        },
    }
    with open(os.path.join(output_dir, "run_summary.json"), "w", encoding="utf-8") as handle:
        json.dump(summary, handle, indent=2)
    return summary


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Topology-safe WT vs MUT MD comparator (INS/DEL/INSDEL/DUP/SNP aware)."
    )
    parser.add_argument("--reference-pdb", required=True, help="WT reference PDB containing ligand.")
    parser.add_argument("--ligand-xml", required=True, help="OpenMM XML with ligand parameters.")
    parser.add_argument(
        "--ligand-resname",
        action="append",
        required=True,
        help="Ligand residue name(s). Repeat or use comma-separated values.",
    )
    parser.add_argument(
        "--mutations",
        action="append",
        required=True,
        help="Mutation list (repeat and/or comma-separated). Supports SNP/INS/DEL/INSDEL/DUP.",
    )
    parser.add_argument(
        "--templates",
        action="append",
        required=True,
        help="MODELLER template codes, e.g. 2XYZA (repeat and/or comma-separated).",
    )
    parser.add_argument("--chain-id", default="A", help="Protein chain used for sequence extraction/alignment.")
    parser.add_argument(
        "--original-sequence",
        default=None,
        help="Original protein sequence used by mutator/genmodels. If omitted, derived from reference PDB chain.",
    )
    parser.add_argument(
        "--start-pos",
        type=int,
        default=None,
        help="Sequence numbering start position for mutation indices; inferred from reference PDB if omitted.",
    )
    parser.add_argument("--num-models", type=int, default=50, help="Number of MODELLER models to build.")
    parser.add_argument("--num-processors", type=int, default=4, help="Parallel workers for MODELLER.")
    parser.add_argument("--modeller-seed", type=int, default=None, help="Deterministic MODELLER seed.")

    parser.add_argument("--temperature-k", type=float, default=300.0)
    parser.add_argument("--friction-per-ps", type=float, default=1.0)
    parser.add_argument("--timestep-fs", type=float, default=2.0)
    parser.add_argument("--pressure-bar", type=float, default=1.0)
    parser.add_argument("--barostat-interval", type=int, default=25)
    parser.add_argument(
        "--nonbonded-method",
        default="PME",
        help="Nonbonded method: PME/Ewald/CutoffPeriodic/CutoffNonPeriodic/NoCutoff.",
    )
    parser.add_argument("--nonbonded-cutoff-nm", type=float, default=1.0)
    parser.add_argument("--no-solvent", action="store_true", help="Disable water box + ion addition.")
    parser.add_argument("--water-model", default="tip3p", help="Water model for addSolvent (tip3p/spce/tip4pew/tip5p).")
    parser.add_argument("--solvent-padding-nm", type=float, default=1.0)
    parser.add_argument("--ionic-strength-m", type=float, default=0.15)
    parser.add_argument("--no-neutralize", action="store_true", help="Disable system neutralization when adding solvent.")
    parser.add_argument("--positive-ion", default="Na+")
    parser.add_argument("--negative-ion", default="Cl-")
    parser.add_argument("--equil-steps", type=int, default=5000)
    parser.add_argument("--heating-initial-k", type=float, default=50.0)
    parser.add_argument("--heating-steps", type=int, default=5000)
    parser.add_argument("--heating-stages", type=int, default=10)
    parser.add_argument("--prod-steps", type=int, default=50000)
    parser.add_argument("--report-interval", type=int, default=100)
    parser.add_argument("--md-seed", type=int, default=None, help="Random seed for WT MD; MUT uses seed+1.")
    parser.add_argument("--platform", default="CPU", help="OpenMM platform: AUTO/CPU/CUDA/OpenCL/Reference.")

    parser.add_argument("--rb-ang", type=float, default=6.0, help="Pocket radius R_B in Angstrom.")
    parser.add_argument("--rp-ang", type=float, default=12.0, help="Context shell radius R_P in Angstrom.")
    parser.add_argument("--grid-spacing-ang", type=float, default=1.2)
    parser.add_argument("--sigma-ang", type=float, default=1.2)
    parser.add_argument("--max-grid-points", type=int, default=512)
    parser.add_argument("--occupancy-only", action="store_true", help="Disable velocity channels.")
    parser.add_argument("--keep-com", action="store_true", help="Disable COM removal.")
    parser.add_argument(
        "--no-density-normalize",
        action="store_true",
        help="Disable per-region atom-count normalization in field channels.",
    )
    parser.add_argument(
        "--no-append-type-counts",
        action="store_true",
        help="Disable appended per-type count features.",
    )

    parser.add_argument("--vamp-lag", type=int, default=5)
    parser.add_argument("--latent-b", type=int, default=10)
    parser.add_argument("--latent-p", type=int, default=10)
    parser.add_argument("--latent-l", type=int, default=6)
    parser.add_argument("--vamp-reg", type=float, default=1e-6)

    parser.add_argument("--var-max-order", type=int, default=6)
    parser.add_argument("--te-surrogates", type=int, default=64)
    parser.add_argument("--te-seed", type=int, default=13)

    parser.add_argument("--output-dir", default="topology_safe_run", help="Output directory.")
    return parser


def main() -> None:
    parser = build_arg_parser()
    args = parser.parse_args()

    ligand_resnames = parse_csv_or_repeat(args.ligand_resname)
    mutations = parse_csv_or_repeat(args.mutations)
    templates = parse_csv_or_repeat(args.templates)

    build_cfg = BuildConfig(
        reference_pdb=args.reference_pdb,
        ligand_xml=args.ligand_xml,
        ligand_resnames=ligand_resnames,
        mutations=mutations,
        templates=templates,
        chain_id=args.chain_id,
        original_sequence=args.original_sequence,
        start_pos=args.start_pos,
        num_models=args.num_models,
        num_processors=args.num_processors,
        modeller_seed=args.modeller_seed,
    )
    md_cfg = MDConfig(
        temperature_k=args.temperature_k,
        friction_per_ps=args.friction_per_ps,
        timestep_fs=args.timestep_fs,
        pressure_bar=args.pressure_bar,
        barostat_interval=args.barostat_interval,
        nonbonded_method=args.nonbonded_method,
        nonbonded_cutoff_nm=args.nonbonded_cutoff_nm,
        add_solvent=not args.no_solvent,
        water_model=args.water_model,
        solvent_padding_nm=args.solvent_padding_nm,
        ionic_strength_m=args.ionic_strength_m,
        neutralize=not args.no_neutralize,
        positive_ion=args.positive_ion,
        negative_ion=args.negative_ion,
        heating_initial_temperature_k=args.heating_initial_k,
        heating_steps=args.heating_steps,
        heating_stages=args.heating_stages,
        equilibration_steps=args.equil_steps,
        production_steps=args.prod_steps,
        report_interval=args.report_interval,
        platform=args.platform,
        random_seed=args.md_seed,
    )
    field_cfg = FieldConfig(
        rb_ang=args.rb_ang,
        rp_ang=args.rp_ang,
        grid_spacing_ang=args.grid_spacing_ang,
        sigma_ang=args.sigma_ang,
        max_grid_points=args.max_grid_points,
        include_velocity=not args.occupancy_only,
        remove_com=not args.keep_com,
        density_normalize=not args.no_density_normalize,
        append_type_counts=not args.no_append_type_counts,
    )
    latent_cfg = LatentConfig(
        lag=args.vamp_lag,
        m_b=args.latent_b,
        m_p=args.latent_p,
        m_l=args.latent_l,
        reg=args.vamp_reg,
    )
    te_cfg = TEConfig(
        max_order=args.var_max_order,
        surrogates=args.te_surrogates,
        random_seed=args.te_seed,
    )

    summary = run_full_pipeline(
        build_cfg=build_cfg,
        md_cfg=md_cfg,
        field_cfg=field_cfg,
        latent_cfg=latent_cfg,
        te_cfg=te_cfg,
        output_dir=args.output_dir,
    )

    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
