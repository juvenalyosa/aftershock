#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CONFIG_PATH="${1:-${SCRIPT_DIR}/mutation_panel_20ns_config.json}"
CONDA_ENV_NAME="${CONDA_ENV_NAME:-bgt-openmm82}"
OUTPUT_DIR="${OUTPUT_DIR:-mutation_panel_1znf_20ns_cf}"
LIGAND_RESNAME="${LIGAND_RESNAME:-ZN}"
BINDING_CUTOFF_ANG="${BINDING_CUTOFF_ANG:-6.0}"
CONTROL_SCENARIO="${CONTROL_SCENARIO:-}"

CONSENSUS_CONTROL_ARGS=()
EVIDENCE_CONTROL_ARGS=()
if [[ -n "${CONTROL_SCENARIO}" ]]; then
  CONSENSUS_CONTROL_ARGS=(--control-scenario "${CONTROL_SCENARIO}")
  EVIDENCE_CONTROL_ARGS=(--control-scenario "${CONTROL_SCENARIO}")
fi

if [[ ! -f "${CONFIG_PATH}" ]]; then
  echo "Config not found: ${CONFIG_PATH}" >&2
  echo "Usage: bash run_toy_panel_20ns.sh [path/to/mutation_panel_20ns_config.json]" >&2
  exit 1
fi

cd "${SCRIPT_DIR}"

echo "[1/3] Running 20 ns mutation panel from config..."
conda run --no-capture-output -n "${CONDA_ENV_NAME}" \
  python run_mutation_panel_from_config.py --config "${CONFIG_PATH}"

echo "[2/3] Building per-run flow artifacts and plots..."
mapfile -t RUN_DIRS < <(find "${OUTPUT_DIR}" -mindepth 2 -maxdepth 2 -type d -name "rep*" | sort)
if [[ "${#RUN_DIRS[@]}" -eq 0 ]]; then
  echo "No run directories found under ${OUTPUT_DIR}" >&2
  exit 2
fi

for RUN_DIR in "${RUN_DIRS[@]}"; do
  echo "  - ${RUN_DIR}"
  conda run --no-capture-output -n "${CONDA_ENV_NAME}" \
    python plot_toy_analysis.py \
      --run-dir "${RUN_DIR}" \
      --ligand-resname "${LIGAND_RESNAME}" \
      --cutoff-ang "${BINDING_CUTOFF_ANG}"
done

echo "[3/5] Ranking allosteric residue and region effects..."
for RUN_DIR in "${RUN_DIRS[@]}"; do
  conda run --no-capture-output -n "${CONDA_ENV_NAME}" \
    python allostery_rank.py \
      --run-dir "${RUN_DIR}" \
      --ligand-resname "${LIGAND_RESNAME}" \
      --cutoff-ang "${BINDING_CUTOFF_ANG}" \
      --source-hotspots 10 \
      --top-edges 80 \
      --top-paths 30 \
      --top-residues 30
done

echo "[4/6] Building panel-level allostery consensus..."
conda run --no-capture-output -n "${CONDA_ENV_NAME}" \
  python allostery_consensus.py \
    --panel-dir "${OUTPUT_DIR}" \
    --ligand-resname "${LIGAND_RESNAME}" \
    --cutoff-ang "${BINDING_CUTOFF_ANG}" \
    --top-residues 30 \
    --top-regions 10 \
    "${CONSENSUS_CONTROL_ARGS[@]}"

echo "[5/6] Writing panel-level allostery evidence report..."
conda run --no-capture-output -n "${CONDA_ENV_NAME}" \
  python allostery_evidence_report.py \
    --panel-dir "${OUTPUT_DIR}" \
    --top-residues 10 \
    --top-regions 5 \
    "${EVIDENCE_CONTROL_ARGS[@]}"

echo "[6/6] Writing reader reports..."
for RUN_DIR in "${RUN_DIRS[@]}"; do
  conda run --no-capture-output -n "${CONDA_ENV_NAME}" \
    python write_reader_report.py --run-dir "${RUN_DIR}"
done

echo "Done. Panel outputs are in: ${OUTPUT_DIR}"
echo "Example report: ${OUTPUT_DIR}/snp_k2r/rep1/analysis/reader_report.md"
echo "Example allostery ranking: ${OUTPUT_DIR}/snp_k2r/rep1/analysis/allostery_residue_scores.csv"
echo "Consensus ranking: ${OUTPUT_DIR}/allostery_consensus_residues.csv"
echo "Evidence report: ${OUTPUT_DIR}/allostery_evidence_report.md"
