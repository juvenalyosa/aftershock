"""
Benchmark and calibrate the fast mutation/allostery scanner.

Input is a CSV of variants. Each row can either point to existing WT/MUT
structures or ask the script to build a mutant structure from a reference PDB.

Required column:
- name

Mutation columns:
- mutations or mutation_set: comma/semicolon separated mutation specs

Structure columns, choose one mode:
- wt_pdb and mut_pdb
- run_dir
- no structure columns: build from --reference-pdb/--template-pdb

Optional evaluation columns:
- label: binary 0/1 allosteric/effect label
- effect_score: continuous measured effect, such as |ddG|, activity shift, etc.
- any external score columns requested with --external-score-column
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import os
import shutil
from typing import Any, Dict, List, Optional, Sequence, Tuple

os.environ.setdefault("MPLCONFIGDIR", os.path.join(os.environ.get("TMPDIR", "/tmp"), "pert-matplotlib"))

import matplotlib.pyplot as plt
import numpy as np

from fast_allostery_scan import _infer_from_run_dir, run_fast_scan
from topology_safe_pipeline import BuildConfig, prepare_structures


def _parse_csv_tokens(value: object) -> List[str]:
    out: List[str] = []
    for chunk in str(value or "").replace(";", ",").split(","):
        token = chunk.strip()
        if token:
            out.append(token)
    return out


def _as_float(value: object) -> Optional[float]:
    if value is None:
        return None
    text = str(value).strip()
    if not text:
        return None
    try:
        val = float(text)
    except ValueError:
        return None
    return val if math.isfinite(val) else None


def _load_rows(path: str) -> List[Dict[str, str]]:
    with open(path, "r", newline="", encoding="utf-8") as handle:
        reader = csv.DictReader(handle)
        if reader.fieldnames is None:
            raise ValueError(f"Benchmark CSV has no header: {path}")
        rows = [dict(row) for row in reader]
    if not rows:
        raise ValueError(f"Benchmark CSV contains no rows: {path}")
    if "name" not in rows[0]:
        raise ValueError("Benchmark CSV must contain a 'name' column.")
    return rows


def _write_csv(path: str, rows: Sequence[Dict[str, object]]) -> None:
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    if not rows:
        with open(path, "w", encoding="utf-8") as handle:
            handle.write("")
        return
    keys: List[str] = []
    for row in rows:
        for key in row.keys():
            if key not in keys:
                keys.append(key)
    with open(path, "w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=keys)
        writer.writeheader()
        writer.writerows(rows)


def _rankdata(values: Sequence[float]) -> np.ndarray:
    arr = np.asarray(values, dtype=float)
    order = np.argsort(arr, kind="mergesort")
    ranks = np.empty(len(arr), dtype=float)
    i = 0
    while i < len(arr):
        j = i + 1
        while j < len(arr) and arr[order[j]] == arr[order[i]]:
            j += 1
        rank = 0.5 * (i + j - 1) + 1.0
        ranks[order[i:j]] = rank
        i = j
    return ranks


def _pearson(x: Sequence[float], y: Sequence[float]) -> Optional[float]:
    x_arr = np.asarray(x, dtype=float)
    y_arr = np.asarray(y, dtype=float)
    mask = np.isfinite(x_arr) & np.isfinite(y_arr)
    if int(np.sum(mask)) < 2:
        return None
    x_arr = x_arr[mask]
    y_arr = y_arr[mask]
    x_sd = float(np.std(x_arr))
    y_sd = float(np.std(y_arr))
    if x_sd <= 1e-12 or y_sd <= 1e-12:
        return None
    return float(np.corrcoef(x_arr, y_arr)[0, 1])


def _spearman(x: Sequence[float], y: Sequence[float]) -> Optional[float]:
    x_arr = np.asarray(x, dtype=float)
    y_arr = np.asarray(y, dtype=float)
    mask = np.isfinite(x_arr) & np.isfinite(y_arr)
    if int(np.sum(mask)) < 2:
        return None
    return _pearson(_rankdata(x_arr[mask]), _rankdata(y_arr[mask]))


def _roc_auc(labels: Sequence[int], scores: Sequence[float]) -> Optional[float]:
    y = np.asarray(labels, dtype=int)
    s = np.asarray(scores, dtype=float)
    mask = np.isfinite(s)
    y = y[mask]
    s = s[mask]
    n_pos = int(np.sum(y == 1))
    n_neg = int(np.sum(y == 0))
    if n_pos == 0 or n_neg == 0:
        return None
    ranks = _rankdata(s)
    sum_pos = float(np.sum(ranks[y == 1]))
    auc = (sum_pos - n_pos * (n_pos + 1) / 2.0) / float(n_pos * n_neg)
    return float(auc)


def _average_precision(labels: Sequence[int], scores: Sequence[float]) -> Optional[float]:
    pairs = [
        (float(score), int(label))
        for label, score in zip(labels, scores)
        if math.isfinite(float(score))
    ]
    positives = sum(label == 1 for _, label in pairs)
    if positives == 0:
        return None
    pairs.sort(key=lambda item: item[0], reverse=True)
    hit = 0
    precision_sum = 0.0
    for rank, (_, label) in enumerate(pairs, start=1):
        if label == 1:
            hit += 1
            precision_sum += hit / float(rank)
    return float(precision_sum / positives)


def _best_binary_threshold(labels: Sequence[int], scores: Sequence[float]) -> Optional[Dict[str, float]]:
    pairs = [
        (int(label), float(score))
        for label, score in zip(labels, scores)
        if math.isfinite(float(score))
    ]
    if not pairs or not any(label == 1 for label, _ in pairs) or not any(label == 0 for label, _ in pairs):
        return None
    thresholds = sorted({score for _, score in pairs}, reverse=True)
    best: Optional[Dict[str, float]] = None
    for threshold in thresholds:
        tp = sum(label == 1 and score >= threshold for label, score in pairs)
        fp = sum(label == 0 and score >= threshold for label, score in pairs)
        fn = sum(label == 1 and score < threshold for label, score in pairs)
        tn = sum(label == 0 and score < threshold for label, score in pairs)
        sensitivity = tp / float(max(1, tp + fn))
        specificity = tn / float(max(1, tn + fp))
        balanced_accuracy = 0.5 * (sensitivity + specificity)
        youden_j = sensitivity + specificity - 1.0
        candidate = {
            "threshold": float(threshold),
            "balanced_accuracy": float(balanced_accuracy),
            "sensitivity": float(sensitivity),
            "specificity": float(specificity),
            "youden_j": float(youden_j),
        }
        if best is None or (candidate["balanced_accuracy"], candidate["youden_j"]) > (
            best["balanced_accuracy"],
            best["youden_j"],
        ):
            best = candidate
    return best


def _numeric_column(rows: Sequence[Dict[str, object]], key: str) -> List[float]:
    values: List[float] = []
    for row in rows:
        val = _as_float(row.get(key))
        values.append(float("nan") if val is None else val)
    return values


def _label_column(rows: Sequence[Dict[str, object]], key: str) -> Optional[List[int]]:
    labels: List[int] = []
    for row in rows:
        value = _as_float(row.get(key))
        if value is None:
            return None
        labels.append(1 if value > 0 else 0)
    return labels


def _evaluate_predictions(
    rows: Sequence[Dict[str, object]],
    label_column: str,
    effect_column: str,
    external_score_columns: Sequence[str],
) -> Dict[str, Any]:
    score_columns = ["global_fast_allostery_score", "mean_top10_destabilization_proxy", *external_score_columns]
    summary: Dict[str, Any] = {"n": len(rows), "scores": {}}
    labels = _label_column(rows, label_column) if label_column else None
    effects = _numeric_column(rows, effect_column) if effect_column else []
    has_effects = bool(effect_column) and any(math.isfinite(v) for v in effects)

    for score_col in score_columns:
        scores = _numeric_column(rows, score_col)
        entry: Dict[str, Any] = {
            "available": int(sum(math.isfinite(v) for v in scores)),
        }
        if labels is not None:
            entry["roc_auc"] = _roc_auc(labels, scores)
            entry["average_precision"] = _average_precision(labels, scores)
            entry["best_threshold"] = _best_binary_threshold(labels, scores)
        if has_effects:
            entry["pearson_vs_effect"] = _pearson(scores, effects)
            entry["spearman_vs_effect"] = _spearman(scores, effects)
        summary["scores"][score_col] = entry
    return summary


def _plot_benchmark(
    rows: Sequence[Dict[str, object]],
    output_png: str,
    label_column: str,
    effect_column: str,
) -> None:
    scores = np.asarray(_numeric_column(rows, "global_fast_allostery_score"), dtype=float)
    labels = _label_column(rows, label_column) if label_column else None
    effects = np.asarray(_numeric_column(rows, effect_column), dtype=float) if effect_column else np.asarray([])

    fig, axes = plt.subplots(1, 2, figsize=(11.5, 4.5))
    axes[0].hist(scores[np.isfinite(scores)], bins=min(12, max(3, len(scores))), color="#4C78A8", alpha=0.85)
    axes[0].set_title("Fast Score Distribution")
    axes[0].set_xlabel("global_fast_allostery_score")
    axes[0].set_ylabel("count")
    axes[0].grid(alpha=0.2, axis="y")

    if labels is not None:
        jitter = np.linspace(-0.04, 0.04, len(scores)) if len(scores) else np.asarray([])
        axes[1].scatter(np.asarray(labels, dtype=float) + jitter, scores, color="#E45756", edgecolor="black", alpha=0.85)
        axes[1].set_xticks([0, 1])
        axes[1].set_xlabel(label_column)
        axes[1].set_ylabel("global_fast_allostery_score")
        axes[1].set_title("Score vs Binary Label")
    elif effects.size:
        mask = np.isfinite(effects) & np.isfinite(scores)
        axes[1].scatter(effects[mask], scores[mask], color="#E45756", edgecolor="black", alpha=0.85)
        axes[1].set_xlabel(effect_column)
        axes[1].set_ylabel("global_fast_allostery_score")
        axes[1].set_title("Score vs Measured Effect")
    else:
        axes[1].axis("off")
        axes[1].text(0.5, 0.5, "No label/effect column supplied", ha="center", va="center")
    axes[1].grid(alpha=0.2)

    fig.tight_layout()
    os.makedirs(os.path.dirname(output_png) or ".", exist_ok=True)
    fig.savefig(output_png, dpi=220)
    plt.close(fig)


def _resolve_structure_pair(
    row: Dict[str, str],
    output_dir: str,
    index: int,
    args: argparse.Namespace,
    mutations: Sequence[str],
) -> Tuple[str, str]:
    run_dir = str(row.get("run_dir", "")).strip()
    if run_dir:
        wt_pdb, mut_pdb, _ = _infer_from_run_dir(run_dir)
        return wt_pdb, mut_pdb

    wt_pdb = str(row.get("wt_pdb", "")).strip()
    mut_pdb = str(row.get("mut_pdb", "")).strip()
    if wt_pdb and mut_pdb:
        return wt_pdb, mut_pdb

    if not args.reference_pdb:
        raise ValueError(
            f"Row {index + 1} has no run_dir/wt_pdb/mut_pdb. Provide --reference-pdb to build structures."
        )
    if not args.template_pdb:
        raise ValueError("Structure building requires --template-pdb.")

    name = str(row.get("name", f"row_{index + 1}")).strip() or f"row_{index + 1}"
    run_dir = os.path.join(output_dir, "built_structures", name)
    template_code = args.template[:-1]
    seed_dir = os.path.join(run_dir, "model_build", "modeling_job")
    os.makedirs(seed_dir, exist_ok=True)
    shutil.copy2(args.template_pdb, os.path.join(seed_dir, f"{template_code}.pdb"))
    build_cfg = BuildConfig(
        reference_pdb=args.reference_pdb,
        ligand_xml=args.ligand_xml,
        ligand_resnames=[args.ligand_resname],
        mutations=list(mutations),
        templates=[args.template],
        chain_id=args.chain_id,
        num_models=args.num_models,
        num_processors=args.num_processors,
        modeller_seed=args.modeller_seed_base + index,
    )
    prep = prepare_structures(build_cfg, output_dir=run_dir)
    return prep.wt_pdb, prep.mutant_ligand_pdb


def run_benchmark(args: argparse.Namespace) -> Dict[str, Any]:
    input_rows = _load_rows(args.input_csv)
    os.makedirs(args.output_dir, exist_ok=True)
    prediction_rows: List[Dict[str, object]] = []

    for index, row in enumerate(input_rows):
        name = str(row.get("name", f"row_{index + 1}")).strip() or f"row_{index + 1}"
        mutations = _parse_csv_tokens(row.get("mutations") or row.get("mutation_set"))
        if not mutations:
            raise ValueError(f"Row {index + 1} ({name}) has no mutations/mutation_set value.")
        wt_pdb, mut_pdb = _resolve_structure_pair(row, args.output_dir, index, args, mutations)
        scan_dir = os.path.join(args.output_dir, "scans", name)
        ligand_resname = str(row.get("ligand_resname", "")).strip() or args.ligand_resname
        scan = run_fast_scan(
            wt_pdb=wt_pdb,
            mut_pdb=mut_pdb,
            ligand_resname=ligand_resname,
            output_dir=scan_dir,
            mutation_label=name,
            mutation_specs=mutations,
            cutoff_ang=args.cutoff_ang,
            contact_threshold_ang=args.contact_threshold_ang,
            source_hotspots=args.source_hotspots,
            top_residues=args.top_residues,
        )
        pred: Dict[str, object] = dict(row)
        pred.update(
            {
                "name": name,
                "mutations": ",".join(mutations),
                "wt_pdb": wt_pdb,
                "mut_pdb": mut_pdb,
                "predicted_allosteric_effect": scan["predicted_allosteric_effect"],
                "global_fast_allostery_score": float(scan["global_fast_allostery_score"]),
                "mean_top10_destabilization_proxy": float(scan["mean_top10_destabilization_proxy"]),
                "aligned_ca_rmsd_ang": float(scan["aligned_ca_rmsd_ang"]),
                "mutation_source_residues": ",".join(scan.get("mutation_source_residues", [])),
                "source_residues": ",".join(scan["source_residues"]),
                "target_residues": ",".join(scan["target_residues"]),
                "deleted_wt_residues": ",".join(scan["deleted_wt_residues"]),
                "top_residues": ",".join(
                    item["node_label"] for item in scan["top_residues"][: min(args.top_residues, len(scan["top_residues"]))]
                ),
                "summary_json": scan["outputs"]["summary_json"],
            }
        )
        prediction_rows.append(pred)

    predictions_csv = os.path.join(args.output_dir, "benchmark_predictions.csv")
    _write_csv(predictions_csv, prediction_rows)
    summary = _evaluate_predictions(
        prediction_rows,
        label_column=args.label_column,
        effect_column=args.effect_column,
        external_score_columns=args.external_score_column or [],
    )
    summary["input_csv"] = args.input_csv
    summary["predictions_csv"] = predictions_csv
    summary["method_note"] = (
        "Benchmark summary reports association/calibration only. Use independent held-out data "
        "before claiming superiority over FoldX/DDMut or any other method."
    )
    summary_json = os.path.join(args.output_dir, "benchmark_summary.json")
    with open(summary_json, "w", encoding="utf-8") as handle:
        json.dump(summary, handle, indent=2)
    plot_png = os.path.join(args.output_dir, "benchmark_summary.png")
    _plot_benchmark(prediction_rows, plot_png, args.label_column, args.effect_column)
    manifest = {
        "rows": len(prediction_rows),
        "predictions_csv": predictions_csv,
        "summary_json": summary_json,
        "summary_plot": plot_png,
    }
    manifest_path = os.path.join(args.output_dir, "benchmark_manifest.json")
    with open(manifest_path, "w", encoding="utf-8") as handle:
        json.dump(manifest, handle, indent=2)
    return manifest


def main() -> None:
    parser = argparse.ArgumentParser(description="Benchmark/calibrate fast allostery mutation scores.")
    parser.add_argument("--input-csv", required=True, help="Benchmark CSV with name and mutations columns.")
    parser.add_argument("--output-dir", default="fast_allostery_benchmark")
    parser.add_argument("--reference-pdb", default=None, help="Reference PDB used when rows do not provide structures.")
    parser.add_argument("--template-pdb", default=None, help="Template PDB copied for MODELLER when building structures.")
    parser.add_argument("--ligand-xml", default="toy_data/empty_ligand.xml")
    parser.add_argument("--ligand-resname", default="ZN")
    parser.add_argument("--template", default="1ZNFA")
    parser.add_argument("--chain-id", default="A")
    parser.add_argument("--num-models", type=int, default=1)
    parser.add_argument("--num-processors", type=int, default=1)
    parser.add_argument("--modeller-seed-base", type=int, default=7000)
    parser.add_argument("--cutoff-ang", type=float, default=6.0)
    parser.add_argument("--contact-threshold-ang", type=float, default=8.0)
    parser.add_argument("--source-hotspots", type=int, default=8)
    parser.add_argument("--top-residues", type=int, default=10)
    parser.add_argument("--label-column", default="label")
    parser.add_argument("--effect-column", default="effect_score")
    parser.add_argument(
        "--external-score-column",
        action="append",
        default=None,
        help="Optional comparator score column, for example foldx_ddg or ddmut_score. Repeat as needed.",
    )
    args = parser.parse_args()
    print(json.dumps(run_benchmark(args), indent=2))


if __name__ == "__main__":
    main()
