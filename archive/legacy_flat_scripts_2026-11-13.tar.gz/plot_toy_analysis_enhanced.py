"""
Enhanced interpretation plots for topology-safe toy runs.
"""

from __future__ import annotations

import argparse
import csv
import json
import os
from typing import Dict, List, Tuple

import matplotlib.pyplot as plt
import numpy as np
from sklearn.mixture import GaussianMixture


def _load_json(path: str) -> Dict:
    with open(path, "r", encoding="utf-8") as handle:
        return json.load(handle)


def _resolve_run_path(run_dir: str, value: str) -> str:
    if os.path.isabs(value):
        return value
    if os.path.exists(value):
        return os.path.abspath(value)
    return os.path.abspath(os.path.join(run_dir, value))


def _moving_average(x: np.ndarray, window: int) -> np.ndarray:
    if window <= 1 or len(x) < window:
        return x
    kernel = np.ones(window, dtype=float) / float(window)
    return np.convolve(x, kernel, mode="same")


def _pad_dims(x: np.ndarray, n: int) -> np.ndarray:
    if x.shape[1] >= n:
        return x[:, :n]
    out = np.zeros((x.shape[0], n), dtype=float)
    out[:, : x.shape[1]] = x
    return out


def plot_basin_convergence(
    u_b_wt: np.ndarray,
    u_b_mut: np.ndarray,
    n_basins: int,
    out_png: str,
) -> Tuple[np.ndarray, np.ndarray]:
    pooled = np.vstack([u_b_wt, u_b_mut])
    gmm = GaussianMixture(
        n_components=max(1, n_basins),
        covariance_type="full",
        reg_covar=1e-6,
        random_state=13,
    )
    gmm.fit(pooled)
    labels_wt = gmm.predict(u_b_wt)
    labels_mut = gmm.predict(u_b_mut)

    fig, axes = plt.subplots(1, 2, figsize=(12, 4.8), sharey=True)
    colors = plt.cm.tab10(np.linspace(0, 1, n_basins))

    for ax, labels, title in [
        (axes[0], labels_wt, "WT cumulative basin occupancy"),
        (axes[1], labels_mut, "MUT cumulative basin occupancy"),
    ]:
        n = len(labels)
        t = np.arange(1, n + 1, dtype=float)
        for basin in range(n_basins):
            indicator = (labels == basin).astype(float)
            cum = np.cumsum(indicator) / t
            ax.plot(t, cum, color=colors[basin], label=f"B{basin}")
        ax.set_xlabel("Frame")
        ax.set_title(title)
        ax.grid(alpha=0.25, linewidth=0.5)
    axes[0].set_ylabel("Cumulative occupancy")
    axes[1].legend(frameon=False, ncol=2)
    fig.suptitle("Convergence View: Basin Population Trajectories")
    fig.tight_layout()
    fig.savefig(out_png, dpi=220)
    plt.close(fig)
    return labels_wt, labels_mut


def plot_latent_timecourse(
    u_b_wt: np.ndarray,
    u_b_mut: np.ndarray,
    out_png: str,
) -> None:
    wt = _pad_dims(u_b_wt, 3)
    mut = _pad_dims(u_b_mut, 3)
    smooth_w = max(3, len(wt) // 25)
    smooth_m = max(3, len(mut) // 25)

    fig, axes = plt.subplots(3, 2, figsize=(12, 8), sharex="col")
    for comp in range(3):
        t_w = np.arange(len(wt))
        t_m = np.arange(len(mut))
        axes[comp, 0].plot(t_w, wt[:, comp], color="#1f77b4", alpha=0.25, linewidth=1)
        axes[comp, 0].plot(
            t_w,
            _moving_average(wt[:, comp], smooth_w),
            color="#1f77b4",
            linewidth=2,
        )
        axes[comp, 0].set_ylabel(f"uB[{comp}]")
        axes[comp, 0].grid(alpha=0.25, linewidth=0.5)

        axes[comp, 1].plot(t_m, mut[:, comp], color="#d62728", alpha=0.25, linewidth=1)
        axes[comp, 1].plot(
            t_m,
            _moving_average(mut[:, comp], smooth_m),
            color="#d62728",
            linewidth=2,
        )
        axes[comp, 1].grid(alpha=0.25, linewidth=0.5)

    axes[0, 0].set_title("WT pocket latent components")
    axes[0, 1].set_title("MUT pocket latent components")
    axes[2, 0].set_xlabel("Frame")
    axes[2, 1].set_xlabel("Frame")
    fig.suptitle("Latent Time-Course (raw + smoothed)")
    fig.tight_layout()
    fig.savefig(out_png, dpi=220)
    plt.close(fig)


def plot_information_dashboard(analysis: Dict, out_png: str) -> None:
    te_wt = analysis["te_wt_p_to_b_given_l"]
    te_mut = analysis["te_mut_p_to_b_given_l"]
    gamma_wt = analysis["susceptibility_wt"]
    gamma_mut = analysis["susceptibility_mut"]

    fig, axes = plt.subplots(1, 2, figsize=(12, 4.8))

    names = ["P→B|L", "B→P|L"]
    x = np.arange(len(names))
    width = 0.35
    wt_vals = [te_wt["te_driver_to_target"], te_wt["te_target_to_driver"]]
    mut_vals = [te_mut["te_driver_to_target"], te_mut["te_target_to_driver"]]
    axes[0].bar(x - width / 2, wt_vals, width=width, color="#1f77b4", label="WT")
    axes[0].bar(x + width / 2, mut_vals, width=width, color="#d62728", label="MUT")
    axes[0].set_xticks(x)
    axes[0].set_xticklabels(names)
    axes[0].set_ylabel("TE (nats)")
    axes[0].set_title("Directed predictive dependence")
    axes[0].legend(frameon=False)
    axes[0].grid(alpha=0.2, linewidth=0.5, axis="y")

    labels = ["WT p-value", "MUT p-value", "0.05"]
    vals = [te_wt["surrogate_pvalue"], te_mut["surrogate_pvalue"], 0.05]
    colors = ["#1f77b4", "#d62728", "#777777"]
    axes[1].bar(labels, vals, color=colors)
    axes[1].set_ylim(0.0, max(0.2, max(vals) * 1.35))
    axes[1].set_ylabel("Surrogate-test p-value")
    axes[1].set_title("Significance + coupling shifts")
    axes[1].grid(alpha=0.2, linewidth=0.5, axis="y")

    text = (
        f"ΔTE(MUT-WT): {analysis['te_delta_mut_minus_wt']:.3f}\\n"
        f"||Γ||F WT: {gamma_wt['fro_norm']:.3f}\\n"
        f"||Γ||F MUT: {gamma_mut['fro_norm']:.3f}\\n"
        f"Δ||Γ||F: {analysis['susceptibility_delta_fro_norm']:.3f}"
    )
    axes[1].text(
        0.03,
        0.95,
        text,
        transform=axes[1].transAxes,
        va="top",
        ha="left",
        fontsize=9,
        bbox={"facecolor": "white", "alpha": 0.8, "edgecolor": "#cccccc"},
    )

    fig.suptitle("Information-Flow Dashboard")
    fig.tight_layout()
    fig.savefig(out_png, dpi=220)
    plt.close(fig)


def _read_binding_csv(path: str) -> List[Dict[str, str]]:
    rows: List[Dict[str, str]] = []
    with open(path, "r", encoding="utf-8") as handle:
        reader = csv.DictReader(handle)
        for row in reader:
            rows.append(row)
    return rows


def plot_binding_site_shift(binding_csv: str, out_png: str) -> None:
    rows = _read_binding_csv(binding_csv)
    points = []
    only_wt = []
    only_mut = []
    for row in rows:
        residue = row["residue"]
        w = row["wt_min_dist_ang"].strip()
        m = row["mut_min_dist_ang"].strip()
        d = row["delta_mut_minus_wt"].strip()
        if d:
            points.append((residue, float(d)))
        elif w and not m:
            only_wt.append(residue)
        elif m and not w:
            only_mut.append(residue)

    points.sort(key=lambda x: abs(x[1]), reverse=True)
    if not points:
        fig, ax = plt.subplots(figsize=(8, 3))
        ax.text(0.5, 0.5, "No shared residues with numeric Δdistance.", ha="center", va="center")
        ax.axis("off")
        fig.savefig(out_png, dpi=220)
        plt.close(fig)
        return

    residues = [x[0] for x in points]
    deltas = np.array([x[1] for x in points], dtype=float)
    y = np.arange(len(residues))
    colors = np.where(deltas >= 0.0, "#d62728", "#1f77b4")

    fig, ax = plt.subplots(figsize=(9, max(3.5, 0.45 * len(residues) + 1.5)))
    ax.barh(y, deltas, color=colors, alpha=0.85)
    ax.set_yticks(y)
    ax.set_yticklabels(residues)
    ax.invert_yaxis()
    ax.axvline(0.0, color="black", linewidth=1)
    ax.set_xlabel("Δ min distance to ligand (MUT - WT, Å)")
    ax.set_title("Binding-site residue shifts around ligand")
    ax.grid(alpha=0.2, linewidth=0.5, axis="x")

    notes = []
    if only_wt:
        notes.append("WT-only: " + ", ".join(only_wt))
    if only_mut:
        notes.append("MUT-only: " + ", ".join(only_mut))
    if notes:
        ax.text(
            0.02,
            0.02,
            "\n".join(notes),
            transform=ax.transAxes,
            va="bottom",
            ha="left",
            fontsize=8,
            bbox={"facecolor": "white", "alpha": 0.8, "edgecolor": "#cccccc"},
        )

    fig.tight_layout()
    fig.savefig(out_png, dpi=220)
    plt.close(fig)


def write_interpretation_summary(
    summary: Dict,
    analysis: Dict,
    labels_wt: np.ndarray,
    labels_mut: np.ndarray,
    out_json: str,
) -> None:
    basin_wt = np.bincount(labels_wt, minlength=analysis["basin_ddg"]["n_basins"]) / len(labels_wt)
    basin_mut = np.bincount(labels_mut, minlength=analysis["basin_ddg"]["n_basins"]) / len(labels_mut)
    payload = {
        "frames_wt": int(summary["md"]["wt"]["frames"]),
        "frames_mut": int(summary["md"]["mut"]["frames"]),
        "te_wt_p_to_b_given_l": analysis["te_wt_p_to_b_given_l"]["te_driver_to_target"],
        "te_mut_p_to_b_given_l": analysis["te_mut_p_to_b_given_l"]["te_driver_to_target"],
        "te_delta_mut_minus_wt": analysis["te_delta_mut_minus_wt"],
        "wt_surrogate_pvalue": analysis["te_wt_p_to_b_given_l"]["surrogate_pvalue"],
        "mut_surrogate_pvalue": analysis["te_mut_p_to_b_given_l"]["surrogate_pvalue"],
        "distribution_method": analysis["distribution_shift"]["method"],
        "js_divergence": analysis["distribution_shift"].get("js_divergence"),
        "gmm_kl_wt_to_mut": analysis["distribution_shift"].get("gmm_kl_wt_to_mut"),
        "susceptibility_delta_fro_norm": analysis["susceptibility_delta_fro_norm"],
        "empirical_basin_pop_wt": basin_wt.tolist(),
        "empirical_basin_pop_mut": basin_mut.tolist(),
    }
    with open(out_json, "w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-dir", required=True)
    args = parser.parse_args()

    run_dir = args.run_dir
    summary = _load_json(os.path.join(run_dir, "run_summary.json"))
    analysis = _load_json(os.path.join(run_dir, "analysis", "analysis_results.json"))
    latents = np.load(os.path.join(run_dir, "analysis", "latents.npz"))
    u_b_wt = np.asarray(latents["u_b_wt"], dtype=float)
    u_b_mut = np.asarray(latents["u_b_mut"], dtype=float)

    analysis_dir = os.path.join(run_dir, "analysis")
    os.makedirs(analysis_dir, exist_ok=True)

    labels_wt, labels_mut = plot_basin_convergence(
        u_b_wt=u_b_wt,
        u_b_mut=u_b_mut,
        n_basins=int(analysis["basin_ddg"]["n_basins"]),
        out_png=os.path.join(analysis_dir, "plot_convergence_basin_prob.png"),
    )
    plot_latent_timecourse(
        u_b_wt=u_b_wt,
        u_b_mut=u_b_mut,
        out_png=os.path.join(analysis_dir, "plot_latent_timecourse.png"),
    )
    plot_information_dashboard(
        analysis=analysis,
        out_png=os.path.join(analysis_dir, "plot_information_dashboard.png"),
    )
    binding_csv = os.path.join(analysis_dir, "binding_site_residues.csv")
    if os.path.exists(binding_csv):
        plot_binding_site_shift(
            binding_csv=binding_csv,
            out_png=os.path.join(analysis_dir, "plot_binding_site_shift.png"),
        )

    write_interpretation_summary(
        summary=summary,
        analysis=analysis,
        labels_wt=labels_wt,
        labels_mut=labels_mut,
        out_json=os.path.join(analysis_dir, "interpretation_summary.json"),
    )

    manifest = {
        "plots": [
            "analysis/plot_convergence_basin_prob.png",
            "analysis/plot_latent_timecourse.png",
            "analysis/plot_information_dashboard.png",
            "analysis/plot_binding_site_shift.png",
        ],
        "summary": "analysis/interpretation_summary.json",
    }
    vmd_script = None
    if isinstance(summary.get("visualization"), dict):
        vmd_script = summary["visualization"].get("vmd_script")
    if vmd_script:
        abs_script = _resolve_run_path(run_dir, vmd_script)
        if os.path.exists(abs_script):
            manifest["scripts"] = [os.path.relpath(abs_script, run_dir)]
    mut_flow = os.path.join(run_dir, "analysis", "view_mut_flow.vmd.tcl")
    if os.path.exists(mut_flow):
        scripts = list(manifest.get("scripts", []))
        rel = os.path.relpath(mut_flow, run_dir)
        if rel not in scripts:
            scripts.append(rel)
        manifest["scripts"] = scripts
    with open(os.path.join(analysis_dir, "enhanced_plot_manifest.json"), "w", encoding="utf-8") as handle:
        json.dump(manifest, handle, indent=2)
    print(json.dumps(manifest, indent=2))


if __name__ == "__main__":
    main()
