"""
Aggregate per-run allostery rankings into scenario-level consensus results.

The per-run `allostery_rank.py` output is useful for one simulation. This
script adds the next layer needed for precision: replicate support, uncertainty,
and conservative consensus ranking across runs.
"""

from __future__ import annotations

import argparse
import csv
import json
import os
import re
from collections import defaultdict
from typing import Any, DefaultDict, Dict, Iterable, List, Optional, Sequence, Tuple

os.environ.setdefault("MPLCONFIGDIR", os.path.join(os.environ.get("TMPDIR", "/tmp"), "pert-matplotlib"))

import matplotlib.pyplot as plt
import numpy as np

from allostery_rank import run_allostery_ranking
from plot_toy_analysis import _resolve_run_path
from topology_safe_pipeline import _tcl_braced_path


def _load_json(path: str) -> Dict[str, Any]:
    with open(path, "r", encoding="utf-8") as handle:
        return json.load(handle)


def _safe_float(value: Any, default: float = float("nan")) -> float:
    try:
        if value is None:
            return default
        return float(value)
    except (TypeError, ValueError):
        return default


def _safe_int(value: Any, default: int = 0) -> int:
    try:
        if value is None:
            return default
        return int(float(value))
    except (TypeError, ValueError):
        return default


def _safe_bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    text = str(value).strip().lower()
    return text in {"1", "true", "yes", "y"}


def _read_csv(path: str) -> List[Dict[str, str]]:
    with open(path, "r", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def _write_csv(path: str, rows: Sequence[Dict[str, Any]]) -> None:
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    if not rows:
        with open(path, "w", encoding="utf-8") as handle:
            handle.write("")
        return
    keys = list(rows[0].keys())
    with open(path, "w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=keys)
        writer.writeheader()
        writer.writerows(rows)


def _scenario_from_run_dir(run_dir: str) -> str:
    return os.path.basename(os.path.dirname(os.path.abspath(run_dir)))


def _replicate_from_run_dir(run_dir: str) -> str:
    return os.path.basename(os.path.abspath(run_dir))


def _find_run_dirs(panel_dir: str) -> List[str]:
    out: List[str] = []
    for root, _, files in os.walk(panel_dir):
        if "run_summary.json" in files:
            out.append(root)
    return sorted(out)


def _bootstrap_mean_ci(values: Sequence[float], rng: np.random.Generator, n_boot: int) -> Tuple[float, float]:
    arr = np.asarray([v for v in values if np.isfinite(v)], dtype=float)
    if arr.size == 0:
        return float("nan"), float("nan")
    if arr.size == 1 or n_boot <= 0:
        value = float(arr[0])
        return value, value
    means = np.zeros(int(n_boot), dtype=float)
    for i in range(int(n_boot)):
        sample = arr[rng.integers(0, arr.size, size=arr.size)]
        means[i] = float(np.mean(sample))
    return float(np.percentile(means, 2.5)), float(np.percentile(means, 97.5))


def _node_sort_key(label: str) -> Tuple[str, int, str]:
    text = str(label)
    chain = ""
    residue = text
    if ":" in text:
        chain, residue = text.split(":", 1)
    match = re.search(r"-?\d+", residue)
    resid = int(match.group(0)) if match else 0
    return chain, resid, residue


def _collect_run_records(
    run_dirs: Sequence[str],
    rank_missing: bool,
    ligand_resname: str,
    cutoff_ang: float,
    source_hotspots: int,
    top_edges: int,
    top_paths: int,
    top_residues: int,
    max_frames: Optional[int],
    contact_threshold_ang: float,
) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]], Dict[str, List[str]], Dict[str, Dict[str, str]]]:
    residue_records: List[Dict[str, Any]] = []
    region_records: List[Dict[str, Any]] = []
    scenario_runs: DefaultDict[str, List[str]] = defaultdict(list)
    representative_run: Dict[str, Dict[str, str]] = {}

    for run_dir_raw in run_dirs:
        run_dir = os.path.abspath(run_dir_raw)
        scenario = _scenario_from_run_dir(run_dir)
        replicate = _replicate_from_run_dir(run_dir)
        scenario_runs[scenario].append(run_dir)
        representative_run.setdefault(
            scenario,
            {"run_dir": run_dir, "scenario": scenario, "replicate": replicate},
        )

        analysis_dir = os.path.join(run_dir, "analysis")
        residue_csv = os.path.join(analysis_dir, "allostery_residue_scores.csv")
        region_csv = os.path.join(analysis_dir, "allostery_region_scores.csv")
        if rank_missing and not os.path.exists(residue_csv):
            run_allostery_ranking(
                run_dir=run_dir,
                ligand_resname=ligand_resname,
                cutoff_ang=cutoff_ang,
                source_hotspots=source_hotspots,
                top_edges_n=top_edges,
                top_paths_n=top_paths,
                top_residues=top_residues,
                region_window=5,
                max_frames=max_frames,
                contact_threshold_ang=contact_threshold_ang,
            )

        if os.path.exists(residue_csv):
            rows = _read_csv(residue_csv)
            max_rank = max([_safe_int(row.get("rank"), 0) for row in rows] or [0])
            for row in rows:
                rank = _safe_int(row.get("rank"), max_rank)
                rank_percentile = 1.0
                if max_rank > 1:
                    rank_percentile = 1.0 - float(rank - 1) / float(max_rank - 1)
                rec: Dict[str, Any] = {
                    "scenario": scenario,
                    "replicate": replicate,
                    "run_dir": run_dir,
                    "max_rank_in_run": max_rank,
                    "rank_percentile": rank_percentile,
                }
                rec.update(row)
                residue_records.append(rec)

        if os.path.exists(region_csv):
            for row in _read_csv(region_csv):
                rec = {"scenario": scenario, "replicate": replicate, "run_dir": run_dir}
                rec.update(row)
                region_records.append(rec)

    return residue_records, region_records, dict(scenario_runs), representative_run


def _aggregate_residues(
    records: Sequence[Dict[str, Any]],
    scenario_runs: Dict[str, List[str]],
    top_support_n: int,
    rng: np.random.Generator,
    n_boot: int,
) -> List[Dict[str, Any]]:
    by_key: DefaultDict[Tuple[str, str], List[Dict[str, Any]]] = defaultdict(list)
    for row in records:
        by_key[(str(row["scenario"]), str(row["node_label"]))].append(dict(row))

    component_cols = [
        "structural_component",
        "dynamics_component",
        "contact_component",
        "te_component",
        "relay_component",
        "target_coupling_component",
    ]
    metric_cols = [
        "total_score",
        "structural_shift_ang",
        "rmsf_delta_abs_ang",
        "speed_delta_abs_ang_per_ps",
        "contact_change",
        "te_out_gain",
        "te_in_gain",
        "te_out_abs_delta",
        "te_in_abs_delta",
        "target_coupling_gain",
        "relay_score",
        "rank_percentile",
    ]

    rows: List[Dict[str, Any]] = []
    for (scenario, node_label), items in by_key.items():
        total_reps = len(set(scenario_runs.get(scenario, [])))
        observed_reps = len({str(item["run_dir"]) for item in items})
        presence_fraction = float(observed_reps) / float(max(1, total_reps))
        ranks = np.asarray([_safe_float(item.get("rank")) for item in items], dtype=float)
        scores = np.asarray([_safe_float(item.get("total_score")) for item in items], dtype=float)
        support_top = float(np.sum(ranks <= float(top_support_n))) / float(max(1, total_reps))
        ci_low, ci_high = _bootstrap_mean_ci(scores.tolist(), rng=rng, n_boot=n_boot)

        first = items[0]
        row: Dict[str, Any] = {
            "scenario": scenario,
            "node_label": node_label,
            "index": first.get("index", ""),
            "chain": first.get("chain", ""),
            "resid": first.get("resid", ""),
            "residue": first.get("residue", ""),
            "wt_residue": first.get("wt_residue", ""),
            "replicates_total": total_reps,
            "replicates_observed": observed_reps,
            "presence_fraction": presence_fraction,
            "support_top_n": int(top_support_n),
            "support_top_n_fraction": support_top,
            "rank_mean": float(np.nanmean(ranks)),
            "rank_median": float(np.nanmedian(ranks)),
            "rank_best": float(np.nanmin(ranks)),
            "rank_worst": float(np.nanmax(ranks)),
            "is_source_hotspot_fraction": float(np.mean([_safe_bool(item.get("is_source_hotspot")) for item in items])),
            "is_target_site_fraction": float(np.mean([_safe_bool(item.get("is_target_site")) for item in items])),
            "total_score_mean": float(np.nanmean(scores)),
            "total_score_std": float(np.nanstd(scores)),
            "total_score_ci95_low": ci_low,
            "total_score_ci95_high": ci_high,
            "conservative_score": ci_low,
        }
        for col in metric_cols:
            vals = np.asarray([_safe_float(item.get(col)) for item in items], dtype=float)
            row[f"{col}_mean"] = float(np.nanmean(vals))
            row[f"{col}_std"] = float(np.nanstd(vals))
        for col in component_cols:
            vals = np.asarray([_safe_float(item.get(col)) for item in items], dtype=float)
            row[f"{col}_mean"] = float(np.nanmean(vals))

        rank_percentile_mean = float(row.get("rank_percentile_mean", 0.0))
        mean_total = float(row["total_score_mean"])
        row["consensus_score"] = presence_fraction * (
            0.50 * mean_total + 0.30 * support_top + 0.20 * rank_percentile_mean
        )
        rows.append(row)

    rows.sort(
        key=lambda row: (
            float(row["consensus_score"]),
            float(row["support_top_n_fraction"]),
            float(row["total_score_mean"]),
        ),
        reverse=True,
    )
    scenario_rank: DefaultDict[str, int] = defaultdict(int)
    for row in rows:
        scenario = str(row["scenario"])
        scenario_rank[scenario] += 1
        row["consensus_rank"] = scenario_rank[scenario]
    return rows


def _aggregate_regions(
    records: Sequence[Dict[str, Any]],
    scenario_runs: Dict[str, List[str]],
    top_support_n: int,
) -> List[Dict[str, Any]]:
    by_key: DefaultDict[Tuple[str, str], List[Dict[str, Any]]] = defaultdict(list)
    for row in records:
        by_key[(str(row["scenario"]), str(row["region"]))].append(dict(row))

    rows: List[Dict[str, Any]] = []
    for (scenario, region), items in by_key.items():
        total_reps = len(set(scenario_runs.get(scenario, [])))
        observed_reps = len({str(item["run_dir"]) for item in items})
        ranks = np.asarray([_safe_float(item.get("rank")) for item in items], dtype=float)
        means = np.asarray([_safe_float(item.get("mean_total_score")) for item in items], dtype=float)
        maxes = np.asarray([_safe_float(item.get("max_total_score")) for item in items], dtype=float)
        support_top = float(np.sum(ranks <= float(top_support_n))) / float(max(1, total_reps))
        presence = float(observed_reps) / float(max(1, total_reps))
        row = {
            "scenario": scenario,
            "region": region,
            "chain": items[0].get("chain", ""),
            "replicates_total": total_reps,
            "replicates_observed": observed_reps,
            "presence_fraction": presence,
            "support_top_n": int(top_support_n),
            "support_top_n_fraction": support_top,
            "rank_mean": float(np.nanmean(ranks)),
            "rank_median": float(np.nanmedian(ranks)),
            "rank_best": float(np.nanmin(ranks)),
            "mean_total_score_mean": float(np.nanmean(means)),
            "mean_total_score_std": float(np.nanstd(means)),
            "max_total_score_mean": float(np.nanmean(maxes)),
            "max_total_score_std": float(np.nanstd(maxes)),
            "top_residue_modes": ",".join(sorted(set(str(item.get("top_residue", "")) for item in items if item.get("top_residue")))),
            "consensus_score": presence * (
                0.55 * float(np.nanmean(means)) + 0.30 * support_top + 0.15 * float(np.nanmean(maxes))
            ),
        }
        rows.append(row)

    rows.sort(key=lambda row: float(row["consensus_score"]), reverse=True)
    scenario_rank: DefaultDict[str, int] = defaultdict(int)
    for row in rows:
        scenario = str(row["scenario"])
        scenario_rank[scenario] += 1
        row["consensus_rank"] = scenario_rank[scenario]
    return rows


def _apply_control_baseline(
    residue_rows: List[Dict[str, Any]],
    control_scenario: Optional[str],
    baseline_margin: float,
) -> List[Dict[str, Any]]:
    control_name = str(control_scenario or "").strip()
    for row in residue_rows:
        row["control_scenario"] = control_name
        row["control_consensus_score"] = ""
        row["control_total_score_mean"] = ""
        row["control_total_score_ci95_high"] = ""
        row["control_support_top_n_fraction"] = ""
        row["baseline_delta_consensus_score"] = ""
        row["baseline_delta_total_score_mean"] = ""
        row["baseline_specific_score"] = ""
        row["baseline_match_key"] = ""
        row["baseline_exceeds_control_ci"] = False
        row["mutation_specific_vs_control"] = False

    if not control_name:
        return []

    control_by_residue: Dict[str, Dict[str, Any]] = {
        str(row.get("node_label", "")): row
        for row in residue_rows
        if str(row.get("scenario", "")) == control_name
    }
    control_by_index: Dict[str, Dict[str, Any]] = {
        str(row.get("index", "")): row
        for row in residue_rows
        if str(row.get("scenario", "")) == control_name and str(row.get("index", "")).strip()
    }
    control_by_chain_resid: Dict[Tuple[str, str], Dict[str, Any]] = {
        (str(row.get("chain", "")), str(row.get("resid", ""))): row
        for row in residue_rows
        if str(row.get("scenario", "")) == control_name
    }
    baseline_rows: List[Dict[str, Any]] = []
    for row in residue_rows:
        residue = str(row.get("node_label", ""))
        index_key = str(row.get("index", ""))
        chain_resid_key = (str(row.get("chain", "")), str(row.get("resid", "")))
        control = control_by_index.get(index_key) if index_key else None
        match_key = f"index:{index_key}" if control is not None and index_key else ""
        if control is None:
            control = control_by_residue.get(residue)
            match_key = f"node_label:{residue}" if control is not None else ""
        if control is None:
            control = control_by_chain_resid.get(chain_resid_key)
            match_key = (
                f"chain_resid:{chain_resid_key[0]}:{chain_resid_key[1]}"
                if control is not None
                else ""
            )
        if control is None:
            control_consensus = 0.0
            control_mean = 0.0
            control_ci_high = 0.0
            control_support = 0.0
        else:
            control_consensus = _safe_float(control.get("consensus_score"), 0.0)
            control_mean = _safe_float(control.get("total_score_mean"), 0.0)
            control_ci_high = _safe_float(control.get("total_score_ci95_high"), 0.0)
            control_support = _safe_float(control.get("support_top_n_fraction"), 0.0)

        delta_consensus = _safe_float(row.get("consensus_score"), 0.0) - control_consensus
        delta_mean = _safe_float(row.get("total_score_mean"), 0.0) - control_mean
        scenario_ci_low = _safe_float(row.get("total_score_ci95_low"), 0.0)
        exceeds_ci = bool(scenario_ci_low > control_ci_high)
        is_control = str(row.get("scenario", "")) == control_name
        mutation_specific = bool(
            (not is_control)
            and delta_consensus >= float(baseline_margin)
            and delta_mean > 0.0
        )

        row["control_consensus_score"] = control_consensus
        row["control_total_score_mean"] = control_mean
        row["control_total_score_ci95_high"] = control_ci_high
        row["control_support_top_n_fraction"] = control_support
        row["baseline_delta_consensus_score"] = delta_consensus
        row["baseline_delta_total_score_mean"] = delta_mean
        row["baseline_specific_score"] = max(0.0, delta_consensus)
        row["baseline_match_key"] = match_key
        row["baseline_exceeds_control_ci"] = exceeds_ci
        row["mutation_specific_vs_control"] = mutation_specific
        if not is_control:
            baseline_rows.append(dict(row))

    baseline_rows.sort(
        key=lambda row: (
            str(row.get("scenario", "")),
            -_safe_float(row.get("baseline_specific_score"), 0.0),
            -_safe_float(row.get("consensus_score"), 0.0),
        )
    )
    scenario_rank: DefaultDict[str, int] = defaultdict(int)
    for row in baseline_rows:
        scenario = str(row.get("scenario", ""))
        scenario_rank[scenario] += 1
        row["baseline_specific_rank"] = scenario_rank[scenario]
    return baseline_rows


def _plot_consensus_scenario(
    scenario: str,
    rows: Sequence[Dict[str, Any]],
    out_png: str,
    top_n: int,
) -> None:
    scenario_rows = [row for row in rows if str(row["scenario"]) == scenario]
    scenario_rows = scenario_rows[: max(1, int(top_n))]
    if not scenario_rows:
        return
    plot_rows = list(reversed(scenario_rows))
    labels = [str(row["node_label"]) for row in plot_rows]
    y = np.arange(len(plot_rows), dtype=float)
    means = np.asarray([float(row["total_score_mean"]) for row in plot_rows], dtype=float)
    low = np.asarray([float(row["total_score_ci95_low"]) for row in plot_rows], dtype=float)
    high = np.asarray([float(row["total_score_ci95_high"]) for row in plot_rows], dtype=float)
    support = np.asarray([float(row["support_top_n_fraction"]) for row in plot_rows], dtype=float)
    xerr = np.vstack([np.maximum(0.0, means - low), np.maximum(0.0, high - means)])

    fig, ax = plt.subplots(figsize=(10.5, max(4.5, 0.34 * len(plot_rows) + 1.5)))
    colors = plt.cm.viridis(np.clip(support, 0.0, 1.0))
    ax.barh(y, means, xerr=xerr, color=colors, alpha=0.9, capsize=3)
    ax.set_yticks(y)
    ax.set_yticklabels(labels)
    ax.set_xlabel("Mean allostery score across replicas")
    ax.set_title(f"Consensus Allosteric Residues: {scenario}")
    ax.grid(alpha=0.2, axis="x")
    for yi, row in zip(y, plot_rows):
        ax.text(
            float(row["total_score_mean"]) + 0.01,
            yi,
            f"support={float(row['support_top_n_fraction']):.2f}",
            va="center",
            fontsize=8,
        )
    fig.tight_layout()
    os.makedirs(os.path.dirname(out_png) or ".", exist_ok=True)
    fig.savefig(out_png, dpi=220)
    plt.close(fig)


def _selection_from_consensus_rows(rows: Sequence[Dict[str, Any]]) -> str:
    terms: List[str] = []
    seen = set()
    for row in rows:
        chain = str(row.get("chain", "")).strip()
        resid = str(row.get("resid", "")).strip()
        if not resid:
            _, parsed_resid, _ = _node_sort_key(str(row.get("node_label", "")))
            resid = str(parsed_resid) if parsed_resid else ""
        if not resid:
            continue
        key = (chain, resid)
        if key in seen:
            continue
        seen.add(key)
        if chain:
            terms.append(f"(chain {chain} and resid {resid})")
        else:
            terms.append(f"(resid {resid})")
    if not terms:
        return "none"
    return "protein and (" + " or ".join(terms) + ")"


def _write_consensus_vmd(
    scenario: str,
    representative_run: Dict[str, str],
    consensus_rows: Sequence[Dict[str, Any]],
    ligand_resname: str,
    out_tcl: str,
    top_n: int,
) -> Optional[str]:
    if not representative_run:
        return None
    run_dir = representative_run["run_dir"]
    summary_path = os.path.join(run_dir, "run_summary.json")
    if not os.path.exists(summary_path):
        return None
    summary = _load_json(summary_path)
    mut_pdb = _resolve_run_path(run_dir, summary["md"]["mut"]["prepared_pdb"])
    mut_dcd_raw = summary["md"]["mut"].get("traj_dcd")
    mut_dcd = _resolve_run_path(run_dir, mut_dcd_raw) if mut_dcd_raw else None
    rows = [row for row in consensus_rows if str(row["scenario"]) == scenario][: max(1, int(top_n))]
    hotspot_sel = _selection_from_consensus_rows(rows)
    label_lines = []
    for row in rows[: min(24, len(rows))]:
        resid = str(row.get("resid", "")).strip()
        chain = str(row.get("chain", "")).strip()
        label = f"{row['consensus_rank']}. {row['node_label']} {float(row['consensus_score']):.3f}"
        label = label.replace("{", "").replace("}", "")
        selection = f"chain {chain} and resid {resid} and name CA" if chain else f"resid {resid} and name CA"
        label_lines += [
            f"set sel [atomselect $mid {{{selection}}}]",
            "if {[$sel num] > 0} {",
            "    set c [measure center $sel]",
            f"    graphics $mid text $c {{{label}}} size 0.85 thickness 2",
            "}",
            "$sel delete",
        ]

    lines = [
        "# Auto-generated consensus allostery hotspot view for VMD",
        f"# Scenario: {scenario}",
        "display projection Orthographic",
        "display depthcue off",
        "axes location Off",
        "color Display Background white",
        f"set mut_pdb {_tcl_braced_path(mut_pdb)}",
        f"set mut_dcd {_tcl_braced_path(mut_dcd)}",
        f"set ligand_sel {{resname {ligand_resname.upper()}}}",
        f"set hotspot_sel {{{hotspot_sel}}}",
        "mol new $mut_pdb type pdb waitfor all",
        "set mid [molinfo top]",
        "if {[string length $mut_dcd] > 0 && [file exists $mut_dcd]} {",
        "    mol addfile $mut_dcd type dcd waitfor all molid $mid",
        "}",
        "mol delrep 0 $mid",
        "mol representation NewCartoon 0.22 24.0 4.2 0",
        "mol color ColorID 8",
        "mol selection {protein}",
        "mol material AOChalky",
        "mol addrep $mid",
        "mol representation Licorice 0.24 20.0 20.0",
        "mol color Name",
        "mol selection $ligand_sel",
        "mol material Glossy",
        "mol addrep $mid",
        "",
        "mol representation VDW 0.55 24.0",
        "mol color ColorID 1",
        "mol selection ($hotspot_sel) and name CA",
        "mol material Glossy",
        "mol addrep $mid",
        "graphics $mid color black",
        *label_lines,
        "display resetview",
        f"puts \"Loaded consensus allostery hotspots for {scenario}.\"",
    ]
    os.makedirs(os.path.dirname(out_tcl) or ".", exist_ok=True)
    with open(out_tcl, "w", encoding="utf-8") as handle:
        handle.write("\n".join(lines) + "\n")
    return out_tcl


def run_consensus(
    panel_dir: str,
    run_dirs: Optional[Sequence[str]],
    rank_missing: bool,
    ligand_resname: str,
    cutoff_ang: float,
    source_hotspots: int,
    top_edges: int,
    top_paths: int,
    top_residues: int,
    top_regions: int,
    max_frames: Optional[int],
    contact_threshold_ang: float,
    output_dir: Optional[str],
    bootstrap: int,
    seed: int,
    control_scenario: Optional[str],
    baseline_margin: float,
) -> Dict[str, Any]:
    panel_dir = os.path.abspath(panel_dir)
    selected_run_dirs = list(run_dirs) if run_dirs else _find_run_dirs(panel_dir)
    if not selected_run_dirs:
        raise ValueError(f"No run_summary.json files found under {panel_dir}.")

    out_dir = os.path.abspath(output_dir or panel_dir)
    os.makedirs(out_dir, exist_ok=True)
    rng = np.random.default_rng(seed)

    residue_records, region_records, scenario_runs, representative_run = _collect_run_records(
        run_dirs=selected_run_dirs,
        rank_missing=rank_missing,
        ligand_resname=ligand_resname,
        cutoff_ang=cutoff_ang,
        source_hotspots=source_hotspots,
        top_edges=top_edges,
        top_paths=top_paths,
        top_residues=top_residues,
        max_frames=max_frames,
        contact_threshold_ang=contact_threshold_ang,
    )
    if not residue_records:
        raise ValueError(
            "No per-run allostery_residue_scores.csv files found. "
            "Run allostery_rank.py first, or pass --rank-missing."
        )

    residue_rows = _aggregate_residues(
        residue_records,
        scenario_runs=scenario_runs,
        top_support_n=top_residues,
        rng=rng,
        n_boot=bootstrap,
    )
    region_rows = _aggregate_regions(region_records, scenario_runs=scenario_runs, top_support_n=top_regions)
    baseline_rows = _apply_control_baseline(
        residue_rows=residue_rows,
        control_scenario=control_scenario,
        baseline_margin=baseline_margin,
    )

    residue_csv = os.path.join(out_dir, "allostery_consensus_residues.csv")
    region_csv = os.path.join(out_dir, "allostery_consensus_regions.csv")
    baseline_csv = os.path.join(out_dir, "allostery_baseline_specific_residues.csv")
    _write_csv(residue_csv, residue_rows)
    _write_csv(region_csv, region_rows)
    if control_scenario:
        _write_csv(baseline_csv, baseline_rows)

    scenarios = sorted(scenario_runs.keys())
    plot_paths: Dict[str, str] = {}
    vmd_paths: Dict[str, str] = {}
    for scenario in scenarios:
        plot_path = os.path.join(out_dir, f"plot_allostery_consensus_{scenario}.png")
        _plot_consensus_scenario(scenario, residue_rows, plot_path, top_n=top_residues)
        if os.path.exists(plot_path):
            plot_paths[scenario] = plot_path
        vmd_path = os.path.join(out_dir, f"view_allostery_consensus_{scenario}.vmd.tcl")
        written = _write_consensus_vmd(
            scenario=scenario,
            representative_run=representative_run.get(scenario, {}),
            consensus_rows=residue_rows,
            ligand_resname=ligand_resname,
            out_tcl=vmd_path,
            top_n=top_residues,
        )
        if written:
            vmd_paths[scenario] = written

    consensus = {
        "panel_dir": panel_dir,
        "run_dirs": selected_run_dirs,
        "scenarios": scenarios,
        "replicates_by_scenario": {k: len(set(v)) for k, v in scenario_runs.items()},
        "top_residues_by_scenario": {
            scenario: [
                row
                for row in residue_rows
                if str(row["scenario"]) == scenario and int(row["consensus_rank"]) <= int(top_residues)
            ]
            for scenario in scenarios
        },
        "top_regions_by_scenario": {
            scenario: [
                row
                for row in region_rows
                if str(row["scenario"]) == scenario and int(row["consensus_rank"]) <= int(top_regions)
            ]
            for scenario in scenarios
        },
        "outputs": {
            "residue_consensus_csv": residue_csv,
            "region_consensus_csv": region_csv,
            "baseline_specific_residue_csv": baseline_csv if control_scenario else None,
            "plots": plot_paths,
            "vmd_scripts": vmd_paths,
        },
        "control_baseline": {
            "control_scenario": control_scenario,
            "baseline_margin": baseline_margin,
            "baseline_specific_residue_csv": baseline_csv if control_scenario else None,
        },
    }
    consensus_json = os.path.join(out_dir, "allostery_consensus.json")
    with open(consensus_json, "w", encoding="utf-8") as handle:
        json.dump(consensus, handle, indent=2)

    manifest = {
        "consensus_json": consensus_json,
        "residue_consensus_csv": residue_csv,
        "region_consensus_csv": region_csv,
        "baseline_specific_residue_csv": baseline_csv if control_scenario else None,
        "plots": plot_paths,
        "vmd_scripts": vmd_paths,
    }
    manifest_path = os.path.join(out_dir, "allostery_consensus_manifest.json")
    with open(manifest_path, "w", encoding="utf-8") as handle:
        json.dump(manifest, handle, indent=2)
    return manifest


def main() -> None:
    parser = argparse.ArgumentParser(description="Aggregate allostery rankings across replicas/scenarios.")
    parser.add_argument("--panel-dir", default=".", help="Panel directory containing scenario/rep*/run_summary.json.")
    parser.add_argument("--run-dir", action="append", default=None, help="Specific run dir; repeat to bypass panel scan.")
    parser.add_argument("--rank-missing", action="store_true", help="Run allostery_rank.py logic for runs missing residue scores.")
    parser.add_argument("--ligand-resname", default="ZN")
    parser.add_argument("--cutoff-ang", type=float, default=6.0)
    parser.add_argument("--source-hotspots", type=int, default=10)
    parser.add_argument("--top-edges", type=int, default=80)
    parser.add_argument("--top-paths", type=int, default=30)
    parser.add_argument("--top-residues", type=int, default=30)
    parser.add_argument("--top-regions", type=int, default=10)
    parser.add_argument("--max-frames", type=int, default=2000)
    parser.add_argument("--contact-threshold-ang", type=float, default=8.0)
    parser.add_argument("--output-dir", default=None, help="Default: panel dir.")
    parser.add_argument("--bootstrap", type=int, default=1000)
    parser.add_argument("--seed", type=int, default=13)
    parser.add_argument("--control-scenario", default=None, help="Scenario to use as a control/baseline for mutation-specific calls.")
    parser.add_argument("--baseline-margin", type=float, default=0.05, help="Minimum consensus-score excess over control.")
    args = parser.parse_args()

    manifest = run_consensus(
        panel_dir=args.panel_dir,
        run_dirs=args.run_dir,
        rank_missing=args.rank_missing,
        ligand_resname=args.ligand_resname,
        cutoff_ang=args.cutoff_ang,
        source_hotspots=args.source_hotspots,
        top_edges=args.top_edges,
        top_paths=args.top_paths,
        top_residues=args.top_residues,
        top_regions=args.top_regions,
        max_frames=None if args.max_frames <= 0 else args.max_frames,
        contact_threshold_ang=args.contact_threshold_ang,
        output_dir=args.output_dir,
        bootstrap=args.bootstrap,
        seed=args.seed,
        control_scenario=args.control_scenario,
        baseline_margin=args.baseline_margin,
    )
    print(json.dumps(manifest, indent=2))


if __name__ == "__main__":
    main()
