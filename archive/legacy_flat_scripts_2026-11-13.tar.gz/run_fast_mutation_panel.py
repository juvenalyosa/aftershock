"""
Run a fast no-MD mutation/allostery screening panel.

This is the quick screening counterpart to `run_mutation_panel.py`.
It builds mutant structures with the existing MODELLER path, transfers ligand
coordinates, then scores the WT/MUT structure pair with `fast_allostery_scan.py`.

Use this for FoldX/DDMut-like prioritization before spending time on MD.
"""

from __future__ import annotations

import argparse
import csv
import json
import os
import shutil
from typing import Any, Dict, List, Sequence, Tuple

os.environ.setdefault("MPLCONFIGDIR", os.path.join(os.environ.get("TMPDIR", "/tmp"), "pert-matplotlib"))

import matplotlib.pyplot as plt
import numpy as np

from fast_allostery_scan import run_fast_scan
from run_mutation_panel import MUTATION_SCENARIOS, _parse_csv_tokens
from topology_safe_pipeline import BuildConfig, prepare_structures


ScenarioDef = Tuple[str, List[str]]


def _write_csv(path: str, rows: Sequence[Dict[str, object]]) -> None:
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    if not rows:
        with open(path, "w", encoding="utf-8") as handle:
            handle.write("")
        return
    keys = list(rows[0].keys())
    with open(path, "w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=keys)
        writer.writeheader()
        writer.writerows(rows)


def _split_mutations(value: str) -> List[str]:
    tokens: List[str] = []
    for chunk in str(value).replace(";", ",").split(","):
        token = chunk.strip()
        if token:
            tokens.append(token)
    return tokens


def _parse_mutation_set(value: str) -> ScenarioDef:
    if ":" not in value:
        raise ValueError(
            "--mutation-set must use NAME:MUT1,MUT2 syntax, for example "
            "egfr_ex19del:L747_A750del,K754R"
        )
    name, mutation_text = value.split(":", 1)
    name = name.strip()
    mutations = _split_mutations(mutation_text)
    if not name or not mutations:
        raise ValueError(f"Invalid mutation set: {value!r}")
    return name, mutations


def _load_json_mutation_sets(payload: Any) -> List[ScenarioDef]:
    if isinstance(payload, dict) and "mutation_sets" in payload:
        payload = payload["mutation_sets"]
    if isinstance(payload, dict):
        out: List[ScenarioDef] = []
        for name, mutations in payload.items():
            if isinstance(mutations, str):
                out.append((str(name), _split_mutations(mutations)))
            elif isinstance(mutations, list):
                out.append((str(name), [str(item).strip() for item in mutations if str(item).strip()]))
            else:
                raise ValueError(f"Mutation set {name!r} must be a string or list.")
        return out
    if isinstance(payload, list):
        out = []
        for item in payload:
            if not isinstance(item, dict):
                raise ValueError("JSON mutation-set lists must contain objects.")
            name = str(item.get("name", "")).strip()
            mutations = item.get("mutations", [])
            if isinstance(mutations, str):
                parsed = _split_mutations(mutations)
            elif isinstance(mutations, list):
                parsed = [str(token).strip() for token in mutations if str(token).strip()]
            else:
                raise ValueError(f"Mutation set {name!r} has invalid mutations.")
            if not name or not parsed:
                raise ValueError(f"Invalid JSON mutation set entry: {item!r}")
            out.append((name, parsed))
        return out
    raise ValueError("Mutation JSON must be a mapping, a list, or contain a 'mutation_sets' key.")


def _load_mutation_sets(path: str) -> List[ScenarioDef]:
    lower = path.lower()
    if lower.endswith(".json"):
        with open(path, "r", encoding="utf-8") as handle:
            return _load_json_mutation_sets(json.load(handle))

    rows: List[ScenarioDef] = []
    with open(path, "r", newline="", encoding="utf-8") as handle:
        reader = csv.DictReader(handle)
        if reader.fieldnames is None:
            raise ValueError(f"Mutation file has no header: {path}")
        required = {"name", "mutations"}
        missing = required - set(reader.fieldnames)
        if missing:
            raise ValueError(f"Mutation CSV must contain columns {sorted(required)}; missing {sorted(missing)}")
        for row in reader:
            name = str(row.get("name", "")).strip()
            mutations = _split_mutations(str(row.get("mutations", "")))
            if not name or not mutations:
                raise ValueError(f"Invalid mutation CSV row: {row!r}")
            rows.append((name, mutations))
    return rows


def _dedupe_scenarios(scenarios: Sequence[ScenarioDef]) -> List[ScenarioDef]:
    seen = set()
    out: List[ScenarioDef] = []
    for name, mutations in scenarios:
        clean_name = str(name).strip()
        clean_mutations = [str(token).strip() for token in mutations if str(token).strip()]
        if not clean_name or not clean_mutations:
            raise ValueError(f"Invalid scenario definition: {(name, mutations)!r}")
        if clean_name in seen:
            raise ValueError(f"Duplicate scenario name: {clean_name}")
        seen.add(clean_name)
        out.append((clean_name, clean_mutations))
    return out


def _resolve_scenarios(custom_scenarios: Sequence[ScenarioDef], include_builtins: bool) -> List[ScenarioDef]:
    scenarios: List[ScenarioDef] = []
    if include_builtins or not custom_scenarios:
        scenarios.extend((name, list(mutations)) for name, mutations in MUTATION_SCENARIOS)
    scenarios.extend((name, list(mutations)) for name, mutations in custom_scenarios)
    return _dedupe_scenarios(scenarios)


def _scenario_summary(rows: Sequence[Dict[str, object]]) -> Dict[str, Dict[str, float]]:
    by_name: Dict[str, List[Dict[str, object]]] = {}
    for row in rows:
        by_name.setdefault(str(row["scenario"]), []).append(dict(row))
    out: Dict[str, Dict[str, float]] = {}
    metrics = [
        "global_fast_allostery_score",
        "mean_top10_destabilization_proxy",
        "aligned_ca_rmsd_ang",
    ]
    for name, items in by_name.items():
        entry: Dict[str, float] = {"replicas": float(len(items))}
        for metric in metrics:
            vals = np.asarray([float(item[metric]) for item in items], dtype=float)
            entry[f"{metric}_mean"] = float(np.mean(vals))
            entry[f"{metric}_std"] = float(np.std(vals))
        out[name] = entry
    return out


def _plot_summary(summary: Dict[str, Dict[str, float]], out_png: str) -> None:
    if not summary:
        return
    names = list(summary.keys())
    x = np.arange(len(names), dtype=float)
    score = np.asarray([summary[n]["global_fast_allostery_score_mean"] for n in names], dtype=float)
    score_sd = np.asarray([summary[n]["global_fast_allostery_score_std"] for n in names], dtype=float)
    destab = np.asarray([summary[n]["mean_top10_destabilization_proxy_mean"] for n in names], dtype=float)
    rmsd = np.asarray([summary[n]["aligned_ca_rmsd_ang_mean"] for n in names], dtype=float)

    fig, axes = plt.subplots(1, 3, figsize=(13.5, 4.2))
    axes[0].bar(x, score, yerr=score_sd, color="#4C78A8", capsize=4)
    axes[0].set_title("Fast allostery score")
    axes[0].set_ylabel("score")
    axes[1].bar(x, destab, color="#E45756")
    axes[1].set_title("Destabilization proxy")
    axes[2].bar(x, rmsd, color="#54A24B")
    axes[2].set_title("Aligned CA RMSD")
    axes[2].set_ylabel("Angstrom")
    for ax in axes:
        ax.set_xticks(x)
        ax.set_xticklabels(names, rotation=25, ha="right")
        ax.grid(alpha=0.2, axis="y")
    fig.suptitle("Fast Mutation Screening Panel")
    fig.tight_layout()
    os.makedirs(os.path.dirname(out_png) or ".", exist_ok=True)
    fig.savefig(out_png, dpi=220)
    plt.close(fig)


def run_fast_panel(
    reference_pdb: str,
    template_pdb: str,
    ligand_xml: str,
    ligand_resname: str,
    template: str,
    chain_id: str,
    replicas: int,
    output_dir: str,
    num_models: int,
    num_processors: int,
    selected_scenarios: Sequence[str],
    cutoff_ang: float,
    contact_threshold_ang: float,
    source_hotspots: int,
    top_residues: int,
    scenario_defs: Sequence[ScenarioDef] | None = None,
) -> Dict[str, object]:
    os.makedirs(output_dir, exist_ok=True)
    template_code = template[:-1]
    scenarios: List[ScenarioDef] = _dedupe_scenarios(
        list(scenario_defs) if scenario_defs is not None else [(name, list(mutations)) for name, mutations in MUTATION_SCENARIOS]
    )
    if selected_scenarios:
        selected = set(selected_scenarios)
        scenarios = [item for item in scenarios if item[0] in selected]
        if not scenarios:
            raise ValueError("No valid scenarios selected.")

    rows: List[Dict[str, object]] = []
    for scenario_index, (scenario_name, mutations) in enumerate(scenarios):
        for rep in range(1, int(replicas) + 1):
            run_dir = os.path.join(output_dir, scenario_name, f"rep{rep}")
            os.makedirs(run_dir, exist_ok=True)
            seed_dir = os.path.join(run_dir, "model_build", "modeling_job")
            os.makedirs(seed_dir, exist_ok=True)
            if template_pdb:
                shutil.copy2(template_pdb, os.path.join(seed_dir, f"{template_code}.pdb"))

            seed_modeller = 17 + scenario_index * 100 + rep
            build_cfg = BuildConfig(
                reference_pdb=reference_pdb,
                ligand_xml=ligand_xml,
                ligand_resnames=[ligand_resname],
                mutations=mutations,
                templates=[template],
                chain_id=chain_id,
                num_models=num_models,
                num_processors=num_processors,
                modeller_seed=seed_modeller,
            )
            prep = prepare_structures(build_cfg, output_dir=run_dir)
            scan = run_fast_scan(
                wt_pdb=prep.wt_pdb,
                mut_pdb=prep.mutant_ligand_pdb,
                ligand_resname=ligand_resname,
                output_dir=os.path.join(run_dir, "fast_scan"),
                mutation_label=scenario_name,
                mutation_specs=mutations,
                cutoff_ang=cutoff_ang,
                contact_threshold_ang=contact_threshold_ang,
                source_hotspots=source_hotspots,
                top_residues=top_residues,
            )
            top_res = ",".join(row["node_label"] for row in scan["top_residues"][: min(10, len(scan["top_residues"]))])
            rows.append(
                {
                    "scenario": scenario_name,
                    "replica": rep,
                    "mutations": ",".join(mutations),
                    "predicted_allosteric_effect": scan["predicted_allosteric_effect"],
                    "global_fast_allostery_score": float(scan["global_fast_allostery_score"]),
                    "mean_top10_destabilization_proxy": float(scan["mean_top10_destabilization_proxy"]),
                    "aligned_ca_rmsd_ang": float(scan["aligned_ca_rmsd_ang"]),
                    "mutation_source_residues": ",".join(scan.get("mutation_source_residues", [])),
                    "source_residues": ",".join(scan["source_residues"]),
                    "target_residues": ",".join(scan["target_residues"]),
                    "deleted_wt_residues": ",".join(scan["deleted_wt_residues"]),
                    "top_residues": top_res,
                    "summary_json": scan["outputs"]["summary_json"],
                }
            )

    metrics_csv = os.path.join(output_dir, "fast_panel_metrics.csv")
    _write_csv(metrics_csv, rows)
    summary = _scenario_summary(rows)
    summary_json = os.path.join(output_dir, "fast_panel_summary.json")
    with open(summary_json, "w", encoding="utf-8") as handle:
        json.dump(summary, handle, indent=2)
    plot_png = os.path.join(output_dir, "fast_panel_summary.png")
    _plot_summary(summary, plot_png)

    manifest = {
        "runs": len(rows),
        "scenarios": [name for name, _ in scenarios],
        "metrics_csv": metrics_csv,
        "summary_json": summary_json,
        "summary_plot": plot_png,
        "method_note": (
            "No production MD. Supports SNP/SNPs, INS, DEL, DELINS/INSDEL, DUP, and "
            "reference-coordinate combinations through named mutation sets. Use for fast "
            "prioritization before targeted validation."
        ),
    }
    manifest_path = os.path.join(output_dir, "fast_panel_manifest.json")
    with open(manifest_path, "w", encoding="utf-8") as handle:
        json.dump(manifest, handle, indent=2)
    return manifest


def main() -> None:
    parser = argparse.ArgumentParser(description="Run fast no-MD mutation/allostery screening panel.")
    parser.add_argument("--reference-pdb", default="toy_data/1ZNF.pdb")
    parser.add_argument("--template-pdb", default="toy_data/1ZNF.pdb")
    parser.add_argument("--ligand-xml", default="toy_data/empty_ligand.xml")
    parser.add_argument("--ligand-resname", default="ZN")
    parser.add_argument("--template", default="1ZNFA")
    parser.add_argument("--chain-id", default="A")
    parser.add_argument("--replicas", type=int, default=1)
    parser.add_argument("--output-dir", default="fast_panel_1znf")
    parser.add_argument("--num-models", type=int, default=4)
    parser.add_argument("--num-processors", type=int, default=1)
    parser.add_argument("--cutoff-ang", type=float, default=6.0)
    parser.add_argument("--contact-threshold-ang", type=float, default=8.0)
    parser.add_argument("--source-hotspots", type=int, default=8)
    parser.add_argument("--top-residues", type=int, default=30)
    parser.add_argument(
        "--mutation-set",
        action="append",
        default=None,
        help=(
            "Custom named variant set as NAME:MUT1,MUT2. Repeat for multiple sets. "
            "Examples: snps:K2R,Q20R or complex:10_11delinsG,Q20dup."
        ),
    )
    parser.add_argument(
        "--mutation-file",
        action="append",
        default=None,
        help=(
            "JSON or CSV mutation-set file. JSON may be {'name':['K2R']} mapping, "
            "a list of {'name','mutations'} objects, or {'mutation_sets': ...}. "
            "CSV requires columns: name,mutations."
        ),
    )
    parser.add_argument(
        "--include-builtins",
        action="store_true",
        help="Run built-in examples in addition to custom --mutation-set/--mutation-file entries.",
    )
    parser.add_argument(
        "--scenarios",
        action="append",
        default=None,
        help="Scenario name filter, repeat/comma separated. Applies after built-in/custom sets are loaded.",
    )
    args = parser.parse_args()
    selected = _parse_csv_tokens(args.scenarios) if args.scenarios else []
    custom_scenarios: List[ScenarioDef] = []
    for mutation_file in args.mutation_file or []:
        custom_scenarios.extend(_load_mutation_sets(mutation_file))
    for mutation_set in args.mutation_set or []:
        custom_scenarios.append(_parse_mutation_set(mutation_set))
    scenario_defs = _resolve_scenarios(custom_scenarios, include_builtins=bool(args.include_builtins))
    manifest = run_fast_panel(
        reference_pdb=args.reference_pdb,
        template_pdb=args.template_pdb,
        ligand_xml=args.ligand_xml,
        ligand_resname=args.ligand_resname,
        template=args.template,
        chain_id=args.chain_id,
        replicas=args.replicas,
        output_dir=args.output_dir,
        num_models=args.num_models,
        num_processors=args.num_processors,
        selected_scenarios=selected,
        cutoff_ang=args.cutoff_ang,
        contact_threshold_ang=args.contact_threshold_ang,
        source_hotspots=args.source_hotspots,
        top_residues=args.top_residues,
        scenario_defs=scenario_defs,
    )
    print(json.dumps(manifest, indent=2))


if __name__ == "__main__":
    main()
